# Gatekeep Sports Desk — audit & fix pass (NFL v1.5 · MLB v5.9 · NHL sog_v2)

Benchmark in mind: RotoBot-style honesty — distributions not point guesses, calibration you can check,
injury/availability awareness, and no number on screen that did not come from data.

## What was wrong everywhere (and is now fixed in all three sports)
| Problem | Fix |
|---|---|
| "Edge" measured against the de-vigged line was treated as a bet signal, but you pay the vig | Every sport now requires **EV > 0 at the price offered** (shared `src/lib/odds.ts`) |
| Blank / garbage odds silently became +100 (fake 50% market, fake two-way) | Parsers return `null`; unpriced rows are model-only and can never qualify |
| Estimated / guessed inputs could still show BET / PLAY / STAB | One universal gate (availability → input quality → edge). ESTIMATED can never qualify |
| Hand-typed injury / roster lists | Removed. Availability comes from live feeds; no feed = UNKNOWN = cannot qualify |
| Random "settle demo" results flattered the scoreboards | Removed. Grading is from official box scores / nflverse. Legacy rows are tagged DEMO and excluded from every metric |
| Odds saved in localStorage with no date (yesterday's price on today's line) | Odds maps are date-stamped and discarded on another day |
| No way to tell if the model is calibrated | Shared calibration lib: Brier vs market, reliability bins, randomized-PIT 50/80/90% interval coverage |

## NFL receptions (v1.4 → v1.5) — validated on real nflverse data
* Real ingestion (`stats_player_week`, `snap_counts`, `injuries`, `games`): routes proxy = team dropbacks × snap %, TPRR shrunk to prior season, walk-forward (week W sees only weeks < W).
* Backtest reproduced the 2025 WR over-prediction; fixed with an in-season **decay-weighted** position ratio (actual/mu 0.935 → 0.991). Carrying the prior-season ratio made 2026 worse, so it is off.
* Early-season dispersion inflation α·(1 + 2.5/games). WR α .10 / TE α .125 re-validated.
* Game cap (3 BETs/game), one-sided price can never be BET, no fabricated -115/-115 baseline rows, receiver/team resolution bug fixed, schedule from nflverse (no hard-coded week, no ESPN spread guessing), real grades from nflverse.

## MLB hits (v5.8 → v5.9)
* Line probabilities from the PA model's hit-count distribution (Poisson-binomial), not a Poisson shortcut, so 1.5 / 2.5 lines are priced correctly (still not PLAY until you opt in).
* Real batter/pitcher inputs from statsapi (season, game log, platoon splits, K%, recent IP). Missing pieces → EST → PASS.
* PLAY requires confirmed lineup, slot 1–3, price window, **EV > 0**, REAL inputs.
* Ledger grades from official box scores (DNP = void, postponed = void); no random grading.
* Parlay picker: EV at the offered price; same-game haircut applied only when no quoted price; deterministic simulation.
* Reference-cache key now includes the tune (changing a setting no longer returns stale numbers).

## NHL (sog_v1 → sog_v2) — and the points market you asked for
* **Points market added** (NB, r = 12 is a prior to calibrate; lines 0.5 / 1.5 / 2.5). Shots / Points toggle on the desk.
* Skater rates are **shrunk** toward last season and a position prior (a 4-game 6.0 shots/game start is no longer priced as a 6.0 shooter).
* Real game logs (last 10 games) replace the fake `[round(mu) ×5]` form chips.
* Opponent factor from live shots-against / goals-against, shrunk by games played; the old hand-typed table is a labelled half-weight fallback.
* **FADE** now needs a real under price and +EV; over/under entered separately and de-vigged together.
* Removed: the 2024 hand-typed roster (players on teams they no longer play for), seeded odds, the fake fallback slate, ESPN game ids (can't be graded), `mu from the line` for screenshot players (now ESTIMATED from the position prior, cannot qualify), mutation of the seed array.
* Ledger: log priced rows → grade from the official box score; scoreboard shows per-market calibration, interval coverage, W-L and units for STAB/FADE only.

## Verified here
* `tsc` clean, **65 / 65 tests** (NFL 17, MLB 19, NHL 29) incl. fixtures for every parser and grader; `server.ts` and the whole app bundle with esbuild.
* NFL pipeline run end-to-end on real nflverse 2024-2026 files.

## NOT verified (be straight about it)
* The sandbox cannot reach the NHL, MLB or ESPN hosts. Those fetchers/parsers are tested against fixtures that follow the documented JSON shapes, **not live responses**. First run on your machine: open each tab and read the status chips (they say exactly which feed failed).
* The UI was typechecked and bundled, **not rendered** (React isn't installable offline here).
* NHL has no historical backtest here: shrinkage K (20 / 40), position priors, the points `r = 12`, and the opponent clamp are sensible priors, not fitted values. Let the ledger's reliability bins and interval coverage tell you what to move; don't trust them before ~200+ graded rows per market.
* ESPN's injury JSON shape was written defensively but is the least certain parser.

## Setup
`npm install && npm run dev` (needs Node 20+; `GEMINI_API_KEY` for screenshot OCR). Tests: `npx tsx --test src/model/*.test.ts`.
