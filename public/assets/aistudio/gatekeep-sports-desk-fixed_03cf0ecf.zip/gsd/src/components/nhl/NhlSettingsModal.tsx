import React from 'react';

interface NhlSettingsModalProps {
  edgeThreshold: number;
  maxJuice: number;
  showStabsOnly: boolean;
  onUpdate: (edgeThreshold: number, maxJuice: number, showStabsOnly: boolean) => void;
}

export const NhlSettingsModal: React.FC<NhlSettingsModalProps> = ({
  edgeThreshold,
  maxJuice,
  showStabsOnly,
  onUpdate
}) => {
  return (
    <div className="space-y-4">
      <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
        <div className="border-b border-[#222d3e] pb-3 mb-4">
          <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white">
            NHL Desk Settings (sog_v2 · shots + points)
          </h2>
          <p className="text-xs text-[#8b97ac]">
            Configure edge qualification thresholds and chalk ceilings for small bankrolls.
          </p>
        </div>

        <div className="space-y-4 text-xs font-mono max-w-md">
          <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
            <label className="block text-[#8b97ac] uppercase text-[11px] mb-1">
              Minimum Edge Threshold (percentage points)
            </label>
            <input
              type="number"
              step="0.5"
              value={edgeThreshold}
              onChange={e => onUpdate(parseFloat(e.target.value) || 5.0, maxJuice, showStabsOnly)}
              className="w-full bg-[#182232] border border-[#222d3e] rounded-lg p-2 text-white font-mono outline-none focus:border-cyan-400"
            />
            <span className="text-[10px] text-[#556277] mt-1 block">
              Default is 5.0 pp (e.g. 60% model vs 55% market)
            </span>
          </div>

          <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
            <label className="block text-[#8b97ac] uppercase text-[11px] mb-1">
              Maximum Chalk Juice (American Odds)
            </label>
            <input
              type="number"
              value={maxJuice}
              onChange={e => onUpdate(edgeThreshold, parseInt(e.target.value) || -200, showStabsOnly)}
              className="w-full bg-[#182232] border border-[#222d3e] rounded-lg p-2 text-white font-mono outline-none focus:border-cyan-400"
            />
            <span className="text-[10px] text-[#556277] mt-1 block">
              Default is -200. Applies to whichever side you would bet.
            </span>
          </div>

          <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e] flex items-center justify-between">
            <div>
              <span className="text-white font-bold block">Only show qualifying rows (STAB / FADE)</span>
              <span className="text-[10px] text-[#556277]">Hides every PASS row</span>
            </div>
            <input
              type="checkbox"
              checked={showStabsOnly}
              onChange={e => onUpdate(edgeThreshold, maxJuice, e.target.checked)}
              className="w-4 h-4 accent-cyan-400"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
