import React from 'react';
import { NhlSkaterProjection, NhlMarket } from '../../types/nhl';
import { NhlRowEval, marketOf } from '../../lib/nhl_board';
import { NHL_CONFIG } from '../../model/nhl_engine';

interface Props {
  projection: NhlSkaterProjection;
  market: NhlMarket;
  line: number;
  evalRow: NhlRowEval;
}

const Row = ({ k, v, strong }: { k: React.ReactNode; v: React.ReactNode; strong?: boolean }) => (
  <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
    <span className="text-[#8b97ac]">{k}</span>
    <span className={strong ? 'text-cyan-400 font-bold' : 'text-white font-medium'}>{v}</span>
  </div>
);

export const NhlPlayerDrawer: React.FC<Props> = ({ projection, market, line, evalRow }) => {
  const mp = marketOf(projection, market)!;
  const d = evalRow.decision;
  const recent = market === 'sog' ? projection.recentShots : projection.recentPoints;
  const unit = market === 'sog' ? 'SOG' : 'PTS';
  const srcNote =
    projection.oppSource === 'live' ? 'live team table, shrunk by games played'
    : projection.oppSource === 'static' ? 'STALE hand-typed table at half weight (live team table not loaded)'
    : 'no opponent data (neutral 1.00)';

  return (
    <div className="p-4 bg-[#182232] border-t border-[#222d3e] text-xs font-mono space-y-3">
      <div className="flex items-center justify-between border-b border-[#222d3e] pb-2">
        <span className="uppercase tracking-wider text-sm font-bold text-white">
          {market === 'sog' ? 'Shots on Goal' : 'Points'} projection &amp; price
        </span>
        <span className="text-cyan-400">{NHL_CONFIG.version} &middot; NB r = {mp.r}{market === 'pts' ? ' (prior)' : ''}</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1">
        <Row k="Shrunk base rate (μ₀)" v={`${mp.mu0.toFixed(2)} ${unit}/gm`} />
        <Row k="Evidence behind rate" v={`${mp.nEff.toFixed(0)} effective games`} />
        <Row k={`Opponent factor (${projection.opp})`} v={`${mp.oppFactor.toFixed(3)}×`} />
        <Row k="Final expected (μ)" v={`${mp.mu.toFixed(2)} ${unit}`} strong />
        <Row k={`P(Over ${line})`} v={`${(evalRow.pOver * 100).toFixed(1)}%`} />
        <Row k={`P(Under ${line})`} v={`${(evalRow.pUnder * 100).toFixed(1)}%`} />
        <Row k="Fair over (de-vigged)" v={d.fairOver !== null ? `${(d.fairOver * 100).toFixed(1)}%${d.twoWay ? '' : ' (1-sided, assumed hold)'}` : '—'} />
        <Row k="EV over / under" v={`${d.evOver !== null ? (d.evOver * 100).toFixed(1) + '%' : '—'} / ${d.evUnder !== null ? (d.evUnder * 100).toFixed(1) + '%' : '—'}`} />
        <Row k="Avg ice time" v={`${projection.toiAvg.toFixed(1)} min`} />
        <Row k="Inputs / availability" v={`${projection.inputsSource} / ${projection.availability}`} />
      </div>
      <div className="text-[10px] text-[#556277]">Opponent factor source: {srcNote}.</div>

      <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
        <div className="text-[11px] text-[#8b97ac] uppercase mb-1.5 font-bold">Last games ({unit}, most recent first):</div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {recent.length ? recent.map((s, i) => (
            <span key={i} className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold ${
              s > line ? 'bg-emerald-950 text-emerald-300 border border-emerald-600' : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}>{s}</span>
          )) : <span className="text-[#556277]">No game log loaded</span>}
        </div>
      </div>

      <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
        <div className="text-white font-bold mb-1">
          Action: <span className={`px-1.5 py-0.5 rounded text-[10px] ${d.tag === 'STAB' ? 'bg-emerald-950 text-emerald-300 border border-emerald-600' : d.tag === 'FADE' ? 'bg-orange-950 text-orange-300 border border-orange-600' : 'bg-slate-800 text-slate-300'}`}>{d.tag}</span>
        </div>
        <div className="text-[#8b97ac]">{d.reason}</div>
      </div>
    </div>
  );
};
