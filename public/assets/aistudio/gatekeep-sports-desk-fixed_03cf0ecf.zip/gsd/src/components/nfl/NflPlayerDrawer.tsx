import React from 'react';
import { NflPropSnapshot } from '../../types/nfl';
import { NFL_PLAYERS } from '../../data/nfl_seed';

interface NflPlayerDrawerProps {
  snapshot: NflPropSnapshot;
  isBetPlaced: boolean;
  onRecordBet: (snap: NflPropSnapshot) => void;
}

export const NflPlayerDrawer: React.FC<NflPlayerDrawerProps> = ({
  snapshot,
  isBetPlaced,
  onRecordBet
}) => {
  const player = NFL_PLAYERS[snapshot.player];
  const routePct = player ? (player.route_pct * 100).toFixed(1) : "—";
  const ratio = player ? player.ratio.toFixed(4) : "1.0000";

  return (
    <div className="p-4 bg-[#182232] border-t border-[#222d3e] text-xs space-y-3">
      <div className="font-semibold text-white flex items-center justify-between border-b border-[#222d3e] pb-2">
        <span className="font-display uppercase tracking-wider text-sm">
          Mathematical Derivation & Audit Ledger (v1.4 Spec)
        </span>
        <span className="font-mono text-sky-400">
          Model Version: v1.4 walk-forward + 0.6/0.4 blend
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs">
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">1. Projected Dropbacks (Game Script OLS)</span>
          <span className="font-mono text-white font-medium">{snapshot.dropbacks.toFixed(2)}</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">2. Route Participation (Snap Proxy)</span>
          <span className="font-mono text-white font-medium">{routePct}%</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">3. Bayesian Shrunk TPRR (K=100)</span>
          <span className="font-mono text-white font-medium">{snapshot.shrunkTprr.toFixed(4)}</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">4. Shrunk Catch Rate (K=30 vs 0.68)</span>
          <span className="font-mono text-white font-medium">{(snapshot.shrunkCatchRate * 100).toFixed(1)}%</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">5. Structural Expected &mu;&#x2081;</span>
          <span className="font-mono text-white font-medium">{snapshot.muStructural.toFixed(3)}</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">6. Walk-Forward Ratio (Clipped [0.85, 1.15])</span>
          <span className="font-mono text-white font-medium">{ratio}</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">7. v1.4 Final Blended &mu; (60% Model / 40% Szn Avg)</span>
          <span className="font-mono text-sky-400 font-bold">{snapshot.mu.toFixed(3)}</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">8. Negative Binomial Dispersion (&alpha;)</span>
          <span className="font-mono text-white font-medium">{snapshot.alpha.toFixed(3)} ({snapshot.pos})</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">9. De-vigged Market Fair Win %</span>
          <span className="font-mono text-white font-medium">
            {((snapshot.lean === 'OVER' ? snapshot.fair_over : snapshot.fair_under) * 100).toFixed(1)}%
          </span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">10. Model Conditional Win %</span>
          <span className="font-mono text-white font-medium">
            {((snapshot.lean === 'OVER' ? snapshot.p_over : snapshot.p_under) * 100).toFixed(1)}%
          </span>
        </div>
      </div>

      <div className="p-3 bg-[#0f1520] rounded-lg border border-[#222d3e]">
        <div className="text-white font-semibold mb-1">
          Card Rule Decision: <span className="font-mono text-sky-400">{snapshot.cardStatus}</span>
        </div>
        <div className="text-xs text-[#8b97ac]">
          {snapshot.cardReason}
        </div>
      </div>

      <div className="flex items-center justify-between pt-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRecordBet(snapshot);
          }}
          className={`px-4 py-2 rounded-lg text-xs font-semibold font-display tracking-wider uppercase transition ${
            isBetPlaced
              ? 'bg-sky-600 hover:bg-sky-500 text-white'
              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold'
          }`}
        >
          {isBetPlaced ? 'Edit Recorded Bet' : 'Record Real Bet (1.0u)'}
        </button>
        <span className="text-[11px] text-[#8b97ac] font-mono">
          Strict pre-kickoff logging · Never rewrites previous logs
        </span>
      </div>
    </div>
  );
};
