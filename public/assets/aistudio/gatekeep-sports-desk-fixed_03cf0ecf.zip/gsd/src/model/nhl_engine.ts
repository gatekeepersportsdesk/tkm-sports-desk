/**
 * NHL props engine v2 (sog_v2): shots on goal + points.
 *
 * What changed from sog_v1 and why:
 *  - Rates are SHRUNK, not raw. A skater with 4 games and a 6.0 shots/game
 *    start is not a 6.0 shooter: current-season rate is pulled toward the
 *    prior-season rate, which is itself pulled toward a position prior.
 *  - Opponent factors come from live team shots-against / goals-against
 *    (shrunk by games played), with the old hand-typed table only as a
 *    half-weight fallback that is labelled as such.
 *  - Points market (NB, r is a PRIOR to be calibrated on the ledger).
 *  - Pricing goes through the shared odds lib: two-way de-vig, EV at the price
 *    actually offered, FADE only with a real under price.
 *  - The universal gate (availability -> input quality -> edge) decides the
 *    final tag; estimated inputs can never be STAB / FADE.
 */
import { forcePassIfUnavailable, AvailabilityStatus, InputsSource } from '../lib/availability';
import { priceMarket, DEFAULT_ONE_SIDED_HOLD } from '../lib/odds';
import { nbinomPmfR, lineProbsFromPmf, LineProbs } from './dist';
import {
  NhlPlayerSnapshot,
  NhlSkaterProjection,
  NhlMarketProjection,
  NhlMarket,
  NhlTeamFactors
} from '../types/nhl';

export const NHL_CONFIG = {
  version: 'sog_v2',
  sog: {
    /** dispersion carried over from sog_v1 (frozen) */
    r: 15.13,
    /** pseudo-games of prior-season evidence behind the current-season rate */
    shrinkK: 20,
    /** pseudo-games of position prior behind the prior-season rate */
    priorK: 20,
    /** position priors (shots / game) used only when data is thin */
    posPrior: { F: 2.0, D: 1.6 } as Record<'F' | 'D', number>,
    lines: [1.5, 2.5, 3.5, 4.5, 5.5]
  },
  pts: {
    /** PRIOR, not fitted: points per game are nearly Poisson; calibrate on the ledger */
    r: 12,
    shrinkK: 40,
    priorK: 40,
    posPrior: { F: 0.45, D: 0.25 } as Record<'F' | 'D', number>,
    lines: [0.5, 1.5, 2.5]
  },
  /** pseudo-games behind a team's shots/goals-against rate */
  teamShrinkK: 15,
  factorClamp: [0.8, 1.25] as [number, number],
  /** a skater needs this many (current + prior) games for REAL inputs */
  minGamesReal: 15,
  edgeMinPts: 5.0,
  maxChalk: -200,
  oneSidedHold: DEFAULT_ONE_SIDED_HOLD,
  /** half weight on the stale hand-typed opponent table */
  staticFactorWeight: 0.5
};

/**
 * Hand-typed opponent shots-allowed multipliers from sog_v1. They are old
 * and unsourced, so they are ONLY used (at half weight) when the live team
 * table could not be loaded, and the UI says so.
 */
export const NHL_STATIC_OPP_SOG: Record<string, number> = {
  ANA: 1.14, SJS: 1.18, CHI: 1.11, CBJ: 1.09, MTL: 1.08,
  OTT: 1.04, BUF: 1.03, UTA: 1.02, DET: 1.01,
  VAN: 1.00, EDM: 0.98, TOR: 0.96, BOS: 0.94, NYR: 0.95,
  VGK: 0.93, CAR: 0.88, NJD: 0.91, COL: 0.95, FLA: 0.92,
  TBL: 0.97, DAL: 0.92, WPG: 0.93, LAK: 0.89, MIN: 0.97,
  NSH: 0.96, CGY: 0.99, STL: 1.02, PIT: 1.01, WSH: 0.99,
  PHI: 0.98, NYI: 1.02, SEA: 0.96
};

const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

/* ------------------------------------------------------------------ */
/* Shrinkage                                                           */
/* ------------------------------------------------------------------ */

export interface ShrunkRate {
  mu0: number;
  /** effective games of evidence (current + discounted prior) */
  nEff: number;
}

/**
 * Bayesian chain: posterior(prior season | position prior) is the prior for
 * the current season. rate = (n*cur + K*prior) / (n + K).
 */
export function shrinkRate(args: {
  gp: number;
  total: number;
  priorGp?: number;
  priorTotal?: number | null;
  posPrior: number;
  shrinkK: number;
  priorK: number;
}): ShrunkRate {
  const gp = Math.max(0, args.gp || 0);
  const priorGp = Math.max(0, args.priorGp || 0);
  const priorTotal = args.priorTotal ?? 0;
  const priorRate = (priorTotal + args.priorK * args.posPrior) / (priorGp + args.priorK);
  const mu0 = (args.total + args.shrinkK * priorRate) / (gp + args.shrinkK);
  // effective evidence: games played plus the part of the prior season that actually carries weight
  return { mu0, nEff: gp + Math.min(priorGp, args.shrinkK) };
}

export function skaterBaseRate(p: NhlPlayerSnapshot, market: NhlMarket): ShrunkRate | null {
  if (market === 'sog') {
    return shrinkRate({
      gp: p.gp,
      total: p.shots,
      priorGp: p.priorGp,
      priorTotal: p.priorShots ?? 0,
      posPrior: NHL_CONFIG.sog.posPrior[p.pos],
      shrinkK: NHL_CONFIG.sog.shrinkK,
      priorK: NHL_CONFIG.sog.priorK
    });
  }
  if (p.points === null || p.points === undefined) return null;
  return shrinkRate({
    gp: p.gp,
    total: p.points,
    priorGp: p.priorGp,
    priorTotal: p.priorPoints ?? 0,
    posPrior: NHL_CONFIG.pts.posPrior[p.pos],
    shrinkK: NHL_CONFIG.pts.shrinkK,
    priorK: NHL_CONFIG.pts.priorK
  });
}

/** REAL only with a live feed and enough games; otherwise ESTIMATED (cannot be STAB/FADE). */
export function classifyInputs(p: NhlPlayerSnapshot, live: boolean): InputsSource {
  if (!live) return 'ESTIMATED';
  const games = (p.gp || 0) + (p.priorGp || 0);
  return games >= NHL_CONFIG.minGamesReal ? 'REAL' : 'ESTIMATED';
}

/* ------------------------------------------------------------------ */
/* Opponent factors                                                    */
/* ------------------------------------------------------------------ */

export interface TeamRates {
  gp: number;
  shotsAgainstPerGame: number | null;
  goalsAgainstPerGame: number | null;
}

/** ratio vs league, shrunk toward 1 by games played */
export function shrunkFactor(teamRate: number, leagueRate: number, gp: number): number {
  if (!(teamRate > 0) || !(leagueRate > 0)) return 1;
  const w = gp / (gp + NHL_CONFIG.teamShrinkK);
  const f = 1 + (teamRate / leagueRate - 1) * w;
  return clamp(f, NHL_CONFIG.factorClamp[0], NHL_CONFIG.factorClamp[1]);
}

/** Build per-team opponent factors from a live team table. */
export function buildTeamFactors(table: Record<string, TeamRates>): Record<string, NhlTeamFactors> {
  const teams = Object.entries(table).filter(([, t]) => t.gp > 0);
  const league = (pick: (t: TeamRates) => number | null) => {
    let num = 0, den = 0;
    for (const [, t] of teams) {
      const v = pick(t);
      if (v !== null && v > 0) { num += v * t.gp; den += t.gp; }
    }
    return den > 0 ? num / den : 0;
  };
  const lgSog = league(t => t.shotsAgainstPerGame);
  const lgGoals = league(t => t.goalsAgainstPerGame);
  const out: Record<string, NhlTeamFactors> = {};
  for (const [abbr, t] of teams) {
    out[abbr] = {
      sog: t.shotsAgainstPerGame ? shrunkFactor(t.shotsAgainstPerGame, lgSog, t.gp) : 1,
      pts: t.goalsAgainstPerGame ? shrunkFactor(t.goalsAgainstPerGame, lgGoals, t.gp) : 1,
      source: 'live'
    };
  }
  return out;
}

export function opponentFactors(opp: string, live?: Record<string, NhlTeamFactors>): NhlTeamFactors {
  const key = (opp || '').toUpperCase();
  if (live && live[key]) return live[key];
  const st = NHL_STATIC_OPP_SOG[key];
  if (st !== undefined) {
    return { sog: 1 + (st - 1) * NHL_CONFIG.staticFactorWeight, pts: 1, source: 'static' };
  }
  return { sog: 1, pts: 1, source: 'none' };
}

/* ------------------------------------------------------------------ */
/* Distribution                                                        */
/* ------------------------------------------------------------------ */

export function nbinomPmf(k: number, mu: number, r: number = NHL_CONFIG.sog.r): number {
  if (k < 0 || mu <= 0) return 0;
  return nbinomPmfR(k, mu, r);
}

/** P(Y > line) for a half line (kept for compatibility with v1 call sites). */
export function pOverLine(line: number, mu: number, r: number = NHL_CONFIG.sog.r): number {
  const probs = lineProbsFromPmf(k => nbinomPmf(k, mu, r), line);
  return Math.min(Math.max(probs.p_over, 1e-6), 1 - 1e-6);
}

export function priceLine(mu: number, r: number, line: number): LineProbs {
  return lineProbsFromPmf(k => nbinomPmf(k, mu, r), line);
}

function projectMarket(
  p: NhlPlayerSnapshot,
  market: NhlMarket,
  oppFactor: number
): NhlMarketProjection | null {
  const rate = skaterBaseRate(p, market);
  if (!rate) return null;
  const cfg = NHL_CONFIG[market];
  const mu = Math.max(0.02, rate.mu0 * oppFactor);
  const probs: Record<number, LineProbs> = {};
  for (const l of cfg.lines) probs[l] = priceLine(mu, cfg.r, l);
  const defaultLine = cfg.lines.reduce((best, l) =>
    Math.abs(probs[l].p_over - 0.5) < Math.abs(probs[best].p_over - 0.5) ? l : best, cfg.lines[0]);
  return {
    market,
    mu0: rate.mu0,
    nEff: rate.nEff,
    oppFactor,
    mu,
    r: cfg.r,
    lines: cfg.lines,
    defaultLine,
    probs
  };
}

export function projectNhlSkater(
  player: NhlPlayerSnapshot,
  oppTeam: string,
  liveFactors?: Record<string, NhlTeamFactors>
): NhlSkaterProjection {
  const f = opponentFactors(oppTeam, liveFactors);
  const sog = projectMarket(player, 'sog', f.sog)!;
  const pts = projectMarket(player, 'pts', f.pts);
  return {
    playerId: player.playerId,
    name: player.name,
    team: player.team,
    opp: (oppTeam || '').toUpperCase(),
    pos: player.pos,
    toiAvg: player.toiAvg,
    recentShots: player.recentShots || [],
    recentPoints: player.recentPoints || [],
    oppSource: f.source,
    sog,
    pts,
    availability: player.availability ?? 'UNKNOWN',
    inputsSource: player.inputsSource ?? 'ESTIMATED'
  };
}

/* ------------------------------------------------------------------ */
/* Odds + decision                                                     */
/* ------------------------------------------------------------------ */

export function parseAmericanOdds(input: string | number | null | undefined): number | null {
  if (input === null || input === undefined || input === '') return null;
  const raw = String(input).trim().replace(/[−–—]/g, '-').replace(/^\+/, '');
  const n = Number(raw);
  if (!Number.isFinite(n) || Math.abs(n) < 100) return null;
  return Math.round(n);
}

export interface NhlDecisionInput {
  pOver: number;
  pUnder: number;
  pPush?: number;
  over: number | null | undefined;
  under: number | null | undefined;
  edgeMinPts?: number;
  /** worst acceptable favourite price, e.g. -200 */
  maxChalk?: number;
  availability?: AvailabilityStatus;
  inputsSource?: InputsSource;
  hold?: number;
}

export interface NhlDecision {
  tag: 'STAB' | 'FADE' | 'PASS';
  side: 'over' | 'under' | null;
  /** edge in percentage points on the tagged side (best priced side when PASS) */
  edge: number;
  ev: number | null;
  edgeOver: number | null;
  edgeUnder: number | null;
  evOver: number | null;
  evUnder: number | null;
  fairOver: number | null;
  twoWay: boolean;
  hasMarket: boolean;
  reason: string;
}

const pct = (x: number) => `${x >= 0 ? '+' : ''}${x.toFixed(1)}pp`;

export function evaluateNhlMarket(inp: NhlDecisionInput): NhlDecision {
  const edgeMin = inp.edgeMinPts ?? NHL_CONFIG.edgeMinPts;
  const maxChalk = inp.maxChalk ?? NHL_CONFIG.maxChalk;
  const price = priceMarket(inp.over ?? null, inp.under ?? null, inp.hold ?? NHL_CONFIG.oneSidedHold);
  const base: NhlDecision = {
    tag: 'PASS', side: null, edge: 0, ev: null,
    edgeOver: null, edgeUnder: null, evOver: null, evUnder: null,
    fairOver: null, twoWay: false, hasMarket: false, reason: ''
  };

  if (!price) {
    const gated = forcePassIfUnavailable('PASS', 'No market odds entered', inp.availability ?? 'ACTIVE', inp.inputsSource ?? 'REAL');
    return { ...base, reason: gated.reason };
  }

  // pushes (integer lines) are removed from both sides: the bet is refunded
  const push = inp.pPush ?? 0;
  const live = Math.max(1e-9, 1 - push);
  const pOver = inp.pOver / live;
  const pUnder = inp.pUnder / live;

  const edgeOver = price.over ? (pOver - price.fairOver) * 100 : null;
  const edgeUnder = price.under ? (pUnder - price.fairUnder) * 100 : null;
  const evOver = price.over ? pOver * price.over.dec - 1 : null;
  const evUnder = price.under ? pUnder * price.under.dec - 1 : null;

  const overOk = price.over !== null && edgeOver !== null && edgeOver >= edgeMin && (evOver ?? -1) > 0 &&
    !(price.over.us < 0 && price.over.us < maxChalk);
  const underOk = price.under !== null && edgeUnder !== null && edgeUnder >= edgeMin && (evUnder ?? -1) > 0 &&
    !(price.under.us < 0 && price.under.us < maxChalk);

  let wants: 'STAB' | 'FADE' | null = null;
  let side: 'over' | 'under' | null = null;
  if (overOk && underOk) side = (evOver ?? 0) >= (evUnder ?? 0) ? 'over' : 'under';
  else if (overOk) side = 'over';
  else if (underOk) side = 'under';
  if (side) wants = side === 'over' ? 'STAB' : 'FADE';

  // best priced side, shown on the row even when it does not qualify
  const shownSide: 'over' | 'under' | null =
    side ?? (edgeOver !== null && (edgeUnder === null || edgeOver >= edgeUnder) ? 'over' : edgeUnder !== null ? 'under' : null);
  const shownEdge = shownSide === 'over' ? edgeOver : shownSide === 'under' ? edgeUnder : 0;
  const shownEv = shownSide === 'over' ? evOver : shownSide === 'under' ? evUnder : null;

  let reason: string;
  if (wants) {
    const o = side === 'over' ? price.over! : price.under!;
    reason =
      `${side === 'over' ? 'Over' : 'Under'} ${o.us > 0 ? '+' : ''}${o.us}: model beats the de-vigged price by ${pct(shownEdge ?? 0)}, ` +
      `EV ${((shownEv ?? 0) * 100).toFixed(1)}% at the offered price.` +
      (price.twoWay ? '' : ` One-sided price: assumed ${((price.hold - 1) * 100).toFixed(0)}% hold.`);
  } else if (shownSide === null) {
    reason = 'No usable price.';
  } else if ((shownEdge ?? 0) >= edgeMin && (shownEv ?? 0) <= 0) {
    reason = `Edge ${pct(shownEdge ?? 0)} does not survive the vig (EV ${((shownEv ?? 0) * 100).toFixed(1)}%).`;
  } else if ((shownEdge ?? 0) >= edgeMin) {
    reason = `Edge ${pct(shownEdge ?? 0)} on the ${shownSide} disqualified: price is worse than ${maxChalk} chalk.`;
  } else if (price.over && !price.under && (edgeOver ?? 0) <= -edgeMin) {
    reason = `Model is ${Math.abs(edgeOver ?? 0).toFixed(1)}pp below the over price, but the under is not priced — enter it to qualify a FADE.`;
  } else {
    reason = `Within neutral margin (${pct(shownEdge ?? 0)}).`;
  }

  // Universal gate: availability -> input quality -> edge
  const gated = forcePassIfUnavailable(
    wants ? 'BET' : 'PASS',
    reason,
    inp.availability ?? 'UNKNOWN',
    inp.inputsSource ?? 'ESTIMATED',
    { requireKnownAvailability: true }
  );
  const final = gated.status === 'BET' && wants ? wants : 'PASS';

  return {
    tag: final,
    side: final === 'PASS' ? null : side,
    edge: shownEdge ?? 0,
    ev: shownEv,
    edgeOver, edgeUnder, evOver, evUnder,
    fairOver: price.fairOver,
    twoWay: price.twoWay,
    hasMarket: true,
    reason: gated.reason
  };
}

/* ------------------------------------------------------------------ */
/* Grading                                                             */
/* ------------------------------------------------------------------ */

export function gradeActual(actual: number, line: number): 'OVER' | 'UNDER' | 'PUSH' {
  if (actual > line) return 'OVER';
  if (actual < line) return 'UNDER';
  return 'PUSH';
}

/** Units won (+) or lost (-) per 1u on the tagged side; 0 on push / void / unqualified. */
export function ledgerUnits(row: {
  tag: 'STAB' | 'FADE' | 'PASS';
  side: 'over' | 'under' | null;
  result: 'OVER' | 'UNDER' | 'PUSH' | 'VOID' | null;
  overOdds: number | null;
  underOdds: number | null;
}): number | null {
  if (row.tag === 'PASS' || !row.side || row.result === null) return null;
  if (row.result === 'PUSH' || row.result === 'VOID') return 0;
  const odds = row.side === 'over' ? row.overOdds : row.underOdds;
  if (odds === null) return null;
  const dec = odds > 0 ? 1 + odds / 100 : 1 + 100 / -odds;
  const won = (row.side === 'over' && row.result === 'OVER') || (row.side === 'under' && row.result === 'UNDER');
  return won ? dec - 1 : -1;
}
