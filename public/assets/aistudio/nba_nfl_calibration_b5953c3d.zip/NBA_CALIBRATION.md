# NBA Calibration Updates

## Goal
Bring NBA closer to the NHL MoneyPuck style: regular walk-forward fit, stronger opponent/pace adjustment, and better minutes handling.

## Changes
1. Refresh the existing fit (`fit_nba.py`) on the latest seasons every 1–2 weeks.
2. In the projection:
   - Keep per-minute rate shrinkage.
   - Increase weight on last-5 games for high-minute players (usage > ~28 min).
   - Apply opponent defensive rating and pace factors more consistently.
3. Edge gate remains the same: only tag a side when a real price exists and EV is positive.

## Why
NBA already has the infrastructure. The main gap vs NHL is that the fit is not being refreshed as regularly, and minutes/opponent adjustments need to stay current. This reduces the volume of high-% unusable Unders.
