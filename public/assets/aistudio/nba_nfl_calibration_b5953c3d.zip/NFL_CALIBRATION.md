# NFL Receptions Calibration Updates

## Goal
Make the mean more opportunity-driven (targets) instead of pure recent receptions, then blend lightly.

## Changes
1. Primary mean = player target share × projected team pass attempts (from the existing dropback model).
2. Blend: 70% target-driven + 30% recent receptions/game (last 3–4 games).
3. Add walk-forward team-context features already tested in nfl_features_exp.py (pass EPA, success rate, neutral-script pass rate).
4. Fit the blend weight and dispersion on walk-forward data the same way NHL fits shrinkK and r.
5. Keep the existing -150 chalk ceiling and two-way de-vig edge gate.

## Why
Targets are a stronger predictor than past receptions. Pure recent form misses game script and opportunity. This is the highest-ROI change available from nflverse data.
