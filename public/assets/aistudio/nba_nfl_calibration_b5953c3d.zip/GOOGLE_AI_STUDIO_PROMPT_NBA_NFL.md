# Prompt: NBA + NFL Calibration Updates

Update the Gatekeep models with these calibration changes. NHL stays unchanged for now.

## NBA
- Ensure the walk-forward fit from fit_nba.py is the source of shrink, opponent, and absence parameters.
- In nba_engine.ts, increase the influence of last-5 games for players projected ≥28 minutes.
- Apply opponent defensive rating and pace factors consistently in the mu calculation.
- Keep the existing edge gate (only tag when price exists and EV > 0).

## NFL Receptions
- Change the structural mean to be primarily target-driven:
  mu_target = target_share × projected_team_pass_attempts
- Blend: mu = 0.70 × mu_target + 0.30 × recent_receptions_per_game
- Incorporate the team-context features from the nfl_experiments (pass EPA, success rate, neutral pass rate) as multiplicative adjustments.
- Fit or set dispersion similarly to the current position-specific alpha.
- Keep the chalk ceiling and two-way pricing.

## Output
Provide the updated sections of nba_engine.ts and nfl_engine.ts with the changes clearly commented.
Keep all existing edge-gate and grading logic intact.
