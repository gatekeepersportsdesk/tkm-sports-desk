import React, { useState } from 'react';
import { NbaMarket, NBA_MARKETS, NbaOddsEntry, NbaPlayerProjection, NbaSettings, nbaOddsKey, NBA_MARKET_UNIT } from '../../types/nba';
import { NbaMatchup, NbaOddsMap, evalNbaRow } from '../../lib/nba_board';
import { NbaPlayerRow } from './NbaPlayerRow';
import { Calendar } from 'lucide-react';

interface Props {
  date: string;
  setDate: (d: string) => void;
  games: NbaMatchup[];
  projections: NbaPlayerProjection[];
  market: NbaMarket;
  setMarket: (m: NbaMarket) => void;
  oddsMap: NbaOddsMap;
  settings: NbaSettings;
  setShowStabsOnly: (v: boolean) => void;
  onOddsChange: (market: NbaMarket, playerId: number, line: number, side: 'over' | 'under', val: number | null) => void;
  onLogRows: () => void;
  onOpenScreenshotUpload: () => void;
  statusLines: string[];
}

export const NbaDesk: React.FC<Props> = ({
  date, setDate, games, projections, market, setMarket, oddsMap, settings,
  setShowStabsOnly, onOddsChange, onLogRows, onOpenScreenshotUpload, statusLines
}) => {
  const [selectedGameId, setSelectedGameId] = useState<string | 'ALL'>('ALL');
  const [lines, setLines] = useState<Record<string, number>>({});

  const entryFor = (m: NbaMarket, id: number, line: number): NbaOddsEntry | undefined => oddsMap[nbaOddsKey(m, id, line)];
  // explicit pick > first line that has a price entered > the line closest to 50/50
  const lineFor = (p: NbaPlayerProjection) => {
    const picked = lines[`${market}:${p.playerId}`];
    if (picked !== undefined) return picked;
    const mp = p.markets[market];
    const priced = mp.lines.find(l => { const e = entryFor(market, p.playerId, l); return e && (e.over != null || e.under != null); });
    return priced ?? mp.defaultLine;
  };
  const tagOf = (p: NbaPlayerProjection) => evalNbaRow(p, market, lineFor(p), entryFor(market, p.playerId, lineFor(p)), settings).decision.tag;
  const plays = projections.filter(p => tagOf(p) !== 'PASS').length;

  const visible = projections
    .filter(p => {
      if (selectedGameId !== 'ALL' && p.gameId !== selectedGameId) return false;
      if (settings.showStabsOnly && tagOf(p) === 'PASS') return false;
      return true;
    })
    .sort((a, b) => b.markets[market].mu - a.markets[market].mu);
  const gameIndex = React.useMemo(() => {
    const m = new Map<string, NbaPlayerProjection[]>();
    projections.forEach(p => { const k = p.gameId ?? ''; (m.get(k) || m.set(k, []).get(k)!).push(p); });
    return m;
  }, [projections]);
  const priced = Object.values(oddsMap).filter(e => e.over != null || e.under != null).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121824] p-3.5 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-[#8b97ac] font-mono">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="bg-[#0b0f14] border border-[#222d3e] px-2.5 py-1 rounded-lg text-white font-mono text-xs outline-none focus:border-cyan-400" />
          </div>

          <div className="flex items-center gap-1 bg-[#0f1520] p-1 rounded-xl border border-[#222d3e]">
            {NBA_MARKETS.map(m => (
              <button key={m} onClick={() => setMarket(m)}
                className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${market === m ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-[#8b97ac] hover:text-white'}`}>
                {NBA_MARKET_UNIT[m]}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button onClick={() => setSelectedGameId('ALL')}
              className={`px-3 py-1 rounded-full text-xs font-mono cursor-pointer ${selectedGameId === 'ALL' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'}`}>
              All ({projections.length})
            </button>
            {games.map(g => (
              <button key={g.gameId} onClick={() => setSelectedGameId(g.gameId)}
                className={`px-3 py-1 rounded-full text-xs font-mono whitespace-nowrap cursor-pointer ${selectedGameId === g.gameId ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'}`}>
                {g.away} @ {g.home}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <label className="flex items-center gap-1.5 text-xs font-mono text-[#8b97ac] cursor-pointer">
            <input type="checkbox" checked={settings.showStabsOnly} onChange={e => setShowStabsOnly(e.target.checked)} className="accent-cyan-400" />
            Qualifying only ({plays})
          </label>
          <button onClick={onLogRows} disabled={!priced}
            className="px-3.5 py-1.5 bg-emerald-900/60 hover:bg-emerald-800/70 disabled:opacity-40 text-emerald-200 border border-emerald-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer"
            title="Snapshot every priced row (model P + market price) so it can be graded from the real box score">
            Log priced rows ({priced})
          </button>
          <button onClick={onOpenScreenshotUpload}
            className="px-3.5 py-1.5 bg-[#182232] hover:bg-[#222d3e] text-cyan-300 border border-cyan-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer">
            📷 Upload Lines Screenshot
          </button>
        </div>
      </div>

      {statusLines.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {statusLines.map(s => (
            <span key={s} className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-cyan-950/60 border border-cyan-700/60 text-cyan-300">{s}</span>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {visible.length === 0 ? (
          <div className="p-8 text-center text-[#556277] bg-[#121824] rounded-2xl border border-[#222d3e] font-mono text-xs">
            {games.length === 0
              ? 'No NBA games loaded for this date (schedule feed unreachable or no games). Nothing is invented offline.'
              : 'No players match the current filter.'}
          </div>
        ) : visible.map(p => (
          <NbaPlayerRow
            key={`${p.playerId}_${p.gameId}`}
            projection={p}
            gamePlayers={gameIndex.get(p.gameId ?? '') ?? [p]}
            market={market}
            entryFor={entryFor}
            settings={settings}
            selectedLine={lineFor(p)}
            onOddsChange={onOddsChange}
            onSelectLine={(m, id, l) => setLines(prev => ({ ...prev, [`${m}:${id}`]: l }))}
          />
        ))}
      </div>
    </div>
  );
};
