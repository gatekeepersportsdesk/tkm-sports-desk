import React, { useState, useEffect } from 'react';
import { Header, ActiveSport } from './components/Header';
import { ErrorBoundary } from './components/common/ErrorBoundary';

// NFL components & data
import { NflDesk } from './components/nfl/NflDesk';
import { NflScoreboard } from './components/nfl/NflScoreboard';
import { NflImportModal } from './components/nfl/NflImportModal';
import { NflGradeModal } from './components/nfl/NflGradeModal';
import { generateInitialNflSnapshots, NFL_PLAYERS, NFL_GAMES } from './data/nfl_seed';
import { parseOdds, applyGameCap } from './model/nfl_engine';
import { importNflLines, NflImportContext } from './lib/nfl_import';
import { normalizePlayerName } from './lib/nflverse';
import { NflPropSnapshot, NflActualRecord, NflBetRecord, NflGameContext, NflPlayerStats } from './types/nfl';

// MLB components & data
import { MlbDesk } from './components/mlb/MlbDesk';
import { MlbParlayPicker } from './components/mlb/MlbParlayPicker';
import { MlbLedger } from './components/mlb/MlbLedger';
import { MlbSettings } from './components/mlb/MlbSettings';
import { fetchBoxResults, gradeLedger } from './lib/mlb_grade';
import { loadDated, saveDated } from './lib/dated_store';
import { fuzzyMatchName } from './lib/availability';
import { MLB_DEFAULT_TUNE, devigMlb } from './model/mlb_engine';
import { MlbLedgerRow, MlbBatterInput, MlbGateResult, MlbGameMatchup } from './types/mlb';

// NHL components & data
import { NhlDesk } from './components/nhl/NhlDesk';
import { NhlScoreboard } from './components/nhl/NhlScoreboard';
import { NhlSettingsModal } from './components/nhl/NhlSettingsModal';
// NBA components & data
import { NbaDesk } from './components/nba/NbaDesk';
import { NbaScoreboard } from './components/nba/NbaScoreboard';
import { NbaSettingsModal } from './components/nba/NbaSettingsModal';
import { NBA_CONFIG, applyNbaTuning, NbaTuning, NBA_TUNING_DEFAULTS } from './model/nba_engine';
import { NbaLedgerRow, NbaMarket, NbaSettings, nbaOddsKey } from './types/nba';
import { buildNbaSlate, collectNbaLedgerRows, mergeNbaLedger, inferNbaMarket, withOddsLines, NbaOddsMap } from './lib/nba_board';
import { fetchNbaState, fetchNbaSchedule, fetchNbaInjuries, fetchNbaActuals, gradeNbaLedger, NbaGame, NbaInjury, NbaState } from './lib/nba_data';
import { buildEstimatedNhlSkater } from './data/nhl_seed';
import { projectNhlSkater, NHL_CONFIG, applyNhlTuning, NhlTuning, NHL_TUNING_DEFAULTS } from './model/nhl_engine';
import { NhlLedgerRow, NhlGameMatchup, NhlMarket, NhlOddsMap, NhlPlayerSnapshot, NhlSettings, NhlTeamFactors, nhlOddsKey } from './types/nhl';
import { collectLedgerRows, mergeLedger, inferNhlMarket, marketOf } from './lib/nhl_board';

// Live schedules & Screenshot Scanner
import { fetchLiveMlbGames } from './lib/live_schedule';
import { fetchNflSlate, gamesById, fetchNflGrades } from './lib/live_nfl';
import {
  fetchNhlSchedule, fetchNhlTeam, fetchNhlFactors, fetchNhlInjuries, fetchNhlBoxes,
  normalizeNhlTeam, applyInjuries, gradeNhlLedger, NhlInjury
} from './lib/nhl_data';
import { parseOdds as parseOddsShared } from './lib/odds';
import { ScreenshotUploadModal, ExtractedPropLine } from './components/common/ScreenshotUploadModal';
import { getTodayIsoDate } from './lib/dates';
import { installSessionDiagnostics, LoadDiagnosis } from './lib/session_diag';

export default function App() {
  // The selected sport / tab survive reloads, hot reloads and remounts (they used to reset to NFL).
  const NAV_KEY = 'gatekeep_nav_v1';
  const VALID_TABS: Record<ActiveSport, string[]> = {
    nfl: ['desk', 'import', 'grade', 'scoreboard'],
    mlb: ['desk', 'parlays', 'ledger', 'settings'],
    nhl: ['desk', 'scoreboard', 'settings'],
    nba: ['desk', 'scoreboard', 'settings']
  };
  const readNav = (): { sport: ActiveSport; tab: string } => {
    try {
      const v = JSON.parse(localStorage.getItem(NAV_KEY) || 'null');
      if (v && (v.sport === 'nfl' || v.sport === 'mlb' || v.sport === 'nhl' || v.sport === 'nba')) {
        return { sport: v.sport, tab: VALID_TABS[v.sport as ActiveSport].includes(v.tab) ? v.tab : 'desk' };
      }
    } catch { /* ignore */ }
    return { sport: 'nfl', tab: 'desk' };
  };
  const [activeSport, setActiveSport] = useState<ActiveSport>(() => readNav().sport);
  const [activeSubTab, setActiveSubTab] = useState<string>(() => readNav().tab);
  useEffect(() => {
    try { localStorage.setItem(NAV_KEY, JSON.stringify({ sport: activeSport, tab: activeSubTab })); } catch { /* ignore */ }
  }, [activeSport, activeSubTab]);

  // Why did the page just (re)load? Only a full reload can reset the app; this records the cause (see lib/session_diag.ts).
  const [loadDiag, setLoadDiag] = useState<LoadDiagnosis | null>(null);
  const [loadDiagDismissed, setLoadDiagDismissed] = useState(false);
  useEffect(() => {
    // Visible remount trace: if the whole App component remounts without a page reload, this counter jumps.
    try {
      const n = Number(sessionStorage.getItem('gk_app_mounts') || '0') + 1;
      sessionStorage.setItem('gk_app_mounts', String(n));
      console.info(`[gatekeep] App mounted (#${n} in this tab session). Navigation restored from storage: ${activeSport}/${activeSubTab}`);
    } catch { /* ignore */ }
    installSessionDiagnostics().then(setLoadDiag).catch(() => { /* diagnostics must never affect the app */ });
  }, []);

  // Universal Screenshot Modal state
  const [showScreenshotModal, setShowScreenshotModal] = useState(false);

  /* =========================================================================
     LIVE AUTO-PULLED SCHEDULES STATE
     ========================================================================= */
  const [nflLiveGames, setNflLiveGames] = useState<Record<string, NflGameContext>>(NFL_GAMES);
  const [nflLiveRosters, setNflLiveRosters] = useState<Record<string, NflPlayerStats[]>>({});
  const [nflInjuries, setNflInjuries] = useState<NflImportContext['injuries']>({});
  const [nflInjuriesAvailable, setNflInjuriesAvailable] = useState(false);
  const [nflMeta, setNflMeta] = useState<{ season: number; week: number } | null>(null);
  const [nflRosterStatus, setNflRosterStatus] = useState('loading NFL slate from nflverse…');
  const [mlbSlateNote, setMlbSlateNote] = useState('');
  const [mlbLiveGames, setMlbLiveGames] = useState<MlbGameMatchup[]>([]); // only official schedule
  const [nhlLiveGames, setNhlLiveGames] = useState<NhlGameMatchup[]>([]); // official NHL schedule only
  const [nhlSkatersByTeam, setNhlSkatersByTeam] = useState<Record<string, NhlPlayerSnapshot[]>>({});
  const [nhlFactors, setNhlFactors] = useState<Record<string, NhlTeamFactors> | null>(null);
  const [nhlInjuries, setNhlInjuries] = useState<NhlInjury[] | null>(null);
  const [nhlStatusLines, setNhlStatusLines] = useState<string[]>(['loading NHL slate…']);

  const [isLoadingSchedule, setIsLoadingSchedule] = useState(false);
  const [scheduleStatusText, setScheduleStatusText] = useState("Auto-synced today's games");

  /** nflverse slate: games + lines, receivers with walk-forward inputs, injury report. */
  const loadNflSlate = async (): Promise<number> => {
    setNflRosterStatus('loading NFL slate from nflverse…');
    const slate = await fetchNflSlate();
    if (!slate) {
      setNflRosterStatus('nflverse slate unavailable — nothing is priced from guesses; rows stay model-only/ESTIMATED');
      return 0;
    }
    const players = slate.receivers || {};
    setNflLiveGames(gamesById(slate.games));
    setNflLiveRosters(players);
    setNflInjuries(slate.injuries || {});
    setNflInjuriesAvailable(Boolean(slate.injuriesAvailable));
    setNflMeta({ season: slate.season, week: slate.week });
    const n = Object.values(players).reduce((a, b) => a + (b?.length || 0), 0);
    setNflRosterStatus(
      `week ${slate.week} · inputs through week ${slate.asOfWeek} · ${n} receivers · ratios WR ${slate.ratios.WR.ratio.toFixed(3)} / TE ${slate.ratios.TE.ratio.toFixed(3)}` +
      (slate.injuriesAvailable ? '' : ' · NO injury report (availability UNKNOWN)') +
      (slate.warnings?.length ? ` · ${slate.warnings.join(' ')}` : '')
    );
    return slate.games.length;
  };

  const refreshAllSchedules = async () => {
    setIsLoadingSchedule(true);
    setScheduleStatusText("Auto-pulling today's games from sports feeds...");
    try {
      const [nflN, mlb] = await Promise.all([
        loadNflSlate(),
        fetchLiveMlbGames()
      ]);
      setMlbLiveGames(mlb || []); // empty official day → empty board, not seed
      setMlbSlateNote((mlb || []).length === 0
        ? 'No MLB games on the official schedule for today (or the schedule feed is unreachable) — nothing is shown or priced.'
        : `MLB slate: ${mlb.length} game(s) · ${mlb.filter(g => g.confirmed).length} with posted lineups`);
      setScheduleStatusText(`Live games updated: ${nflN} NFL, ${mlb?.length || 0} MLB (NHL loads from its own tab date)`);
    } catch (e: any) {
      console.warn('Schedule sync warning:', e);
      setScheduleStatusText("Active game slate ready");
    } finally {
      setIsLoadingSchedule(false);
    }
  };

  // Auto-pull live games on load
  useEffect(() => {
    refreshAllSchedules();
  }, []);

  /* =========================================================================
     NFL STATE & HANDLERS
     ========================================================================= */
  const [nflSnapshots, setNflSnapshots] = useState<NflPropSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_snapshots_v15');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return generateInitialNflSnapshots();
  });

  const [nflBets, setNflBets] = useState<Record<string, NflBetRecord>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_bets_v15');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  // keyed `${season}-${week}-${normalized name}`; starts empty (no demo grades)
  const [nflActuals, setNflActuals] = useState<Record<string, NflActualRecord>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_actuals_v15');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  const [showNflImportModal, setShowNflImportModal] = useState(false);
  const [showNflGradeModal, setShowNflGradeModal] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('gatekeep_nfl_snapshots_v15', JSON.stringify(nflSnapshots));
      localStorage.setItem('gatekeep_nfl_bets_v15', JSON.stringify(nflBets));
      localStorage.setItem('gatekeep_nfl_actuals_v15', JSON.stringify(nflActuals));
    } catch (e) {
      console.error(e);
    }
  }, [nflSnapshots, nflBets, nflActuals]);

  const nflImportCtx = (): NflImportContext => ({
    games: nflLiveGames,
    players: [...Object.values(nflLiveRosters).flat(), ...Object.values(NFL_PLAYERS)],
    injuries: nflInjuries,
    injuriesAvailable: nflInjuriesAvailable
  });

  const handleNflImport = (season: number, week: number, book: string, kind: 'pre' | 'open' | 'close', text: string) => {
    const res = importNflLines(text, season, week, book, kind, nflImportCtx(), nflSnapshots);
    setNflSnapshots(res.snapshots);
    const skipNote = res.skipped.length
      ? `\n\nSkipped ${res.skipped.length}:\n` + res.skipped.slice(0, 8).map(x => `• ${x.text} — ${x.reason}`).join('\n')
      : '';
    alert(`Priced ${res.imported} NFL prop(s).${skipNote}`);
  };

  const handleNflUpsertSnapshot = (snap: NflPropSnapshot) => {
    setNflSnapshots(prev => {
      const next = [...prev];
      const idx = next.findIndex(s => s.id === snap.id);
      if (idx >= 0) next[idx] = snap; else next.push(snap);
      return importNflLinesCap(next);
    });
  };

  const importNflLinesCap = (snaps: NflPropSnapshot[]) => applyGameCap(snaps);

  const setActual = (acc: Record<string, NflActualRecord>, season: number, week: number, player: string, rec: NflActualRecord) => {
    acc[`${season}-${week}-${normalizePlayerName(player)}`] = rec;
  };

  const handleNflCommitGrades = (season: number, week: number, text: string) => {
    const updated = { ...nflActuals };
    let graded = 0;
    text.split('\n').forEach(l => {
      const parts = l.split(/[\t|,]/).map(x => x.trim());
      if (parts.length < 2 || !parts[0]) return;
      const valStr = parts[1].toUpperCase();
      if (valStr === 'DNP' || valStr === 'VOID') {
        setActual(updated, season, week, parts[0], { played: false, actual: 0 });
        graded++;
      } else {
        const valNum = parseFloat(valStr);
        if (Number.isFinite(valNum) && valNum >= 0) {
          setActual(updated, season, week, parts[0], { played: true, actual: valNum });
          graded++;
        }
      }
    });
    setNflActuals(updated);
    alert(`Committed realized receptions for ${graded} players.`);
  };

  /** Real grading from nflverse final box data (no simulation). */
  const handleNflAutoGrade = async () => {
    const weeks = Array.from(new Set(nflSnapshots.filter(s => s.hasMarket !== false).map(s => `${s.season}-${s.week}`)));
    if (!weeks.length) { alert('No priced NFL lines to grade yet.'); return; }
    const updated = { ...nflActuals };
    let graded = 0, pending = 0, unavailable = 0;
    for (const sw of weeks) {
      const [season, week] = sw.split('-').map(Number);
      const g = await fetchNflGrades(season, week);
      if (!g) { unavailable++; continue; }
      const finals = new Set(g.finalTeams);
      nflSnapshots.filter(s => s.season === season && s.week === week && s.hasMarket !== false).forEach(s => {
        if (!finals.has(s.team)) { pending++; return; }
        const hit = g.actuals[normalizePlayerName(s.player)];
        setActual(updated, season, week, s.player, hit ? { played: true, actual: hit.actual } : { played: false, actual: 0 });
        graded++;
      });
    }
    setNflActuals(updated);
    alert(`Auto-graded ${graded} line(s) from nflverse; ${pending} still pending (game not final)` + (unavailable ? `; ${unavailable} week(s) could not be fetched.` : '.'));
  };

  const handleNflRecordBet = (snap: NflPropSnapshot) => {
    if (snap.hasMarket === false) { alert('Enter the book line and odds first.'); return; }
    const stakeStr = prompt(`Confirm 1.0u stake for ${snap.player} ${snap.lean} ${snap.line} (${snap.oddsOffered > 0 ? '+' : ''}${snap.oddsOffered}):`, "1.0");
    if (stakeStr === null) return;
    const stakeNum = parseFloat(stakeStr);
    if (isNaN(stakeNum) || stakeNum <= 0) return;

    setNflBets(prev => ({
      ...prev,
      [snap.id]: {
        snapshot_id: snap.id,
        side: snap.lean.toLowerCase() as 'over' | 'under',
        stake: stakeNum,
        odds_taken: snap.oddsOffered,
        placed_at: new Date().toISOString()
      }
    }));
  };

  const handleNflExportJson = () => {
    const blob = new Blob([JSON.stringify({ snapshots: nflSnapshots, bets: nflBets, actuals: nflActuals }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nfl_receptions_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  const handleNflImportJson = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.snapshots) setNflSnapshots(data.snapshots);
      if (data.bets) setNflBets(data.bets);
      if (data.actuals) setNflActuals(data.actuals);
      alert("NFL database synchronized successfully.");
    } catch (e: any) {
      alert("Invalid JSON format: " + e.message);
    }
  };

  const handleNflReset = () => {
    if (confirm("Clear the NFL desk (lines, bets and grades)?")) {
      setNflSnapshots([]);
      setNflBets({});
      setNflActuals({});
    }
  };

  /* =========================================================================
     MLB STATE & HANDLERS
     ========================================================================= */
  // Odds are per-day: yesterday's prices are never applied to today's board.
  const mlbToday = getTodayIsoDate();
  const [mlbOddsMap, setMlbOddsMap] = useState<Record<number, { over: string; under: string; line?: number }>>(
    () => loadDated('gatekeep_mlb_odds_v59', mlbToday, {})
  );

  const [mlbParlayLegs, setMlbParlayLegs] = useState<{
    id: number;
    name: string;
    team: string;
    calP: number;
    overPrice: string;
    gamePk: number;
    line: number;
    call: 'PLAY' | 'PASS';
    quality: string;
  }[]>([]);

  // Starts empty. (The old build shipped two hand-typed "graded" rows that flattered every metric.)
  const [mlbLedger, setMlbLedger] = useState<MlbLedgerRow[]>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_mlb_ledger_v59');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  const [mlbTune, setMlbTune] = useState(MLB_DEFAULT_TUNE);

  useEffect(() => {
    saveDated('gatekeep_mlb_odds_v59', mlbToday, mlbOddsMap);
    try {
      localStorage.setItem('gatekeep_mlb_ledger_v59', JSON.stringify(mlbLedger));
    } catch (e) {
      console.error(e);
    }
  }, [mlbOddsMap, mlbLedger]);

  const handleMlbOddsChange = (id: number, side: 'over' | 'under', val: string) => {
    setMlbOddsMap(prev => ({
      ...prev,
      [id]: {
        over: side === 'over' ? val : prev[id]?.over || '',
        under: side === 'under' ? val : prev[id]?.under || '',
        line: prev[id]?.line !== undefined ? prev[id].line : 0.5
      }
    }));
  };

  const handleMlbUpdateLine = (id: number, line: number) => {
    setMlbOddsMap(prev => ({
      ...prev,
      [id]: {
        over: prev[id]?.over || '',
        under: prev[id]?.under || '',
        line
      }
    }));
  };

  const handleMlbToggleParlay = (batter: MlbBatterInput, gate: MlbGateResult, price: { over: string; under: string; line?: number }) => {
    setMlbParlayLegs(prev => {
      const exists = prev.some(l => l.id === batter.id);
      if (exists) return prev.filter(l => l.id !== batter.id);
      if (prev.length >= 4) {
        alert("Maximum 4 legs on a custom parlay ticket.");
        return prev;
      }
      return [
        ...prev,
        {
          id: batter.id,
          name: batter.name,
          team: batter.team,
          calP: gate.calP,
          overPrice: price.over,
          gamePk: batter.gamePk,
          line: price.line ?? 0.5,
          call: gate.call,
          quality: gate.quality
        }
      ];
    });
  };

  const handleMlbLogAllPriced = (pricedRows: any[]) => {
    const today = getTodayIsoDate();
    const newRows: MlbLedgerRow[] = [...mlbLedger];
    let added = 0;
    let skipped = 0;

    pricedRows.forEach(r => {
      const line = r.price.line ?? 0.5;
      const exists = newRows.some(x => x.id === r.batter.id && x.date === today && (x.line ?? 0.5) === line);
      const devig = devigMlb(r.price.over, r.price.under);
      if (exists || !devig) { if (!exists) skipped++; return; }
      newRows.unshift({
        date: today,
        gamePk: r.game.gamePk,
        id: r.batter.id,
        name: r.batter.name,
        team: r.batter.team,
        slot: r.batter.slot,
        call: r.gate.call,
        over: r.price.over,
        under: r.price.under || '',
        hold: 1.07,
        dec: devig.dec,
        modelP: r.gate.modelP,          // P(over THIS line), pre-market-blend
        fairP: r.gate.fair,
        blendedP: r.gate.calP,
        edge: r.gate.edge,
        quality: r.gate.quality,
        hit: null,
        result: '',
        void: false,
        line,
        ev: r.gate.ev ?? null
      });
      added++;
    });

    setMlbLedger(newRows);
    alert(`Logged ${added} priced hitter row(s).` + (skipped ? ` ${skipped} skipped (unreadable odds).` : ''));
  };

  /** Real grading from official box scores. A row is graded only when its game is Final. */
  const handleMlbGradeOpenPlays = async () => {
    const open = mlbLedger.filter(r => r.hit === null && !r.void && !r.demo);
    if (!open.length) { alert('Nothing open to grade.'); return; }
    const results = await fetchBoxResults(Array.from(new Set(open.map(r => r.gamePk))));
    if (!results) { alert('Could not reach the MLB box-score feed — nothing was graded.'); return; }
    const g = gradeLedger(mlbLedger, results);
    setMlbLedger(g.rows);
    alert(`Graded ${g.graded} from final box scores; ${g.pending} still pending (game not final); ${g.voided} void (DNP/postponed).`);
  };

  const handleMlbExportCsv = () => {
    const header = "date,game_pk,id,name,team,slot,call,line,over,under,hold,dec,model_p,fair_p,blended_p,edge,ev,quality,hit,result,void,demo";
    const csvRows = mlbLedger.map(r => [
      r.date, r.gamePk, r.id, `"${r.name}"`, r.team, r.slot, r.call, r.line ?? 0.5, r.over, r.under, r.hold, r.dec,
      r.modelP, r.fairP, r.blendedP, r.edge, r.ev ?? '', r.quality, r.hit ?? '', r.result, r.void ? 1 : 0, r.demo ? 1 : 0
    ].join(','));
    const blob = new Blob([[header, ...csvRows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mlb_hits_ledger_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  /* =========================================================================
     NHL STATE & HANDLERS (sog_v2: shots + points)
     ========================================================================= */
  const NHL_ODDS_KEY = 'gatekeep_nhl_odds_v2';
  const NHL_LEDGER_KEY = 'gatekeep_nhl_ledger_v2';
  // The date you were looking at and the SOG/PTS toggle survive a page reload (per tab, so a new day still opens on today).
  const [nhlDate, setNhlDate] = useState<string>(() => {
    try { const v = sessionStorage.getItem('gk_nhl_date'); if (v && /^\d{4}-\d{2}-\d{2}$/.test(v)) return v; } catch { /* ignore */ }
    return getTodayIsoDate();
  });
  const [nhlMarket, setNhlMarket] = useState<NhlMarket>(() => {
    try { const v = sessionStorage.getItem('gk_nhl_market'); if (v === 'sog' || v === 'pts') return v; } catch { /* ignore */ }
    return 'sog';
  });
  useEffect(() => {
    try { sessionStorage.setItem('gk_nhl_date', nhlDate); sessionStorage.setItem('gk_nhl_market', nhlMarket); } catch { /* ignore */ }
  }, [nhlDate, nhlMarket]);
  // odds are stamped with the date they were entered for; another day's prices are discarded
  const [nhlOdds, setNhlOdds] = useState<{ date: string; map: NhlOddsMap }>(() => {
    const d = getTodayIsoDate();
    try { localStorage.removeItem('gatekeep_nhl_odds_map'); localStorage.removeItem('gatekeep_nhl_results'); } catch { /* ignore */ }
    return { date: d, map: loadDated<NhlOddsMap>(`${NHL_ODDS_KEY}_${d}`, d, {}) };
  });
  const [nhlLedger, setNhlLedger] = useState<NhlLedgerRow[]>(() => {
    try {
      const saved = localStorage.getItem(NHL_LEDGER_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) { console.error(e); }
    return [];
  });
  const [nhlGradeStatus, setNhlGradeStatus] = useState('');
  const [nhlExtraSkaters, setNhlExtraSkaters] = useState<NhlPlayerSnapshot[]>([]);
  // v2 stores ONLY the values you changed. v1 stored every default, which would pin old priors over newly fitted ones.
  const NHL_TUNING_KEY = 'gatekeep_nhl_tuning_v2';
  const [nhlTuning, setNhlTuning] = useState<NhlTuning>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(NHL_TUNING_KEY) || 'null');
      if (saved && typeof saved === 'object') return { ...NHL_TUNING_DEFAULTS, ...saved };
    } catch { /* ignore */ }
    return { ...NHL_TUNING_DEFAULTS };
  });
  useEffect(() => {
    try {
      const overrides: Partial<NhlTuning> = {};
      (Object.keys(nhlTuning) as (keyof NhlTuning)[]).forEach(k => { if (nhlTuning[k] !== NHL_TUNING_DEFAULTS[k]) overrides[k] = nhlTuning[k]; });
      localStorage.setItem(NHL_TUNING_KEY, JSON.stringify(overrides));
    } catch { /* ignore */ }
  }, [nhlTuning]);
  const [nhlSettings, setNhlSettings] = useState<NhlSettings>({
    edgeThreshold: NHL_CONFIG.edgeMinPts,
    maxJuice: NHL_CONFIG.maxChalk,
    showStabsOnly: false
  });

  useEffect(() => {
    setNhlOdds({ date: nhlDate, map: loadDated<NhlOddsMap>(`${NHL_ODDS_KEY}_${nhlDate}`, nhlDate, {}) });
  }, [nhlDate]);

  useEffect(() => {
    saveDated(`${NHL_ODDS_KEY}_${nhlOdds.date}`, nhlOdds.date, nhlOdds.map);
  }, [nhlOdds]);

  useEffect(() => {
    try { localStorage.setItem(NHL_LEDGER_KEY, JSON.stringify(nhlLedger)); } catch (e) { console.error(e); }
  }, [nhlLedger]);

  // Official schedule + live rosters/game logs + team table + injury report for the selected date.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setNhlStatusLines(['loading NHL slate…']);
      const games = await fetchNhlSchedule(nhlDate);
      if (cancelled) return;
      setNhlLiveGames(games);
      if (!games.length) {
        setNhlSkatersByTeam({});
        setNhlStatusLines(['no NHL games from the official schedule for this date (or the feed is unreachable)']);
        return;
      }
      const teams = Array.from(new Set(games.flatMap(g => [g.awayTeam, g.homeTeam])));
      const [factors, injuries, rosters] = await Promise.all([
        fetchNhlFactors(),
        fetchNhlInjuries(),
        Promise.all(teams.map(async t => [t, await fetchNhlTeam(t, nhlDate)] as const))
      ]);
      if (cancelled) return;
      const map = Object.fromEntries(rosters) as Record<string, NhlPlayerSnapshot[]>;
      setNhlSkatersByTeam(map);
      setNhlFactors(factors);
      setNhlInjuries(injuries);
      const n = Object.values(map).reduce((a, b) => a + b.length, 0);
      const missing = Object.entries(map).filter(([, v]) => !v.length).map(([k]) => k);
      setNhlStatusLines([
        n ? `${n} skaters from the NHL API${missing.length ? ` · missing ${missing.join(',')}` : ''}` : 'roster fetch failed — board is empty (no offline roster is invented)',
        factors ? 'opponent factors: live shots/goals-against' : 'opponent factors: stale static table at half weight (live team table not loaded)',
        injuries ? `ESPN injury report loaded (${injuries.length} listed)` : 'NO injury report — availability UNKNOWN, rows cannot qualify'
      ]);
    })().catch(err => {
      console.error(err);
      if (!cancelled) setNhlStatusLines(['NHL load failed']);
    });
    return () => { cancelled = true; };
  }, [nhlDate]);

  const nhlProjections = React.useMemo(() => {
    applyNhlTuning(nhlTuning); // the engine reads the live config; priors are user-overridable
    const list: ReturnType<typeof projectNhlSkater>[] = [];
    nhlLiveGames.forEach(g => {
      const away = normalizeNhlTeam(g.awayTeam);
      const home = normalizeNhlTeam(g.homeTeam);
      const withExtras = (team: string) => {
        const base = nhlSkatersByTeam[team] || [];
        const extras = nhlExtraSkaters.filter(x => x.team === team && !base.some(b => fuzzyMatchName(b.name, x.name)));
        return applyInjuries([...base, ...extras], nhlInjuries);
      };
      withExtras(away).forEach(p => list.push({ ...projectNhlSkater(p, home, nhlFactors ?? undefined), gameId: g.gameId }));
      withExtras(home).forEach(p => list.push({ ...projectNhlSkater(p, away, nhlFactors ?? undefined), gameId: g.gameId }));
    });
    return list;
  }, [nhlLiveGames, nhlSkatersByTeam, nhlExtraSkaters, nhlInjuries, nhlFactors, nhlTuning]);

  const handleNhlOddsChange = (market: NhlMarket, playerId: number, line: number, side: 'over' | 'under', val: number | null) => {
    setNhlOdds(prev => {
      const key = nhlOddsKey(market, playerId, line);
      const entry = { ...(prev.map[key] || {}), [side]: val };
      const next = { ...prev.map };
      if (entry.over == null && entry.under == null) delete next[key];
      else next[key] = entry;
      return { ...prev, map: next };
    });
  };

  const handleNhlLogRows = () => {
    const rows = collectLedgerRows(nhlProjections, nhlOdds.map, nhlSettings, nhlDate);
    if (!rows.length) { alert('No priced rows to log.'); return; }
    setNhlLedger(prev => mergeLedger(prev, rows));
    alert(`Logged ${rows.length} priced row(s) (${rows.filter(r => r.tag !== 'PASS').length} qualifying). Grade them from the Scoreboard after the games are final.`);
  };

  const handleNhlGrade = async () => {
    const pendingIds = Array.from(new Set(nhlLedger.filter(r => r.result === null && !r.demo).map(r => r.gameId)));
    if (!pendingIds.length) { setNhlGradeStatus('Nothing pending.'); return; }
    setNhlGradeStatus('Fetching official box scores…');
    const boxes = await fetchNhlBoxes(pendingIds);
    if (!boxes) { setNhlGradeStatus('Box score feed unreachable — nothing graded, nothing simulated.'); return; }
    const out = gradeNhlLedger(nhlLedger, boxes);
    setNhlLedger(out.rows);
    setNhlGradeStatus(`Graded ${out.graded} · void ${out.voided} · still pending ${out.pending} (games not final yet).`);
  };

  const handleNhlImportLedger = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr);
      const arr: any[] = Array.isArray(data) ? data : Array.isArray(data.results) ? data.results : Array.isArray(data.rows) ? data.rows : [];
      const rows: NhlLedgerRow[] = arr.map((r, i) =>
        r && r.id && r.market
          ? (r as NhlLedgerRow)
          : ({
              id: `legacy:${i}:${r?.date ?? ''}:${r?.playerId ?? ''}`,
              date: r?.date ?? '', gameId: 0, market: 'sog' as const, playerId: r?.playerId ?? 0,
              playerName: r?.playerName ?? '?', team: r?.team ?? '', opp: r?.opp ?? '', line: r?.line ?? 0,
              modelMu: r?.modelMu ?? 0, r: NHL_CONFIG.sog.r, probOver: r?.probOver ?? 0.5,
              overOdds: r?.oddsTaken ?? null, underOdds: null, pMarketOver: null, tag: 'PASS' as const, side: null,
              edge: 0, ev: null, inputsSource: 'ESTIMATED' as const, availability: 'UNKNOWN' as const,
              actual: r?.actualSog ?? null, result: null, demo: true
            })
      );
      setNhlLedger(prev => mergeLedger(prev, rows));
      alert(`Imported ${rows.length} row(s). Rows from older versions (no ids) are kept but marked DEMO and excluded from all metrics.`);
    } catch (e: any) {
      alert('Invalid JSON: ' + e.message);
    }
  };

  /* =========================================================================
     NBA STATE & HANDLERS (nba_v1: points, rebounds, assists, threes)
     ========================================================================= */
  const NBA_ODDS_KEY = 'gatekeep_nba_odds_v1';
  const NBA_LEDGER_KEY = 'gatekeep_nba_ledger_v1';
  const NBA_TUNING_KEY = 'gatekeep_nba_tuning_v1';
  const [nbaDate, setNbaDate] = useState<string>(() => {
    try { const v = sessionStorage.getItem('gk_nba_date'); if (v && /^\d{4}-\d{2}-\d{2}$/.test(v)) return v; } catch { /* ignore */ }
    return getTodayIsoDate();
  });
  const [nbaMarket, setNbaMarket] = useState<NbaMarket>(() => {
    try { const v = sessionStorage.getItem('gk_nba_market'); if (v === 'pts' || v === 'reb' || v === 'ast' || v === 'tpm') return v; } catch { /* ignore */ }
    return 'pts';
  });
  useEffect(() => {
    try { sessionStorage.setItem('gk_nba_date', nbaDate); sessionStorage.setItem('gk_nba_market', nbaMarket); } catch { /* ignore */ }
  }, [nbaDate, nbaMarket]);
  const [nbaOdds, setNbaOdds] = useState<{ date: string; map: NbaOddsMap }>(() => {
    const d = nbaDate;
    return { date: d, map: loadDated<NbaOddsMap>(`${NBA_ODDS_KEY}_${d}`, d, {}) };
  });
  const [nbaLedger, setNbaLedger] = useState<NbaLedgerRow[]>(() => {
    try { const saved = localStorage.getItem(NBA_LEDGER_KEY); if (saved) return JSON.parse(saved); } catch { /* ignore */ }
    return [];
  });
  const [nbaGradeStatus, setNbaGradeStatus] = useState('');
  const [nbaGames, setNbaGames] = useState<NbaGame[]>([]);
  const [nbaState, setNbaState] = useState<NbaState | null>(null);
  const [nbaInjuries, setNbaInjuries] = useState<NbaInjury[] | null>(null);
  const [nbaStatusLines, setNbaStatusLines] = useState<string[]>(['loading NBA slate…']);
  const [nbaTuning, setNbaTuning] = useState<NbaTuning>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(NBA_TUNING_KEY) || 'null');
      if (saved && typeof saved === 'object') {
        const known = Object.fromEntries(Object.entries(saved).filter(([k, v]) => k in NBA_TUNING_DEFAULTS && typeof v === 'number')); // drops retired keys (minGamesReal)
        return { ...NBA_TUNING_DEFAULTS, ...known };
      }
    } catch { /* ignore */ }
    return { ...NBA_TUNING_DEFAULTS };
  });
  useEffect(() => {
    try {
      const overrides: Partial<NbaTuning> = {};
      (Object.keys(nbaTuning) as (keyof NbaTuning)[]).forEach(k => { if (nbaTuning[k] !== NBA_TUNING_DEFAULTS[k]) overrides[k] = nbaTuning[k]; });
      localStorage.setItem(NBA_TUNING_KEY, JSON.stringify(overrides));
    } catch { /* ignore */ }
  }, [nbaTuning]);
  const [nbaSettings, setNbaSettings] = useState<NbaSettings>({ edgeThreshold: NBA_CONFIG.edgeMinPts, maxJuice: NBA_CONFIG.maxChalk, showStabsOnly: false });

  useEffect(() => {
    setNbaOdds({ date: nbaDate, map: loadDated<NbaOddsMap>(`${NBA_ODDS_KEY}_${nbaDate}`, nbaDate, {}) });
  }, [nbaDate]);
  useEffect(() => { saveDated(`${NBA_ODDS_KEY}_${nbaOdds.date}`, nbaOdds.date, nbaOdds.map); }, [nbaOdds]);
  useEffect(() => {
    try { localStorage.setItem(NBA_LEDGER_KEY, JSON.stringify(nbaLedger)); } catch (e) { console.error(e); }
  }, [nbaLedger]);

  // Schedule + game logs (server-side aggregated) + injury report for the selected date. Only loads while the NBA tab is open.
  useEffect(() => {
    if (activeSport !== 'nba') return;
    let cancelled = false;
    (async () => {
      setNbaStatusLines(['loading NBA slate…']);
      const [games, state, injuries] = await Promise.all([fetchNbaSchedule(nbaDate), fetchNbaState(nbaDate), fetchNbaInjuries()]);
      if (cancelled) return;
      setNbaGames(games ?? []);
      setNbaState(state);
      setNbaInjuries(injuries);
      const lines: string[] = [];
      lines.push(games === null ? 'schedule feed unreachable' : `${games.length} game(s) on the schedule`);
      lines.push(state ? `${state.players.length} players from ${state.gamesPlayed} played games${state.priorLoaded ? ' + last season' : ' (last season NOT loaded: priors are thin)'}` : 'game logs unreachable — board is empty (nothing is invented)');
      lines.push(injuries === null ? 'injury feed unreachable: every player is AVAILABILITY UNKNOWN and cannot qualify' : `${injuries.length} injury report entries`);
      setNbaStatusLines(lines);
    })().catch(() => { if (!cancelled) setNbaStatusLines(['NBA load failed']); });
    return () => { cancelled = true; };
  }, [nbaDate, activeSport]);

  const nbaProjections = React.useMemo(() => {
    applyNbaTuning(nbaTuning);
    if (!nbaState) return [];
    return withOddsLines(buildNbaSlate(nbaState, nbaGames, nbaInjuries), nbaOdds.map);
  }, [nbaState, nbaGames, nbaInjuries, nbaTuning, nbaOdds]);

  const handleNbaOddsChange = (market: NbaMarket, playerId: number, line: number, side: 'over' | 'under', val: number | null) => {
    setNbaOdds(prev => {
      const key = nbaOddsKey(market, playerId, line);
      const entry = { ...(prev.map[key] || {}), [side]: val };
      const next = { ...prev.map };
      if (entry.over == null && entry.under == null) delete next[key];
      else next[key] = entry;
      return { ...prev, map: next };
    });
  };

  const handleNbaLogRows = () => {
    const rows = collectNbaLedgerRows(nbaProjections, nbaOdds.map, nbaSettings, nbaDate);
    if (!rows.length) { alert('No priced rows to log.'); return; }
    setNbaLedger(prev => mergeNbaLedger(prev, rows));
    alert(`Logged ${rows.length} priced row(s) (${rows.filter(r => r.tag !== 'PASS').length} qualifying). Grade them from the Scoreboard after the games are final.`);
  };

  const handleNbaGrade = async () => {
    const pending = nbaLedger.filter(r => r.result === null);
    if (!pending.length) { setNbaGradeStatus('Nothing pending.'); return; }
    setNbaGradeStatus('Fetching real box scores…');
    const lines = await fetchNbaActuals(Array.from(new Set(pending.map(r => r.date))));
    if (!lines) { setNbaGradeStatus('Box score feed unreachable — nothing graded, nothing simulated.'); return; }
    const out = gradeNbaLedger(nbaLedger, lines, getTodayIsoDate());
    setNbaLedger(out.rows);
    setNbaGradeStatus(`Graded ${out.graded} · void ${out.voided} · still pending ${out.pending} (box scores usually post within a day; the free feed can lag).`);
  };

  const handleNbaImportLedger = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr);
      const arr: any[] = Array.isArray(data) ? data : Array.isArray(data.rows) ? data.rows : [];
      const rows = arr.filter(r => r && r.id && r.market && r.gameId !== undefined) as NbaLedgerRow[];
      setNbaLedger(prev => mergeNbaLedger(prev, rows));
      alert(`Imported ${rows.length} row(s)${rows.length < arr.length ? ` (${arr.length - rows.length} without ids were skipped)` : ''}.`);
    } catch (e: any) {
      alert('Invalid JSON: ' + e.message);
    }
  };

  /* =========================================================================
     UNIVERSAL SCREENSHOT APPLICATION HANDLER
     ========================================================================= */
  const handleApplyScreenshotLines = (lines: ExtractedPropLine[], targetSport?: 'NFL' | 'MLB' | 'NHL' | 'NBA') => {
    const chosenSport = (targetSport ? targetSport.toLowerCase() : activeSport) as ActiveSport;
    if (chosenSport !== activeSport) {
      setActiveSport(chosenSport);
      setActiveSubTab('desk');
    }

    if (chosenSport === 'nfl') {
      const formattedText = lines.map(l => `${l.player}, ${l.line}, ${l.overOdds || ''}, ${l.underOdds || ''}`).join('\n');
      handleNflImport(nflMeta?.season ?? 2026, nflMeta?.week ?? 0, 'Sportsbook OCR', 'pre', formattedText);
    } else if (chosenSport === 'mlb') {
      let matched = 0;
      const unmatched: string[] = [];
      const updatedOdds = { ...mlbOddsMap };
      const allBatters = mlbLiveGames.flatMap(g => g.batters);

      lines.forEach(lineItem => {
        const hits = allBatters.filter(b => fuzzyMatchName(lineItem.player, b.name));
        const ids = new Set(hits.map(h => h.id));
        if (ids.size !== 1) { unmatched.push(`${lineItem.player}${ids.size > 1 ? ' (ambiguous)' : ''}`); return; }
        const found = hits[0];
        updatedOdds[found.id] = {
          over: lineItem.overOdds || '',
          under: lineItem.underOdds || '',
          line: lineItem.line || 0.5
        };
        matched++;
      });

      setMlbOddsMap(updatedOdds);
      alert(`Applied ${matched} line(s) to the MLB board.` + (unmatched.length ? `\nNot in a posted lineup (skipped): ${unmatched.slice(0, 8).join(', ')}` : ''));
    } else if (chosenSport === 'nba') {
      let matched = 0;
      const unmatched: string[] = [];
      const entries: Array<[string, { over?: number | null; under?: number | null }]> = [];
      lines.forEach(li => {
        const market = inferNbaMarket(li.prop);
        if (!market) { unmatched.push(`${li.player} (market "${li.prop || '?'}" is not priced here)`); return; }
        const hits = nbaProjections.filter(p => fuzzyMatchName(li.player, p.name));
        const ids = new Set(hits.map(h => h.playerId));
        if (ids.size !== 1) { unmatched.push(`${li.player}${ids.size > 1 ? ' (ambiguous)' : ' (not on a loaded team today)'}`); return; }
        const over = parseOddsShared(li.overOdds)?.us ?? null;
        const under = parseOddsShared(li.underOdds)?.us ?? null;
        if (over == null && under == null) { unmatched.push(`${li.player} (no readable price)`); return; }
        entries.push([nbaOddsKey(market, hits[0].playerId, li.line), { over, under }]);
        matched++;
      });
      if (entries.length) setNbaMarket(entries[0][0].split('|')[0] as NbaMarket);
      setNbaOdds(prev => ({ ...prev, map: { ...prev.map, ...Object.fromEntries(entries) } }));
      alert(`Applied ${matched} line(s) to the NBA board.` + (unmatched.length ? `\nSkipped: ${unmatched.slice(0, 8).join(', ')}` : ''));
    } else if (chosenSport === 'nhl') {
      let matched = 0;
      const unmatched: string[] = [];
      const newExtras: NhlPlayerSnapshot[] = [];
      const slateTeams = new Set(nhlLiveGames.flatMap(g => [normalizeNhlTeam(g.awayTeam), normalizeNhlTeam(g.homeTeam)]));
      const loaded = [...Object.values(nhlSkatersByTeam).flat(), ...nhlExtraSkaters];
      const entries: Array<[string, { over?: number | null; under?: number | null }]> = [];

      lines.forEach(li => {
        const market = inferNhlMarket(li.prop, li.line);
        const supported = NHL_CONFIG[market].lines as number[];
        if (!supported.includes(li.line)) { unmatched.push(`${li.player} (${market.toUpperCase()} ${li.line} not a supported line)`); return; }
        const hits = loaded.filter(p => fuzzyMatchName(li.player, p.name));
        const ids = new Set(hits.map(h => h.playerId));
        let target: NhlPlayerSnapshot | undefined;
        if (ids.size > 1) { unmatched.push(`${li.player} (ambiguous)`); return; }
        if (ids.size === 1) target = hits[0];
        else {
          // not on a loaded roster: add an ESTIMATED skater (position prior only, never BET) if we know the team
          const team = normalizeNhlTeam(li.team || '');
          if (!slateTeams.has(team)) { unmatched.push(`${li.player} (team unknown / not on this slate)`); return; }
          target = buildEstimatedNhlSkater(li.player, team);
          newExtras.push(target);
        }
        const over = parseOddsShared(li.overOdds)?.us ?? null;
        const under = parseOddsShared(li.underOdds)?.us ?? null;
        if (over === null && under === null) { unmatched.push(`${li.player} (no odds)`); return; }
        entries.push([nhlOddsKey(market, target.playerId, li.line), { over, under }]);
        matched++;
      });

      if (newExtras.length) setNhlExtraSkaters(prev => [...prev, ...newExtras]);
      setNhlOdds(prev => ({ ...prev, map: { ...prev.map, ...Object.fromEntries(entries) } }));
      alert(`Applied ${matched} line(s) to the NHL board.` + (newExtras.length ? `\n${newExtras.length} player(s) were not on a loaded roster and are ESTIMATED (priced from the position prior; cannot qualify).` : '') + (unmatched.length ? `\nSkipped: ${unmatched.slice(0, 8).join(', ')}` : ''));
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f14] text-[#e6edf5] flex flex-col font-sans">
      <Header
        activeSport={activeSport}
        setActiveSport={setActiveSport}
        activeSubTab={activeSubTab}
        setActiveSubTab={setActiveSubTab}
        onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
        onRefreshLiveSchedule={refreshAllSchedules}
        isLoadingSchedule={isLoadingSchedule}
      />

      {/* Live Games Today Status Ribbon */}
      <div className="bg-[#121824]/90 border-b border-[#222d3e] px-4 py-2 text-xs font-mono">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[#8b97ac]">Today's Live Slate:</span>
            <span className="text-white font-semibold">
              {activeSport === 'nba'
                ? (nbaStatusLines[0] || "")
                : activeSport === 'nhl'
                ? (nhlStatusLines[0] || "")
                : activeSport === 'nfl'
                ? nflRosterStatus
                : (mlbSlateNote || scheduleStatusText)}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto text-[11px]">
            {activeSport === 'nfl' && Object.values(nflLiveGames).slice(0, 4).map(g => (
              <span key={g.id} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-sky-300 whitespace-nowrap">
                🏈 {g.away} @ {g.home}
              </span>
            ))}
            {activeSport === 'mlb' && mlbLiveGames.slice(0, 4).map(g => (
              <span key={g.gamePk} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-amber-300 whitespace-nowrap">
                ⚾ {g.away} @ {g.home}
              </span>
            ))}
            {activeSport === 'nba' && nbaGames.slice(0, 4).map(g => (
              <span key={g.gameId} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-orange-300 whitespace-nowrap">
                🏀 {g.away} @ {g.home}
              </span>
            ))}
            {activeSport === 'nhl' && nhlLiveGames.slice(0, 4).map(g => (
              <span key={g.gameId} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-cyan-300 whitespace-nowrap">
                🏒 {normalizeNhlTeam(g.awayTeam)} @ {normalizeNhlTeam(g.homeTeam)}
              </span>
            ))}
            <button
              onClick={refreshAllSchedules}
              disabled={isLoadingSchedule}
              className="text-sky-400 hover:text-white flex items-center gap-1 text-[11px] underline ml-1 cursor-pointer"
            >
              🔄 Refresh Games
            </button>
          </div>
        </div>
      </div>

      {loadDiag && !loadDiag.benign && !loadDiagDismissed && (
        <div className="max-w-6xl w-full mx-auto px-4 mt-3">
          <div className="flex items-start justify-between gap-3 p-3 rounded-xl border border-amber-800 bg-amber-950/40 text-amber-200 text-xs font-mono">
            <span><b>Page was reloaded:</b> {loadDiag.message}</span>
            <button onClick={() => setLoadDiagDismissed(true)} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-white">dismiss</button>
          </div>
        </div>
      )}
      <main className="max-w-6xl w-full mx-auto px-4 py-5 flex-1">
        <ErrorBoundary resetKey={`${activeSport}:${activeSubTab}`} label={`${activeSport.toUpperCase()} ${activeSubTab}`}>
        {/* =========================================================================
            SPORT 1: NFL RECEPTIONS PROPS (v1.6)
            ========================================================================= */}
        {activeSport === 'nfl' && (
          <div>
            {activeSubTab === 'desk' && (
              <NflDesk
                liveRosters={nflLiveRosters}
                rosterStatus={nflRosterStatus}
                injuries={nflInjuries}
                injuriesAvailable={nflInjuriesAvailable}
                onUpsertSnapshot={handleNflUpsertSnapshot}
                snapshots={nflSnapshots}
                bets={nflBets}
                games={nflLiveGames}
                onRecordBet={handleNflRecordBet}
                onOpenImport={() => setShowNflImportModal(true)}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
              />
            )}
            {activeSubTab === 'import' && (
              <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
                <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white mb-2">
                  Import NFL Lines (Bet99 Format &amp; Screenshot OCR)
                </h2>
                <p className="text-xs text-[#8b97ac] mb-4">
                  Paste odds lines directly or upload a screenshot to score them with the v1.6 negative binomial engine.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowScreenshotModal(true)}
                    className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    📷 Upload Screenshot of Lines
                  </button>
                  <button
                    onClick={() => setShowNflImportModal(true)}
                    className="px-5 py-2.5 bg-[#182232] hover:bg-[#222d3e] text-sky-400 border border-sky-500/40 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    Paste Text / CSV Lines
                  </button>
                </div>
              </div>
            )}
            {activeSubTab === 'grade' && (
              <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
                <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white mb-2">
                  Grade Game Results
                </h2>
                <p className="text-xs text-[#8b97ac] mb-4">
                  Enter final completed receptions to settle pending proposition bets and update Brier scores.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={handleNflAutoGrade}
                    className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    Auto-grade from nflverse
                  </button>
                  <button
                    onClick={() => setShowNflGradeModal(true)}
                    className="px-5 py-2.5 bg-[#182232] hover:bg-[#222d3e] text-sky-400 border border-sky-500/40 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    Enter manually
                  </button>
                </div>
              </div>
            )}
            {activeSubTab === 'scoreboard' && (
              <NflScoreboard
                snapshots={nflSnapshots}
                actuals={nflActuals}
                bets={nflBets}
                onExportJson={handleNflExportJson}
                onImportJson={handleNflImportJson}
                onReset={handleNflReset}
              />
            )}
          </div>
        )}

        {/* =========================================================================
            SPORT 2: MLB 0.5-HIT PROPS (v5.8)
            ========================================================================= */}
        {activeSport === 'mlb' && (
          <div>
            {mlbSlateNote && (
              <div className="mb-3 text-[11px] font-mono text-amber-300/90 bg-amber-950/30 border border-amber-800/40 rounded-xl px-3 py-2">
                {mlbSlateNote}
              </div>
            )}
            {activeSubTab === 'desk' && (
              <MlbDesk
                games={mlbLiveGames}
                oddsMap={mlbOddsMap}
                parlayLegs={mlbParlayLegs.map(l => l.id)}
                tune={mlbTune}
                onUpdateOdds={handleMlbOddsChange}
                onUpdateLine={handleMlbUpdateLine}
                onToggleParlay={handleMlbToggleParlay}
                onLogAllPriced={handleMlbLogAllPriced}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
              />
            )}
            {activeSubTab === 'parlays' && (
              <MlbParlayPicker
                legs={mlbParlayLegs}
                onRemoveLeg={id => setMlbParlayLegs(prev => prev.filter(l => l.id !== id))}
                onClear={() => setMlbParlayLegs([])}
                sgpHaircut={mlbTune.sgpHaircut}
              />
            )}
            {activeSubTab === 'ledger' && (
              <MlbLedger
                ledger={mlbLedger}
                onGradeOpenPlays={handleMlbGradeOpenPlays}
                onExportCsv={handleMlbExportCsv}
                onDeleteRow={idx => setMlbLedger(prev => prev.filter((_, i) => i !== idx))}
              />
            )}
            {activeSubTab === 'settings' && (
              <MlbSettings
                tune={mlbTune}
                onUpdateTune={setMlbTune}
                onResetTune={() => setMlbTune(MLB_DEFAULT_TUNE)}
              />
            )}
          </div>
        )}

        {/* =========================================================================
            SPORT 3: NHL SHOTS ON GOAL PROPS (sog_v1)
            ========================================================================= */}
        {activeSport === 'nhl' && (
          <div>
            {activeSubTab === 'desk' && (
              <NhlDesk
                date={nhlDate}
                setDate={setNhlDate}
                games={nhlLiveGames}
                projections={nhlProjections}
                market={nhlMarket}
                setMarket={setNhlMarket}
                oddsMap={nhlOdds.map}
                settings={nhlSettings}
                setShowStabsOnly={v => setNhlSettings(prev => ({ ...prev, showStabsOnly: v }))}
                onOddsChange={handleNhlOddsChange}
                onLogRows={handleNhlLogRows}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
                statusLines={nhlStatusLines}
              />
            )}
            {activeSubTab === 'scoreboard' && (
              <NhlScoreboard
                rows={nhlLedger}
                gradeStatus={nhlGradeStatus}
                onGrade={handleNhlGrade}
                onClearResults={() => { if (confirm('Clear the entire NHL ledger?')) setNhlLedger([]); }}
                onExportJson={() => {
                  const blob = new Blob([JSON.stringify({ rows: nhlLedger }, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `nhl_ledger_${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                }}
                onImportJson={handleNhlImportLedger}
              />
            )}
            {activeSubTab === 'settings' && (
              <NhlSettingsModal
                settings={nhlSettings}
                tuning={nhlTuning}
                onSettings={setNhlSettings}
                onTuning={setNhlTuning}
              />
            )}
          </div>
        )}

        {/* =========================================================================
            SPORT 4: NBA PLAYER PROPS (nba_v1)
            ========================================================================= */}
        {activeSport === 'nba' && (
          <div>
            {activeSubTab === 'desk' && (
              <NbaDesk
                date={nbaDate}
                setDate={setNbaDate}
                games={nbaGames}
                projections={nbaProjections}
                market={nbaMarket}
                setMarket={setNbaMarket}
                oddsMap={nbaOdds.map}
                settings={nbaSettings}
                setShowStabsOnly={v => setNbaSettings(prev => ({ ...prev, showStabsOnly: v }))}
                onOddsChange={handleNbaOddsChange}
                onLogRows={handleNbaLogRows}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
                statusLines={nbaStatusLines}
              />
            )}
            {activeSubTab === 'scoreboard' && (
              <NbaScoreboard
                rows={nbaLedger}
                gradeStatus={nbaGradeStatus}
                onGrade={handleNbaGrade}
                onClearResults={() => { if (confirm('Clear the entire NBA ledger?')) setNbaLedger([]); }}
                onExportJson={() => {
                  const blob = new Blob([JSON.stringify({ rows: nbaLedger }, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `nba_ledger_${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                }}
                onImportJson={handleNbaImportLedger}
              />
            )}
            {activeSubTab === 'settings' && (
              <NbaSettingsModal settings={nbaSettings} tuning={nbaTuning} onSettings={setNbaSettings} onTuning={setNbaTuning} />
            )}
          </div>
        )}
              </ErrorBoundary>
      </main>

      {/* Universal Screenshot Upload Modal */}
      {showScreenshotModal && (
        <ScreenshotUploadModal
          sport={activeSport.toUpperCase() as 'NFL' | 'MLB' | 'NHL' | 'NBA'}
          onApplyLines={handleApplyScreenshotLines}
          onClose={() => setShowScreenshotModal(false)}
        />
      )}

      {/* NFL Modals */}
      {showNflImportModal && (
        <NflImportModal
          defaultSeason={nflMeta?.season}
          defaultWeek={nflMeta?.week}
          onImport={handleNflImport}
          onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
          onClose={() => setShowNflImportModal(false)}
        />
      )}
      {showNflGradeModal && (
        <NflGradeModal
          defaultSeason={nflMeta?.season}
          defaultWeek={nflMeta ? nflMeta.week - 1 : undefined}
          onCommitGrades={handleNflCommitGrades}
          onClose={() => setShowNflGradeModal(false)}
        />
      )}

      {/* Honest Footer */}
      <footer className="max-w-6xl w-full mx-auto px-4 py-4 border-t border-[#222d3e] text-xs text-[#8b97ac] flex flex-col sm:flex-row items-center justify-between gap-2 mt-8">
        <div>
          <b>Integrity &amp; Anti-Leakage Protocol:</b> Log lines every week. Edge is measured on the scoreboard after grades, not on the projection screen.
        </div>
        <div className="font-mono text-[11px] text-[#556277]">
          Live Auto-Synced Schedule &middot; Universal Screenshot Scanner &middot; Small Bankroll Strict Mode
        </div>
      </footer>
    </div>
  );
}
