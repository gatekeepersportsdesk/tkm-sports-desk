import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const port = 3000;

app.use(express.json({ limit: '50mb' }));

// Sportsbook OCR parsing endpoint via Gemini 3.8 Flash Vision
app.post('/api/ocr-lines', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', sport = 'any' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 in request body' });
    }

    // Clean base64 header if included
    const cleanedBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const prompt = `You are an expert sports betting odds reader and optical character recognition parser.
Analyze this sportsbook screenshot (from Bet365, Bet99, DraftKings, FanDuel, Bovada, Pinnacle, or similar).
Extract all player proposition betting lines shown in the image.
The user is interested in props for ${sport} (NFL receptions, MLB 0.5-hits, or NHL shots on goal).

Respond with a strictly valid JSON object matching this schema:
{
  "book": "detected sportsbook name (e.g. Bet99, Bet365, DraftKings, etc.)",
  "detectedSport": "NFL" | "MLB" | "NHL",
  "propType": "receptions" | "hits" | "shots",
  "lines": [
    {
      "player": "Full Player Name",
      "team": "Team code if visible, otherwise empty string",
      "line": 6.5,
      "overOdds": "-110",
      "underOdds": "-120"
    }
  ]
}

Formatting rules:
- Format American odds with minus or plus (e.g. "-110", "+120", "-165").
- If only one side odds is visible, set the other to empty string.
- Normalize player names accurately (e.g. "Jaxon Smith-Njigba", "AJ Barner", "Aaron Judge", "Auston Matthews").
- Return JSON only. No markdown formatting or extra text.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType, data: cleanedBase64 } },
            { text: prompt }
          ]
        }
      ],
      config: {
        responseMimeType: 'application/json'
      }
    });

    const raw = response.text || '{}';
    const cleaned = raw.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
    const parsed = JSON.parse(cleaned || '{}');
    return res.json(parsed);
  } catch (err: any) {
    console.error('OCR Line parsing error:', err);
    return res.status(500).json({
      error: 'Failed to process screenshot with AI vision',
      details: err.message
    });
  }
});

// Proxy endpoints for today's live sports games (avoids browser CORS issues)
app.get('/api/games/nfl', async (_req, res) => {
  try {
    const response = await fetch('https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard', {
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`ESPN API returned ${response.status}`);
    const data = await response.json();
    return res.json(data);
  } catch (err: any) {
    console.error('ESPN NFL fetch failed:', err);
    return res.status(500).json({ error: 'Failed to fetch NFL live games', details: err.message });
  }
});

app.get('/api/games/mlb', async (_req, res) => {
  try {
    const response = await fetch('https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard', {
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`ESPN API returned ${response.status}`);
    const data = await response.json();
    return res.json(data);
  } catch (err: any) {
    console.error('ESPN MLB fetch failed:', err);
    return res.status(500).json({ error: 'Failed to fetch MLB live games', details: err.message });
  }
});

app.get('/api/games/nhl', async (req, res) => {
  try {
    const date = req.query.date as string;
    const url = date
      ? `https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard?dates=${date.replace(/-/g, '')}`
      : 'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard';
    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`ESPN API returned ${response.status}`);
    const data = await response.json();
    return res.json(data);
  } catch (err: any) {
    console.error('ESPN NHL fetch failed:', err);
    return res.status(500).json({ error: 'Failed to fetch NHL live games', details: err.message });
  }
});

// ---- NHL live data (official api-web.nhle.com) ----
const NHL_SEASON = '20262027';
const NHL_ABBREV: Record<string, string> = {
  SJ: 'SJS', SJS: 'SJS', LA: 'LAK', LAK: 'LAK', TB: 'TBL', TBL: 'TBL',
  NJ: 'NJD', NJD: 'NJD', WAS: 'WSH', WSH: 'WSH', MON: 'MTL', MTL: 'MTL',
  VEG: 'VGK', VGK: 'VGK', LV: 'VGK', UTAH: 'UTA', UTA: 'UTA',
  ANH: 'ANA', ANA: 'ANA', CLS: 'CBJ', CBJ: 'CBJ', CAL: 'CGY', CGY: 'CGY',
  NAS: 'NSH', NSH: 'NSH', WIN: 'WPG', WPG: 'WPG', PHO: 'UTA', ARI: 'UTA',
};

function nhlTeam(code: string): string {
  const u = (code || '').toUpperCase();
  return NHL_ABBREV[u] || u;
}

app.get('/api/nhl/schedule', async (req, res) => {
  try {
    const date = (req.query.date as string) || new Date().toISOString().slice(0, 10);
    const response = await fetch(`https://api-web.nhle.com/v1/schedule/${date}`, {
      headers: { Accept: 'application/json', 'User-Agent': 'GatekeepSportsDesk/1.0' },
    });
    if (!response.ok) throw new Error(`NHL schedule ${response.status}`);
    const data = await response.json();
    const games: any[] = [];
    for (const day of data.gameWeek || []) {
      if (day.date !== date) continue;
      for (const g of day.games || []) {
        games.push({
          gameId: g.id,
          startTimeUtc: g.startTimeUTC || g.startTimeUtc,
          awayTeam: g.awayTeam?.abbrev,
          homeTeam: g.homeTeam?.abbrev,
          venue: g.venue?.default || '',
        });
      }
    }
    return res.json({ date, games });
  } catch (err: any) {
    console.error('NHL schedule failed:', err);
    return res.status(500).json({ error: 'Failed to fetch NHL schedule', details: err.message });
  }
});

app.get('/api/nhl/skaters/:team', async (req, res) => {
  try {
    const team = nhlTeam(req.params.team);
    const [rosterRes, statsRes] = await Promise.all([
      fetch(`https://api-web.nhle.com/v1/roster/${team}/${NHL_SEASON}`, {
        headers: { Accept: 'application/json', 'User-Agent': 'GatekeepSportsDesk/1.0' },
      }),
      fetch(`https://api-web.nhle.com/v1/club-stats/${team}/${NHL_SEASON}/2`, {
        headers: { Accept: 'application/json', 'User-Agent': 'GatekeepSportsDesk/1.0' },
      }),
    ]);
    if (!rosterRes.ok) throw new Error(`roster ${rosterRes.status} for ${team}`);
    const roster = await rosterRes.json();
    const statsJson = statsRes.ok ? await statsRes.json() : { skaters: [] };
    const statsById: Record<number, any> = {};
    for (const s of statsJson.skaters || []) statsById[s.playerId] = s;

    const skaters: any[] = [];
    const pushPlayer = (p: any, pos: 'F' | 'D') => {
      const id = p.id;
      const name = `${p.firstName?.default || ''} ${p.lastName?.default || ''}`.trim();
      const st = statsById[id];
      const gp = Math.max(1, st?.gamesPlayed || 1);
      const shots = st?.shots || 0;
      const sogPerGame = shots / gp;
      // mu0 = expected SOG tonight; floor by role when sample is tiny
      const mu0 = Math.max(0.6, Math.min(5.5, sogPerGame || (pos === 'F' ? 2.2 : 1.5)));
      const toiVal = st?.avgTimeOnIcePerGame;
      let toiAvg = 15;
      if (typeof toiVal === 'number') {
        toiAvg = toiVal / 60;
      } else if (typeof toiVal === 'string' && toiVal.includes(':')) {
        const [m, s] = toiVal.split(':').map(Number);
        toiAvg = m + (s || 0) / 60;
      }
      skaters.push({
        playerId: id,
        name,
        team,
        pos,
        mu0: Math.round(mu0 * 100) / 100,
        toiAvg: Math.round(toiAvg * 10) / 10,
        recentShots: [Math.round(mu0), Math.round(mu0), Math.round(mu0), Math.round(mu0), Math.round(mu0)],
        gamesPlayed: st?.gamesPlayed || 0,
        seasonShots: shots,
        inputsSource: st ? 'REAL' : 'ROSTER_ONLY',
      });
    };
    for (const p of roster.forwards || []) pushPlayer(p, 'F');
    for (const p of roster.defensemen || []) pushPlayer(p, 'D');
    // Prefer higher SOG volume for the board (top 14)
    skaters.sort((a, b) => b.mu0 - a.mu0);
    return res.json({ team, season: NHL_SEASON, skaters: skaters.slice(0, 14) });
  } catch (err: any) {
    console.error('NHL skaters failed:', err);
    return res.status(500).json({ error: 'Failed to fetch NHL skaters', details: err.message });
  }
});

const httpServer = http.createServer(app);

// Mount Vite middleware for SPA serving in development mode

// ---- NFL live WR/TE (ESPN) ----
const ESPN_NFL_TEAM_ID: Record<string, string> = {
  ARI:'22', ATL:'1', BAL:'33', BUF:'2', CAR:'29', CHI:'3', CIN:'4', CLE:'5',
  DAL:'6', DEN:'7', DET:'8', GB:'9', HOU:'34', IND:'11', JAX:'30', KC:'12',
  LAC:'24', LAR:'14', LV:'13', MIA:'15', MIN:'16', NE:'17', NO:'18', NYG:'19',
  NYJ:'20', PHI:'21', PIT:'23', SEA:'26', SF:'25', TB:'27', TEN:'10', WSH:'28', WAS:'28',
};

app.get('/api/nfl/receivers/:team', async (req, res) => {
  try {
    const team = (req.params.team || '').toUpperCase();
    const tid = ESPN_NFL_TEAM_ID[team];
    if (!tid) return res.status(404).json({ error: `Unknown team ${team}` });
    const response = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${tid}/roster`,
      { headers: { Accept: 'application/json' } }
    );
    if (!response.ok) throw new Error(`ESPN roster ${response.status}`);
    const data = await response.json();
    const receivers: any[] = [];
    for (const grp of data.athletes || []) {
      for (const a of grp.items || []) {
        const pos = a.position?.abbreviation;
        if (pos !== 'WR' && pos !== 'TE') continue;
        const name = a.displayName || a.fullName;
        if (!name || /WR\d|TE\d|Top Center|Top Winger/i.test(name)) continue;
        receivers.push({ id: String(a.id), name, pos, team, jersey: a.jersey || '' });
      }
    }
    return res.json({ team, receivers });
  } catch (err: any) {
    console.error('NFL receivers failed:', err);
    return res.status(500).json({ error: 'Failed to fetch NFL receivers', details: err.message });
  }
});

app.get('/api/mlb/schedule', async (req, res) => {
  try {
    const date = (req.query.date as string) || new Date().toISOString().slice(0, 10);
    const url = `https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=${date}&hydrate=lineups,probablePitcher,team,linescore`;
    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`MLB schedule ${response.status}`);
    const data = await response.json();
    const gamesRaw = data.dates?.[0]?.games || [];
    return res.json({ date, count: gamesRaw.length, games: gamesRaw });
  } catch (err: any) {
    console.error('MLB schedule failed:', err);
    return res.status(500).json({ error: 'Failed to fetch MLB schedule', details: err.message });
  }
});

const vite = await createViteServer({
  server: {
    middlewareMode: true,
    hmr: { server: httpServer }
  }
});
app.use(vite.middlewares);

httpServer.listen(port, '0.0.0.0', () => {
  console.log(`Gatekeep Sports Desk full-stack server running on http://0.0.0.0:${port}`);
});
