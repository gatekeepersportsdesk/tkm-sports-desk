/**
 * Gatekeep Sports Desk — Universal Availability & Input Quality Gate
 * 
 * Non-negotiable rule:
 * Order: Slip / Roster -> Availability -> Inputs Quality -> Edge.
 * Never edge-first on an injured or dead roster.
 * Model math does not know injuries. Availability gates the card. Estimated inputs are not bets.
 */

export type AvailabilityStatus = 
  | 'ACTIVE' 
  | 'QUESTIONABLE' 
  | 'DOUBTFUL' 
  | 'OUT' 
  | 'IR' 
  | 'INACTIVE' 
  | 'SCRATCHED' 
  | 'NOT_IN_LINEUP' 
  | 'UNKNOWN';

export type InputsSource = 'REAL' | 'ESTIMATED' | 'UNKNOWN';

export interface PlayerAvailabilityInfo {
  status: AvailabilityStatus;
  reason: string;
}

/**
 * NFL Manual Injury & Inactive Roster
 * Ensures known injured/IR athletes cannot be graded as BET/PLAY even if slips quote them.
 */
export const NFL_MANUAL_UNAVAILABLE: Record<string, PlayerAvailabilityInfo> = {
  // 49ers
  "brandon aiyuk": { status: "IR", reason: "Torn ACL/MCL (Out for Season)" },
  "aiyuk": { status: "IR", reason: "Torn ACL/MCL (Out for Season)" },
  "deebo samuel": { status: "OUT", reason: "Hospitalized / Illness (Inactive)" },
  "deebo samuel sr.": { status: "OUT", reason: "Hospitalized / Illness (Inactive)" },
  "christian mccaffrey": { status: "IR", reason: "Bilateral Achilles Tendinitis" },

  // Chiefs / Bucs / Texans / Dolphins / Bills
  "rashee rice": { status: "IR", reason: "Knee Surgery (Out for Season)" },
  "chris godwin": { status: "IR", reason: "Dislocated Ankle (Out for Season)" },
  "stefon diggs": { status: "IR", reason: "Torn ACL (Out for Season)" },
  "hollywood brown": { status: "IR", reason: "Sternoclavicular Surgery" },
  "marquise brown": { status: "IR", reason: "Sternoclavicular Surgery" },
  "skylar thompson": { status: "INACTIVE", reason: "Ribs" },
  "braxton berrios": { status: "IR", reason: "Torn ACL" },
  "curtis samuel": { status: "OUT", reason: "Pectoral Injury" },
  "allenz lazard": { status: "IR", reason: "Chest Injury" },
  "allen lazard": { status: "IR", reason: "Chest Injury" },
  "diontae johnson": { status: "INACTIVE", reason: "Hamstring / Trade Transition" }
};

/**
 * NHL Manual Scratches & IR
 */
export const NHL_MANUAL_SCRATCHES: Record<string, PlayerAvailabilityInfo> = {
  "gabriel landeskog": { status: "IR", reason: "Knee Cartilage Transplant" },
  "evander kane": { status: "IR", reason: "Abdominal / Hip Surgery" },
  "carey price": { status: "IR", reason: "LTIR / Chronic Knee" },
  "robin lehner": { status: "IR", reason: "LTIR / Hip Surgery" },
  "nicklas backstrom": { status: "IR", reason: "LTIR / Hip Resurfacing" },
  "t.j. oshie": { status: "IR", reason: "Chronic Back Injury" },
  "patrik laine": { status: "IR", reason: "Knee Sprain" },
  "john gibson": { status: "OUT", reason: "Appendectomy Recovery" },
  "alexander romanov": { status: "SCRATCHED", reason: "Upper Body Injury" },
  "boone jenner": { status: "IR", reason: "Shoulder Surgery" }
};

/**
 * Normalizes player name for matching
 */
export function normalizeName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[.'’\-]/g, '')
    .replace(/\s+(jr|sr|iii|ii|iv)$/, '')
    .trim();
}

/**
 * Fuzzy check if candidate matches target
 */
export function fuzzyMatchName(input: string, candidate: string): boolean {
  const normInput = normalizeName(input);
  const normCandidate = normalizeName(candidate);
  if (normInput === normCandidate) return true;
  if (normInput.length > 4 && normCandidate.includes(normInput)) return true;
  if (normCandidate.length > 4 && normInput.includes(normCandidate)) return true;
  return false;
}

/**
 * Lookup NFL availability status
 */
export function lookupNflAvailability(playerName: string): PlayerAvailabilityInfo {
  const norm = normalizeName(playerName);
  for (const [key, val] of Object.entries(NFL_MANUAL_UNAVAILABLE)) {
    if (fuzzyMatchName(norm, normalizeName(key))) {
      return val;
    }
  }
  return { status: "ACTIVE", reason: "On active game roster" };
}

/**
 * Lookup NHL availability status
 */
export function lookupNhlAvailability(playerName: string): PlayerAvailabilityInfo {
  const norm = normalizeName(playerName);
  for (const [key, val] of Object.entries(NHL_MANUAL_SCRATCHES)) {
    if (fuzzyMatchName(norm, normalizeName(key))) {
      return val;
    }
  }
  return { status: "ACTIVE", reason: "Expected in lineup" };
}

/**
 * Check if a status represents an unavailable player
 */
export function isUnavailable(status: AvailabilityStatus): boolean {
  return (
    status === 'OUT' ||
    status === 'IR' ||
    status === 'INACTIVE' ||
    status === 'SCRATCHED' ||
    status === 'NOT_IN_LINEUP'
  );
}

/**
 * Universal Gate Enforcement:
 * Overrides card status to PASS if player is unavailable or inputs are estimated.
 */
export function forcePassIfUnavailable(
  computedStatus: 'BET' | 'PLAY' | 'PASS' | 'OFF',
  computedReason: string,
  availability: AvailabilityStatus,
  inputsSource: InputsSource = 'REAL'
): { status: 'BET' | 'PASS' | 'OFF'; reason: string; playAllowed: boolean } {
  if (isUnavailable(availability)) {
    return {
      status: 'PASS',
      reason: `Not available (${availability})`,
      playAllowed: false
    };
  }

  if (inputsSource === 'ESTIMATED') {
    return {
      status: 'PASS',
      reason: `Estimated inputs — cannot qualify as BET/PLAY`,
      playAllowed: false
    };
  }

  const isPlay = computedStatus === 'BET' || computedStatus === 'PLAY';
  return {
    status: isPlay ? 'BET' : computedStatus === 'OFF' ? 'OFF' : 'PASS',
    reason: computedReason,
    playAllowed: isPlay
  };
}
