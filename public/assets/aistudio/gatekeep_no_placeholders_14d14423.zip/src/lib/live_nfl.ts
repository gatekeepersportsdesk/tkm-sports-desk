import { NflPlayerStats } from '../types/nfl';

/** Fetch real WR/TE names from ESPN via server proxy. Never invent role labels. */
export async function fetchNflReceivers(team: string): Promise<NflPlayerStats[]> {
  try {
    const res = await fetch(`/api/nfl/receivers/${encodeURIComponent(team)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return (data.receivers || []).map((r: any) => {
      const isTE = r.pos === 'TE';
      const stats: NflPlayerStats = {
        name: r.name,
        pos: isTE ? 'TE' : 'WR',
        team,
        route_pct: isTE ? 0.55 : 0.70,
        season_tprr: isTE ? 0.16 : 0.20,
        prior_tprr: isTE ? 0.16 : 0.20,
        routes: 80,
        targets: 15,
        receptions: 10,
        games: 5,
        season_avg: isTE ? 2.5 : 3.5,
        ratio: isTE ? 1.0283 : 0.9915,
      };
      return stats;
    });
  } catch (e) {
    console.warn('NFL receivers fetch failed', team, e);
    return [];
  }
}

export async function loadNflReceiversForTeams(
  teams: string[]
): Promise<Record<string, NflPlayerStats[]>> {
  const uniq = Array.from(new Set(teams.map((t) => (t || '').toUpperCase()).filter(Boolean)));
  const out: Record<string, NflPlayerStats[]> = {};
  await Promise.all(
    uniq.map(async (team) => {
      out[team] = await fetchNflReceivers(team);
    })
  );
  return out;
}
