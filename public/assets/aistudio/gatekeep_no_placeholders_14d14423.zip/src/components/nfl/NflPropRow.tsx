import React, { useState } from 'react';
import { NflPropSnapshot } from '../../types/nfl';
import { NflPlayerDrawer } from './NflPlayerDrawer';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface NflPropRowProps {
  snapshot: NflPropSnapshot;
  isBetPlaced: boolean;
  onRecordBet: (snap: NflPropSnapshot) => void;
  onUpdateLine?: (player: string, line: number, overOdds: string, underOdds: string) => void;
}

export const NflPropRow: React.FC<NflPropRowProps> = ({
  snapshot,
  isBetPlaced,
  onRecordBet,
  onUpdateLine
}) => {
  const [expanded, setExpanded] = useState(false);
  const [lineInput, setLineInput] = useState<string>(String(snapshot.line));
  const [overOddsInput, setOverOddsInput] = useState<string>(snapshot.overOdds || '-115');
  const [underOddsInput, setUnderOddsInput] = useState<string>(snapshot.underOdds || '-115');

  // Sync internal inputs when prop updates
  React.useEffect(() => {
    setLineInput(String(snapshot.line));
    setOverOddsInput(snapshot.overOdds);
    setUnderOddsInput(snapshot.underOdds);
  }, [snapshot.line, snapshot.overOdds, snapshot.underOdds]);

  const handleLineCommit = (newLineStr: string, newOver: string, newUnder: string) => {
    const parsedLine = parseFloat(newLineStr);
    if (!isNaN(parsedLine) && parsedLine >= 0 && onUpdateLine) {
      onUpdateLine(snapshot.player, parsedLine, newOver || '-115', newUnder || '-115');
    }
  };

  const edgePts = (snapshot.edge * 100).toFixed(1);
  const isPlay = snapshot.cardStatus === 'BET';

  const statusBadge = isPlay ? (
    <span className="text-[11px] font-mono px-2.5 py-0.5 rounded font-bold bg-emerald-950 text-emerald-300 border border-emerald-500 shadow-sm shadow-emerald-900/50">
      PLAY
    </span>
  ) : (
    <span className="text-[11px] font-mono px-2 py-0.5 rounded font-medium bg-slate-800 text-slate-400 border border-slate-700">
      PASS
    </span>
  );

  const leanBadgeStyles = {
    OVER: 'bg-emerald-950 text-emerald-400 border border-emerald-800',
    UNDER: 'bg-orange-950 text-orange-400 border border-orange-800'
  };

  return (
    <div className={`border rounded-xl transition overflow-hidden mb-2.5 ${
      isPlay
        ? 'border-emerald-500/60 bg-[#0c161d] shadow-sm shadow-emerald-950/40'
        : 'border-[#222d3e] bg-[#0f1520] hover:border-slate-600'
    }`}>
      <div
        onClick={() => setExpanded(!expanded)}
        className="p-3 sm:p-3.5 cursor-pointer flex flex-col gap-2.5 select-none"
      >
        {/* Line 1: Player info + Status Badges */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="font-bold text-white text-sm sm:text-base truncate">
              {snapshot.player}
            </span>
            <span className="font-mono text-[11px] bg-[#182232] text-sky-400 px-1.5 py-0.5 rounded border border-[#222d3e]">
              {snapshot.pos}
            </span>
            <span className="text-xs text-[#8b97ac] font-mono">
              {snapshot.team}
            </span>
            {snapshot.availability && snapshot.availability !== 'ACTIVE' && snapshot.availability !== 'UNKNOWN' && (
              <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                snapshot.availability === 'IR' || snapshot.availability === 'OUT' || snapshot.availability === 'INACTIVE'
                  ? 'bg-rose-950 text-rose-300 border-rose-600 animate-pulse'
                  : 'bg-amber-950 text-amber-300 border-amber-600'
              }`}>
                {snapshot.availability}
              </span>
            )}
            {snapshot.inputsSource === 'ESTIMATED' && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded border bg-amber-950/80 text-amber-300 border-amber-600 font-semibold" title="Estimated input stats — cannot be BET/PLAY">
                EST. INPUTS
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isBetPlaced && (
              <span className="text-[10px] font-mono font-bold bg-sky-900 text-sky-200 px-2 py-0.5 rounded border border-sky-600">
                PLACED 1.0u
              </span>
            )}
            {statusBadge}
            <button className="text-[#8b97ac] hover:text-white transition">
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Gate Reason Note */}
        {snapshot.cardReason && (snapshot.availability !== 'ACTIVE' || snapshot.inputsSource === 'ESTIMATED' || snapshot.cardStatus === 'PASS') && (
          <div className="text-[11px] font-mono text-[#8b97ac] italic truncate">
            Gate: <span className={snapshot.availability === 'IR' || snapshot.availability === 'OUT' ? 'text-rose-400 font-semibold' : 'text-slate-300'}>{snapshot.cardReason}</span>
          </div>
        )}

        {/* Line 2: Interactive editable line & odds from sportsbook */}
        <div
          className="flex flex-wrap items-center justify-between gap-2.5 pt-1 border-t border-[#222d3e]/60"
          onClick={e => e.stopPropagation()}
        >
          {/* Sportsbook line & odds editors */}
          <div className="flex items-center gap-2 font-mono text-xs">
            <label className="text-[10px] text-[#8b97ac] flex flex-col">
              Line
              <input
                type="number"
                step="0.5"
                min="0.5"
                max="15.5"
                value={lineInput}
                onChange={e => {
                  setLineInput(e.target.value);
                  handleLineCommit(e.target.value, overOddsInput, underOddsInput);
                }}
                className="w-16 bg-[#0b0f14] border border-[#222d3e] rounded px-1.5 py-1 text-xs font-mono text-center text-white font-bold outline-none focus:border-sky-400 mt-0.5"
                title="Edit sportsbook line (e.g. 2.5, 3.5, 4.5)"
              />
            </label>

            <label className="text-[10px] text-[#8b97ac] flex flex-col">
              Over Odds
              <input
                type="text"
                value={overOddsInput}
                placeholder="-115"
                onChange={e => {
                  setOverOddsInput(e.target.value);
                  handleLineCommit(lineInput, e.target.value, underOddsInput);
                }}
                className="w-16 bg-[#0b0f14] border border-[#222d3e] rounded px-1.5 py-1 text-xs font-mono text-center text-white outline-none focus:border-sky-400 mt-0.5"
                title="Sportsbook Over Odds (e.g. -115)"
              />
            </label>

            <label className="text-[10px] text-[#8b97ac] flex flex-col">
              Under Odds
              <input
                type="text"
                value={underOddsInput}
                placeholder="-115"
                onChange={e => {
                  setUnderOddsInput(e.target.value);
                  handleLineCommit(lineInput, overOddsInput, e.target.value);
                }}
                className="w-16 bg-[#0b0f14] border border-[#222d3e] rounded px-1.5 py-1 text-xs font-mono text-center text-white outline-none focus:border-sky-400 mt-0.5"
                title="Sportsbook Under Odds (e.g. -115)"
              />
            </label>
          </div>

          {/* Model calculation results */}
          <div className="flex items-center gap-2">
            <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${leanBadgeStyles[snapshot.lean]}`}>
              {snapshot.lean} {snapshot.line.toFixed(1)} rec ({snapshot.edge >= 0 ? '+' : ''}{edgePts} pts)
            </span>
          </div>
        </div>

        {/* Line 3: Model mu, Season avg, Model win % vs Market fair % */}
        <div className="flex flex-wrap items-center justify-between text-xs text-[#8b97ac] font-mono pt-1.5 border-t border-[#222d3e]/70 gap-y-1">
          <div>
            Model &mu;: <span className="text-sky-400 font-bold">{snapshot.mu.toFixed(2)}</span> &middot; Szn avg: <span className="text-white font-medium">{snapshot.seasonAvg.toFixed(2)}</span>
          </div>
          <div>
            Model Win: <span className="text-emerald-400 font-semibold">{((snapshot.lean === 'OVER' ? snapshot.p_over : snapshot.p_under) * 100).toFixed(1)}%</span> vs Fair Mkt: <span className="text-white font-medium">{((snapshot.lean === 'OVER' ? snapshot.fair_over : snapshot.fair_under) * 100).toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {expanded && (
        <NflPlayerDrawer
          snapshot={snapshot}
          isBetPlaced={isBetPlaced}
          onRecordBet={onRecordBet}
        />
      )}
    </div>
  );
};
