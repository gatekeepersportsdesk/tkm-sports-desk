import React, { useState } from 'react';
import { NflPropSnapshot, NflGameContext } from '../../types/nfl';
import { NflPropRow } from './NflPropRow';
import { NFL_GAMES, NFL_PLAYERS, getOrCreateNflPlayer, calculateNflSnapshotFromInputs, getPlayersForTeam } from '../../data/nfl_seed';
import { getTodayDayOfWeek } from '../../lib/dates';

interface NflDeskProps {
  snapshots: NflPropSnapshot[];
  bets: Record<string, { stake: number; side: 'over' | 'under'; odds_taken: number }>;
  games?: Record<string, NflGameContext>;
  liveRosters?: Record<string, import('../../types/nfl').NflPlayerStats[]>;
  rosterStatus?: string;
  onRecordBet: (snap: NflPropSnapshot) => void;
  onOpenImport: () => void;
  onOpenScreenshotUpload?: () => void;
}

export const NflDesk: React.FC<NflDeskProps> = ({
  snapshots: externalSnapshots,
  bets,
  games = NFL_GAMES,
  liveRosters = {},
  rosterStatus,
  onRecordBet,
  onOpenImport,
  onOpenScreenshotUpload
}) => {
  const allGames = Object.values(games && Object.keys(games).length > 0 ? games : NFL_GAMES);
  
  // Available days
  const availableDays = Array.from(new Set(allGames.map(g => g.day)));
  const daysOrder: ('Monday' | 'Thursday' | 'Sunday')[] = ['Monday', 'Sunday', 'Thursday'];
  const orderedDays = daysOrder.filter(d => availableDays.includes(d));
  availableDays.forEach(d => {
    if (!orderedDays.includes(d as any)) orderedDays.push(d as any);
  });

  // Default to today's day if games exist for today (e.g. Monday), otherwise first day
  const todayDay = getTodayDayOfWeek();
  const initialDay = orderedDays.includes(todayDay as any) ? todayDay : (orderedDays[0] || 'Monday');

  const [selectedDay, setSelectedDay] = useState<string>('ALL');
  const [filterMode, setFilterMode] = useState<'ALL' | 'PLAY' | 'PASS'>('ALL');

  // Local state for user-edited player lines/odds
  const [editedSnapshots, setEditedSnapshots] = useState<Record<string, NflPropSnapshot>>({});

  // Merge external snapshots with local edits
  const currentSnapshots = React.useMemo(() => {
    const map = new Map<string, NflPropSnapshot>();
    externalSnapshots.forEach(s => map.set(`${s.player}_${s.gameKey}`, s));
    Object.values(editedSnapshots).forEach(s => map.set(`${s.player}_${s.gameKey}`, s));
    return Array.from(map.values());
  }, [externalSnapshots, editedSnapshots]);

  const handleUpdateLine = (game: NflGameContext, playerName: string, line: number, overOdds: string, underOdds: string) => {
    const { player: pData } = getOrCreateNflPlayer(playerName, game.away === playerName ? game.away : game.home);
    const updated = calculateNflSnapshotFromInputs(pData, game, line, overOdds, underOdds);
    setEditedSnapshots(prev => ({
      ...prev,
      [`${playerName}_${game.id}`]: updated
    }));
  };

  // Filter games based on selectedDay
  const activeGames = selectedDay === 'ALL'
    ? allGames
    : allGames.filter(g => g.day === selectedDay);

  // Helper to ensure all players on a team are present
  const getTeamRosterSnapshots = (game: NflGameContext, team: string): NflPropSnapshot[] => {
    const live = liveRosters[team] || liveRosters[(team || '').toUpperCase()] || [];
    const seeded = getPlayersForTeam(team).filter(p => !/WR\d|TE\d|Top Center|Top Winger/i.test(p.name));
    const byName = new Map(seeded.map(p => [p.name.toLowerCase(), p]));
    // Prefer LIVE real names. Never show role placeholders.
    const teamPlayers = (live.length ? live.map(p => byName.get(p.name.toLowerCase()) || p) : seeded)
      .filter(p => p.name && !/WR\d|TE\d|Top Center|Top Winger|1st Pair|Offensive D/i.test(p.name));
    
    // For each player on this team, find or create their snapshot for this game
    return teamPlayers.map(p => {
      const existing = currentSnapshots.find(s => s.player === p.name && s.gameKey === game.id);
      if (existing) return existing;

      // Default baseline line from season avg rounded to .5
      const baselineLine = Math.max(0.5, Math.round(p.season_avg * 2) / 2);
      return calculateNflSnapshotFromInputs(p, game, baselineLine, '-115', '-115');
    });
  };

  // Count total plays across whole board
  let totalBoardPlayers = 0;
  let totalBoardPlays = 0;
  allGames.forEach(g => {
    const awaySnaps = getTeamRosterSnapshots(g, g.away);
    const homeSnaps = getTeamRosterSnapshots(g, g.home);
    const all = [...awaySnaps, ...homeSnaps];
    totalBoardPlayers += all.length;
    totalBoardPlays += all.filter(s => s.cardStatus === 'BET').length;
  });

  return (
    <div className="space-y-4">
      {rosterStatus && (
        <div className="text-[11px] font-mono text-[#8b97ac] px-1">NFL roster: {rosterStatus}</div>
      )}
      {/* Slate Days & Quick Filter Navigation Rail */}
      <div className="flex items-center justify-between gap-3 flex-wrap bg-[#121824] p-3 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedDay('ALL')}
            className={`px-3 py-1.5 rounded-xl text-left transition flex flex-col min-w-[100px] border ${
              selectedDay === 'ALL'
                ? 'bg-sky-950/80 border-sky-400 text-sky-300'
                : 'bg-[#0f1520] border-[#222d3e] text-[#8b97ac] hover:text-white'
            }`}
          >
            <span className="text-[10px] font-mono uppercase font-bold tracking-wider">
              Whole Board
            </span>
            <span className="text-xs font-mono font-semibold text-white">
              All Matchups ({totalBoardPlayers} players)
            </span>
          </button>

          {orderedDays.map(day => {
            const isToday = day.toLowerCase() === todayDay.toLowerCase();
            const dayGames = allGames.filter(g => g.day === day);
            let dayPlayers = 0;
            let dayPlays = 0;
            dayGames.forEach(g => {
              const all = [...getTeamRosterSnapshots(g, g.away), ...getTeamRosterSnapshots(g, g.home)];
              dayPlayers += all.length;
              dayPlays += all.filter(s => s.cardStatus === 'BET').length;
            });

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`px-3.5 py-1.5 rounded-xl text-left transition flex flex-col min-w-[95px] border ${
                  selectedDay === day
                    ? 'bg-sky-950/80 border-sky-400 text-sky-300'
                    : 'bg-[#0f1520] border-[#222d3e] text-[#8b97ac] hover:text-white'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono uppercase font-bold tracking-wider">
                    {day}
                  </span>
                  {isToday && (
                    <span className="text-[9px] bg-emerald-500 text-slate-950 px-1 rounded font-bold uppercase">
                      Today
                    </span>
                  )}
                </div>
                <span className="text-xs font-mono font-semibold text-white">
                  {dayPlayers} players {dayPlays > 0 && <span className="text-emerald-400 font-bold">({dayPlays} PLAY)</span>}
                </span>
              </button>
            );
          })}
        </div>

        {/* PLAY / PASS Filter and Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-[#0f1520] p-1 rounded-xl border border-[#222d3e]">
            <button
              onClick={() => setFilterMode('ALL')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition ${
                filterMode === 'ALL'
                  ? 'bg-sky-500 text-slate-950 font-bold'
                  : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              All Players
            </button>
            <button
              onClick={() => setFilterMode('PLAY')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition ${
                filterMode === 'PLAY'
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'text-[#8b97ac] hover:text-emerald-400'
              }`}
            >
              PLAYs Only ({totalBoardPlays})
            </button>
            <button
              onClick={() => setFilterMode('PASS')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition ${
                filterMode === 'PASS'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              PASS Only
            </button>
          </div>

          <button
            onClick={onOpenScreenshotUpload || onOpenImport}
            className="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 cursor-pointer"
          >
            📷 Upload Lines Screenshot
          </button>
          <button
            onClick={onOpenImport}
            className="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-[#182232] hover:bg-[#222d3e] text-sky-400 border border-sky-500/40 cursor-pointer"
          >
            📋 Paste Lines
          </button>
        </div>
      </div>

      {/* Matchups list */}
      <div className="space-y-4">
        {activeGames.length === 0 ? (
          <div className="p-8 text-center text-[#8b97ac] bg-[#121824] rounded-2xl border border-[#222d3e]">
            <p className="font-semibold text-white">No NFL games found for this selection.</p>
          </div>
        ) : (
          activeGames.map((game: NflGameContext) => {
            const awaySnaps = getTeamRosterSnapshots(game, game.away);
            const homeSnaps = getTeamRosterSnapshots(game, game.home);

            const filterSnaps = (snaps: NflPropSnapshot[]) => {
              if (filterMode === 'PLAY') return snaps.filter(s => s.cardStatus === 'BET');
              if (filterMode === 'PASS') return snaps.filter(s => s.cardStatus !== 'BET');
              return snaps;
            };

            const visibleAway = filterSnaps(awaySnaps);
            const visibleHome = filterSnaps(homeSnaps);
            const totalVisible = visibleAway.length + visibleHome.length;
            const qualifiedCount = [...awaySnaps, ...homeSnaps].filter(s => s.cardStatus === 'BET').length;

            return (
              <div key={game.id} className="bg-[#121824] rounded-2xl border border-[#222d3e] overflow-hidden">
                {/* Matchup Header */}
                <div className="p-4 bg-[#182232] border-b border-[#222d3e] flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white">
                        {game.away} @ {game.home}
                      </h2>
                      <span className="text-[10px] font-mono uppercase bg-[#0f1520] text-sky-300 px-2 py-0.5 rounded border border-[#222d3e]">
                        {game.day}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-[#8b97ac] font-mono mt-0.5">
                      <span>{game.kickoff}</span>
                      <span>Spread: {game.home} {game.spread_home > 0 ? `+${game.spread_home}` : game.spread_home}</span>
                      <span>O/U: {(game.implied_total_home + game.implied_total_away).toFixed(1)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs bg-[#0f1520] text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-900 font-semibold">
                      {qualifiedCount} PLAYs
                    </span>
                    <span className="font-mono text-xs bg-[#0f1520] text-[#8b97ac] px-2.5 py-1 rounded-full border border-[#222d3e]">
                      {awaySnaps.length + homeSnaps.length} Players on Board
                    </span>
                  </div>
                </div>

                {/* Team Columns of Props */}
                {totalVisible === 0 ? (
                  <div className="p-8 text-center text-[#8b97ac] font-mono text-xs">
                    No players match the current filter ({filterMode}) for this matchup.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                    {/* Away Team Column */}
                    <div>
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#222d3e]">
                        <h3 className="font-display uppercase tracking-wider text-sm font-bold text-white">
                          {game.away} <span className="font-mono text-xs text-[#8b97ac] font-normal">{game.spread_away > 0 ? `+${game.spread_away}` : game.spread_away}</span>
                        </h3>
                        <span className="text-[11px] font-mono text-[#8b97ac]">
                          {visibleAway.length} Receivers
                        </span>
                      </div>

                      {visibleAway.map(snap => (
                        <NflPropRow
                          key={snap.id}
                          snapshot={snap}
                          isBetPlaced={Boolean(bets[snap.id])}
                          onRecordBet={onRecordBet}
                          onUpdateLine={(pName, l, ov, un) => handleUpdateLine(game, pName, l, ov, un)}
                        />
                      ))}
                    </div>

                    {/* Home Team Column */}
                    <div>
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#222d3e]">
                        <h3 className="font-display uppercase tracking-wider text-sm font-bold text-white">
                          {game.home} <span className="font-mono text-xs text-[#8b97ac] font-normal">{game.spread_home > 0 ? `+${game.spread_home}` : game.spread_home}</span>
                        </h3>
                        <span className="text-[11px] font-mono text-[#8b97ac]">
                          {visibleHome.length} Receivers
                        </span>
                      </div>

                      {visibleHome.map(snap => (
                        <NflPropRow
                          key={snap.id}
                          snapshot={snap}
                          isBetPlaced={Boolean(bets[snap.id])}
                          onRecordBet={onRecordBet}
                          onUpdateLine={(pName, l, ov, un) => handleUpdateLine(game, pName, l, ov, un)}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
