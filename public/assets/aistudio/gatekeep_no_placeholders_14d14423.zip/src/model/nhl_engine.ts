import { lookupNhlAvailability, isUnavailable, AvailabilityStatus, InputsSource } from '../lib/availability';
import { NhlPlayerSnapshot, NhlSkaterProjection } from '../types/nhl';

export const NHL_FROZEN_CONFIG = {
  version: "sog_v1",
  r: 15.13, // Fixed dispersion parameter
  w_opp: 1.0, // Opponent shots-allowed exponent
  s_default: 1.0, // Scale factor covering other game situations
  league_avg_mu: 1.74
};

export const NHL_OPPONENT_FACTORS: Record<string, number> = {
  ANA: 1.14, SJS: 1.18, CHI: 1.11, CBJ: 1.09, MTL: 1.08,
  OTT: 1.04, BUF: 1.03, ARI: 1.02, UTA: 1.02, DET: 1.01,
  VAN: 1.00, EDM: 0.98, TOR: 0.96, BOS: 0.94, NYR: 0.95,
  VGK: 0.93, CAR: 0.88, NJD: 0.91, COL: 0.95, FLA: 0.92,
  TBL: 0.97, DAL: 0.92, WPG: 0.93, LAK: 0.89, MIN: 0.97,
  NSH: 0.96, CGY: 0.99, STL: 1.02, PIT: 1.01, WSH: 0.99,
  PHI: 0.98, NYI: 1.02, SEA: 0.96
};

/**
 * Lanczos log-gamma approximation
 */
export function logGamma(z: number): number {
  const g = 7;
  const C = [
    0.99999999999980993,
    676.5203681218851,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.138571095856205,
    9.9843695780195716e-6,
    1.5056327351493116e-7
  ];
  if (z < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * z)) - logGamma(1 - z);
  }
  z -= 1;
  let x = C[0];
  for (let i = 1; i < g + 2; i++) {
    x += C[i] / (z + i);
  }
  const t = z + g + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

/**
 * Negative Binomial PMF: P(Y = k)
 * With mean mu and dispersion r
 */
export function nbinomPmf(k: number, mu: number, r: number = NHL_FROZEN_CONFIG.r): number {
  if (k < 0 || mu <= 0) return 0.0;
  const p = r / (r + mu);
  const logPmf = logGamma(k + r) - (logGamma(k + 1) + logGamma(r))
               + r * Math.log(p) + k * Math.log(1 - p);
  return Math.exp(logPmf);
}

/**
 * Negative Binomial Survival Function: P(Y > line)
 * For half-lines (1.5, 2.5, 3.5), floor(line) is exact threshold
 */
export function pOverLine(line: number, mu: number, r: number = NHL_FROZEN_CONFIG.r): number {
  const target = Math.floor(line);
  let cdf = 0.0;
  for (let k = 0; k <= target; k++) {
    cdf += nbinomPmf(k, mu, r);
  }
  const survival = 1.0 - cdf;
  return Math.min(Math.max(survival, 1e-6), 1 - 1e-6);
}

/**
 * Compute expected shots mu and probabilities for standard lines
 */
export function projectNhlSkater(
  player: NhlPlayerSnapshot | {
    playerId: number;
    name: string;
    team: string;
    pos: 'F' | 'D';
    mu0: number;
    toiAvg?: number;
    recentShots?: number[];
    availability?: AvailabilityStatus;
    inputsSource?: InputsSource;
  },
  oppTeam: string,
  scale: number = NHL_FROZEN_CONFIG.s_default
): NhlSkaterProjection {
  const oppFactor = NHL_OPPONENT_FACTORS[oppTeam.toUpperCase()] ?? 1.0;
  const mu = player.mu0 * scale * Math.pow(oppFactor, NHL_FROZEN_CONFIG.w_opp);
  const defaultLine = Math.floor(mu) + 0.5;

  const lines = [1.5, 2.5, 3.5, 4.5];
  const probOver: Record<number, number> = {};
  for (const l of lines) {
    probOver[l] = pOverLine(l, mu, NHL_FROZEN_CONFIG.r);
  }

  return {
    playerId: player.playerId,
    name: player.name,
    team: player.team,
    opp: oppTeam.toUpperCase(),
    pos: player.pos,
    mu0: player.mu0,
    oppFactor,
    scale,
    mu,
    defaultLine,
    probOver,
    recentShots: player.recentShots || [],
    toiAvg: player.toiAvg || 18.0,
    availability: player.availability || lookupNhlAvailability(player.name).status,
    inputsSource: player.inputsSource || 'REAL'
  };
}

export function americanToImplied(american: number): number {
  if (!american || isNaN(american) || american === 0) return 0.5;
  if (american > 0) {
    return 100.0 / (american + 100.0);
  } else {
    const abs = Math.abs(american);
    return abs / (abs + 100.0);
  }
}

export function parseAmericanOdds(input: string | number | null | undefined): number | null {
  if (input === null || input === undefined) return null;
  if (typeof input === 'number') return input;
  const cleaned = String(input).trim().replace(/[+−–—]/g, (m) => m === '+' ? '' : '-');
  const num = parseInt(cleaned, 10);
  return isNaN(num) || num === 0 ? null : num;
}

export function evaluateNhlAction(
  probModelOver: number,
  americanOdds: number | null,
  edgeThreshold: number = 5.0, // percentage points
  maxJuice: number = -200,
  availability?: AvailabilityStatus,
  inputsSource?: InputsSource
): { tag: 'STAB' | 'FADE' | 'PASS'; edge: number; reason: string } {
  if (availability && isUnavailable(availability)) {
    return { tag: 'PASS', edge: 0, reason: `Not available (${availability})` };
  }

  if (americanOdds === null) {
    return { tag: 'PASS', edge: 0, reason: "No market odds entered" };
  }

  const pMarket = americanToImplied(americanOdds);
  const edgePts = (probModelOver - pMarket) * 100;

  if (inputsSource === 'ESTIMATED') {
    return {
      tag: 'PASS',
      edge: edgePts,
      reason: `Estimated inputs — cannot qualify as STAB/PLAY (Edge: ${edgePts >= 0 ? '+' : ''}${edgePts.toFixed(1)}pp)`
    };
  }

  if (edgePts >= edgeThreshold) {
    if (americanOdds < 0 && americanOdds < maxJuice) {
      return {
        tag: 'PASS',
        edge: edgePts,
        reason: `Edge (+${edgePts.toFixed(1)}pp) disqualified: odds (${americanOdds}) exceed max chalk juice (${maxJuice})`
      };
    }
    return {
      tag: 'STAB',
      edge: edgePts,
      reason: `Cashable Edge: +${edgePts.toFixed(1)}pp over market implied ${(pMarket * 100).toFixed(1)}%`
    };
  }

  if (edgePts <= -edgeThreshold) {
    return {
      tag: 'FADE',
      edge: edgePts,
      reason: `Under Edge: Model sits ${Math.abs(edgePts).toFixed(1)}pp below market`
    };
  }

  return {
    tag: 'PASS',
    edge: edgePts,
    reason: `Within neutral margin (${edgePts >= 0 ? '+' : ''}${edgePts.toFixed(1)}pp)`
  };
}
