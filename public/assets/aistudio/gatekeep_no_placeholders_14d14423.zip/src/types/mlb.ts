export interface MlbBatterInput {
  id: number;
  name: string;
  team: string;
  slot: number;
  isHome: boolean;
  hand: string;
  seasonBa: number;
  seasonPa?: number;
  xba?: number;
  xbaPa?: number;
  recentBa?: number;
  recentAb?: number;
  bbPct?: number;
  recentReal?: boolean;
  oppSp: string;
  oppHand: string;
  confirmed: boolean;
  availability?: 'ACTIVE' | 'NOT_IN_LINEUP' | 'OUT' | 'UNKNOWN';
  inputsSource?: 'REAL' | 'ESTIMATED' | 'UNKNOWN';
  park: number;
  gamePk: number;
  vsLBa?: number;
  vsLAb?: number;
  vsRBa?: number;
  vsRAb?: number;
  bullpenBaa?: number;
  bullpenAb?: number;
  bullpenFatigue?: number;
  tempF?: number;
}

export interface MlbPitcherInput {
  name: string;
  hand: string;
  kPct: number;
  kBf?: number;
  recentIp?: number;
}

export interface MlbHitProjection {
  raw?: number;
  calP: number;
  rawP: number;
  ba: number;
  ab: number;
  platoon: 'advantage' | 'disadvantage' | 'neutral';
  k: number;
  ip: number;
  total: number;
  spWeight: number;
  splitReal: boolean;
  inputsReal: boolean;
}

export interface MlbGateResult {
  call: 'PLAY' | 'PASS';
  reasons: string[];
  warn: string[];
  why: string[];
  slotOnly: boolean;
  edge: number;
  fair: number;
  stake: string;
  calP: number;
  modelP: number;
  platoon: string;
  quality: string;
}

export interface MlbGameMatchup {
  gamePk: number;
  away: string;
  home: string;
  status: string;
  live: boolean;
  inning: number;
  park: number;
  confirmed: boolean;
  awaySp: MlbPitcherInput;
  homeSp: MlbPitcherInput;
  batters: MlbBatterInput[];
}

export interface MlbLedgerRow {
  date: string;
  gamePk: number;
  id: number;
  name: string;
  team: string;
  slot: number;
  call: 'PLAY' | 'PASS';
  over: string;
  under: string;
  hold: number;
  dec: number;
  modelP: number;
  fairP: number;
  blendedP: number;
  edge: number;
  quality: string;
  hit: number | null;
  result: string;
  void: boolean;
}
