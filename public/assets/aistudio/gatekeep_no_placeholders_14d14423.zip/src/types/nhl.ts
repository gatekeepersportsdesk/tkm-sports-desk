import { AvailabilityStatus, InputsSource } from '../lib/availability';

export interface NhlPlayerSnapshot {
  playerId: number;
  name: string;
  team: string;
  pos: 'F' | 'D';
  mu0: number;
  toiAvg: number;
  recentShots: number[];
  availability?: AvailabilityStatus;
  inputsSource?: InputsSource;
}

export interface NhlSkaterProjection {
  playerId: number;
  name: string;
  team: string;
  opp: string;
  pos: 'F' | 'D';
  mu0: number;
  oppFactor: number;
  scale: number;
  mu: number;
  defaultLine: number;
  probOver: Record<number, number>;
  recentShots: number[];
  toiAvg: number;
  availability?: AvailabilityStatus;
  inputsSource?: InputsSource;
}

export interface NhlGameMatchup {
  gameId: number;
  startTimeUtc: string;
  awayTeam: string;
  homeTeam: string;
  venue: string;
}

export interface NhlGradedResultRecord {
  date: string;
  playerId: number;
  playerName: string;
  team: string;
  opp: string;
  line: number;
  modelMu: number;
  probOver: number;
  oddsTaken: number | null;
  actualSog: number;
  hit: boolean;
}

export interface NhlSettings {
  edgeThreshold: number;
  maxJuice: number;
  showStabsOnly: boolean;
}
