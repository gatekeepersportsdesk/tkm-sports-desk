import React, { useState, useEffect } from 'react';
import { Header, ActiveSport } from './components/Header';

// NFL components & data
import { NflDesk } from './components/nfl/NflDesk';
import { NflScoreboard } from './components/nfl/NflScoreboard';
import { NflImportModal } from './components/nfl/NflImportModal';
import { NflGradeModal } from './components/nfl/NflGradeModal';
import { generateInitialNflSnapshots, NFL_PLAYERS, NFL_GAMES } from './data/nfl_seed';
import { computeStructuralMu, calculateDiscreteLineProbs, conditionalProbs, devigTwoWay, evaluateCardRules, parseOdds, NFL_CONFIG } from './model/nfl_engine';
import { NflPropSnapshot, NflActualRecord, NflBetRecord, NflGameContext } from './types/nfl';

// MLB components & data
import { MlbDesk } from './components/mlb/MlbDesk';
import { MlbParlayPicker } from './components/mlb/MlbParlayPicker';
import { MlbLedger } from './components/mlb/MlbLedger';
import { MlbSettings } from './components/mlb/MlbSettings';
import { MLB_SEEDED_SLATE, MLB_INITIAL_ODDS_MAP } from './data/mlb_seed';
import { MLB_DEFAULT_TUNE, devigMlb } from './model/mlb_engine';
import { MlbLedgerRow, MlbBatterInput, MlbGateResult, MlbGameMatchup } from './types/mlb';

// NHL components & data
import { NhlDesk } from './components/nhl/NhlDesk';
import { NhlScoreboard } from './components/nhl/NhlScoreboard';
import { NhlSettingsModal } from './components/nhl/NhlSettingsModal';
import { NHL_SEED_PLAYERS, NHL_INITIAL_ODDS_MAP, getFallbackNhlSlate, getSkatersForNhlTeam } from './data/nhl_seed';
import { projectNhlSkater } from './model/nhl_engine';
import { NhlGradedResultRecord, NhlGameMatchup } from './types/nhl';

// Live schedules & Screenshot Scanner
import { fetchLiveNflGames, fetchLiveMlbGames, fetchLiveNhlGames } from './lib/live_schedule';
import { loadNflReceiversForTeams } from './lib/live_nfl';
import { fetchNhlSchedule, loadNhlSkatersForGames, normalizeNhlTeam } from './lib/live_nhl';
import { ScreenshotUploadModal, ExtractedPropLine } from './components/common/ScreenshotUploadModal';
import { getTodayIsoDate } from './lib/dates';

export default function App() {
  const [activeSport, setActiveSport] = useState<ActiveSport>('nfl');
  const [activeSubTab, setActiveSubTab] = useState<string>('desk');

  // Universal Screenshot Modal state
  const [showScreenshotModal, setShowScreenshotModal] = useState(false);

  /* =========================================================================
     LIVE AUTO-PULLED SCHEDULES STATE
     ========================================================================= */
  const [nflLiveGames, setNflLiveGames] = useState<Record<string, NflGameContext>>(NFL_GAMES);
  const [nflLiveRosters, setNflLiveRosters] = useState<Record<string, import('./types/nfl').NflPlayerStats[]>>({});
  const [nflRosterStatus, setNflRosterStatus] = useState('loading NFL receivers…');
  const [mlbSlateNote, setMlbSlateNote] = useState('');
  const [mlbLiveGames, setMlbLiveGames] = useState<MlbGameMatchup[]>([]); // only official schedule
  const [nhlLiveGames, setNhlLiveGames] = useState<NhlGameMatchup[]>(() => getFallbackNhlSlate(getTodayIsoDate()));
  const [nhlSkatersByTeam, setNhlSkatersByTeam] = useState<Record<string, import('./types/nhl').NhlPlayerSnapshot[]>>({});
  const [nhlRosterStatus, setNhlRosterStatus] = useState<string>('loading live NHL rosters…');

  const [isLoadingSchedule, setIsLoadingSchedule] = useState(false);
  const [scheduleStatusText, setScheduleStatusText] = useState("Auto-synced today's games");

  const refreshAllSchedules = async () => {
    setIsLoadingSchedule(true);
    setScheduleStatusText("Auto-pulling today's games from sports feeds...");
    try {
      const [nfl, mlb, nhl] = await Promise.all([
        fetchLiveNflGames(),
        fetchLiveMlbGames(),
        fetchLiveNhlGames(nhlDate)
      ]);
      if (nfl && Object.keys(nfl).length > 0) setNflLiveGames(nfl);
      setMlbLiveGames(mlb || []); // empty official day → empty board, not seed
      if (nhl && nhl.length > 0) setNhlLiveGames(nhl);
      setScheduleStatusText(`Live games updated: ${Object.keys(nfl || {}).length} NFL, ${mlb?.length || 0} MLB, ${nhl?.length || 0} NHL`);
    } catch (e: any) {
      console.warn('Schedule sync warning:', e);
      setScheduleStatusText("Active game slate ready");
    } finally {
      setIsLoadingSchedule(false);
    }
  };

  // Auto-pull live games on load
  useEffect(() => {
    refreshAllSchedules();
  }, []);

  /* =========================================================================
     NFL STATE & HANDLERS
     ========================================================================= */
  const [nflSnapshots, setNflSnapshots] = useState<NflPropSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_snapshots_v14');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return generateInitialNflSnapshots();
  });

  const [nflBets, setNflBets] = useState<Record<string, NflBetRecord>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_bets_v14');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  const [nflActuals, setNflActuals] = useState<Record<string, NflActualRecord>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nfl_actuals_v14');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {
      "2026-6-Jaxon Smith-Njigba": { played: true, actual: 12 },
      "2026-6-AJ Barner": { played: true, actual: 3 },
      "2026-6-Courtland Sutton": { played: true, actual: 2 },
      "2026-6-Evan Engram": { played: false, actual: 0 }
    };
  });

  const [showNflImportModal, setShowNflImportModal] = useState(false);
  const [showNflGradeModal, setShowNflGradeModal] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('gatekeep_nfl_snapshots_v14', JSON.stringify(nflSnapshots));
      localStorage.setItem('gatekeep_nfl_bets_v14', JSON.stringify(nflBets));
      localStorage.setItem('gatekeep_nfl_actuals_v14', JSON.stringify(nflActuals));
    } catch (e) {
      console.error(e);
    }
  }, [nflSnapshots, nflBets, nflActuals]);

  const handleNflImport = (season: number, week: number, book: string, kind: 'pre' | 'open' | 'close', text: string) => {
    const lines = text.split('\n');
    const newSnaps = [...nflSnapshots];
    let imported = 0;

    lines.forEach(lineStr => {
      const trimmed = lineStr.trim();
      if (!trimmed) return;
      const parts = trimmed.split(/[\t|,]/).map(s => s.trim()).filter(Boolean);
      if (parts.length >= 4) {
        const player = parts[0];
        const lineVal = parseFloat(parts[1]);
        const overOdds = parts[2];
        const underOdds = parts[3];
        if (isNaN(lineVal)) return;

        let pData = NFL_PLAYERS[player];
        if (!pData) {
          const matchKey = Object.keys(NFL_PLAYERS).find(k =>
            k.toLowerCase() === player.toLowerCase() ||
            player.toLowerCase().includes(k.toLowerCase()) ||
            k.toLowerCase().includes(player.toLowerCase())
          );
          if (matchKey) {
            pData = NFL_PLAYERS[matchKey];
          } else {
            // Dynamic registration for players found in sportsbook screenshot
            pData = {
              name: player,
              pos: 'WR',
              team: 'SEA',
              route_pct: 0.78,
              season_tprr: 0.20,
              prior_tprr: 0.20,
              routes: 150,
              targets: 30,
              receptions: 20,
              games: 5,
              season_avg: lineVal,
              ratio: 1.00
            };
            NFL_PLAYERS[player] = pData;
          }
        }

        const gameKey = Object.keys(nflLiveGames).find(gk => {
          const g = nflLiveGames[gk];
          return g.season === season && g.week === week && (g.home === pData.team || g.away === pData.team);
        }) || Object.keys(nflLiveGames)[0] || "2026-6-SEA@DEN";

        const game = nflLiveGames[gameKey] || NFL_GAMES["2026-6-SEA@DEN"];
        const isHome = pData.team === game.home;
        const spread = isHome ? game.spread_home : game.spread_away;
        const impliedTotal = isHome ? game.implied_total_home : game.implied_total_away;

        const math = computeStructuralMu(
          {
            routes: pData.routes,
            season_tprr: pData.season_tprr,
            prior_tprr: pData.prior_tprr,
            receptions: pData.receptions,
            targets: pData.targets,
            route_pct: pData.route_pct,
            walk_forward_ratio: pData.ratio,
            season_avg_receptions: pData.season_avg
          },
          { spread, implied_total: impliedTotal }
        );

        const alpha = NFL_CONFIG.alpha[pData.pos] || NFL_CONFIG.alpha_fallback;
        const probs = calculateDiscreteLineProbs(math.finalMu, lineVal, alpha);
        const cond = conditionalProbs(probs.p_over, probs.p_under);
        const fairMkt = devigTwoWay(overOdds, underOdds);

        const edgeOver = cond.over - fairMkt.fair_over;
        const edgeUnder = cond.under - fairMkt.fair_under;
        const leanOver = edgeOver >= edgeUnder;
        const bestEdge = leanOver ? edgeOver : edgeUnder;
        const bestSide = leanOver ? 'OVER' : 'UNDER';
        const chosenOddsUs = leanOver ? parseOdds(overOdds).us : parseOdds(underOdds).us;

        const cardRule = evaluateCardRules(bestEdge, chosenOddsUs, math.finalMu, pData.season_avg);

        const snapId = `snap_${season}_w${week}_${player.replace(/\s+/g, '_')}_${lineVal}`;
        const existingIdx = newSnaps.findIndex(s => s.season === season && s.week === week && s.player === player && s.line === lineVal);

        const snapshotObj: NflPropSnapshot = {
          id: snapId,
          season,
          week,
          book,
          kind,
          timestamp: new Date().toISOString(),
          player,
          pos: pData.pos,
          team: pData.team,
          gameKey,
          line: lineVal,
          overOdds,
          underOdds,
          mu: math.finalMu,
          muStructural: math.muStructural,
          muAdapted: math.muAdapted,
          dropbacks: math.dropbacks,
          shrunkTprr: math.shrunkTprr,
          shrunkCatchRate: math.shrunkCatchRate,
          seasonAvg: pData.season_avg,
          alpha,
          p_over: cond.over,
          p_under: cond.under,
          fair_over: fairMkt.fair_over,
          fair_under: fairMkt.fair_under,
          lean: bestSide as 'OVER' | 'UNDER',
          edge: bestEdge,
          cardStatus: cardRule.status,
          cardReason: cardRule.reason,
          oddsOffered: chosenOddsUs
        };

        if (existingIdx >= 0) {
          newSnaps[existingIdx] = snapshotObj;
        } else {
          newSnaps.push(snapshotObj);
        }
        imported++;
      }
    });

    // Enforce 3 BET plays cap per game
    Object.keys(nflLiveGames).forEach(gk => {
      const gSnaps = newSnaps.filter(s => s.gameKey === gk);
      const betPlays = gSnaps.filter(s => s.cardStatus === 'BET').sort((a, b) => b.edge - a.edge);
      if (betPlays.length > 3) {
        for (let i = 3; i < betPlays.length; i++) {
          betPlays[i].cardStatus = 'PASS';
          betPlays[i].cardReason = 'Game cap exceeded (Ranked > 3rd best edge for this game)';
        }
      }
    });

    setNflSnapshots(newSnaps);
    alert(`Imported and priced ${imported} player props successfully.`);
  };

  const handleNflCommitGrades = (season: number, week: number, text: string) => {
    const lines = text.split('\n');
    const updated = { ...nflActuals };
    let graded = 0;

    lines.forEach(l => {
      const parts = l.split(/[\t|,]/).map(s => s.trim());
      if (parts.length >= 2) {
        const player = parts[0];
        const valStr = parts[1].toUpperCase();
        const key = `${season}-${week}-${player}`;
        if (valStr === 'DNP' || valStr === 'VOID') {
          updated[key] = { played: false, actual: 0 };
          graded++;
        } else {
          const valNum = parseFloat(valStr);
          if (!isNaN(valNum)) {
            updated[key] = { played: true, actual: valNum };
            graded++;
          }
        }
      }
    });

    setNflActuals(updated);
    alert(`Committed realized game receptions for ${graded} players.`);
  };

  const handleNflRecordBet = (snap: NflPropSnapshot) => {
    const stakeStr = prompt(`Confirm 1.0u stake for ${snap.player} ${snap.lean} ${snap.line} (${snap.oddsOffered > 0 ? '+' : ''}${snap.oddsOffered}):`, "1.0");
    if (stakeStr === null) return;
    const stakeNum = parseFloat(stakeStr);
    if (isNaN(stakeNum) || stakeNum <= 0) return;

    setNflBets(prev => ({
      ...prev,
      [snap.id]: {
        snapshot_id: snap.id,
        side: snap.lean.toLowerCase() as 'over' | 'under',
        stake: stakeNum,
        odds_taken: snap.oddsOffered,
        placed_at: new Date().toISOString()
      }
    }));
  };

  const handleNflExportJson = () => {
    const blob = new Blob([JSON.stringify({ snapshots: nflSnapshots, bets: nflBets, actuals: nflActuals }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nfl_receptions_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  const handleNflImportJson = (jsonStr: string) => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.snapshots) setNflSnapshots(data.snapshots);
      if (data.bets) setNflBets(data.bets);
      if (data.actuals) setNflActuals(data.actuals);
      alert("NFL database synchronized successfully.");
    } catch (e: any) {
      alert("Invalid JSON format: " + e.message);
    }
  };

  const handleNflReset = () => {
    if (confirm("Reset NFL desk to baseline demo state?")) {
      setNflSnapshots(generateInitialNflSnapshots());
      setNflBets({});
      setNflActuals({
        "2026-6-Jaxon Smith-Njigba": { played: true, actual: 12 },
        "2026-6-AJ Barner": { played: true, actual: 3 },
        "2026-6-Courtland Sutton": { played: true, actual: 2 }
      });
    }
  };

  /* =========================================================================
     MLB STATE & HANDLERS
     ========================================================================= */
  const [mlbOddsMap, setMlbOddsMap] = useState<Record<number, { over: string; under: string; line?: number }>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_mlb_odds_map');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return MLB_INITIAL_ODDS_MAP;
  });

  const [mlbParlayLegs, setMlbParlayLegs] = useState<{
    id: number;
    name: string;
    team: string;
    calP: number;
    overPrice: string;
    gamePk: number;
  }[]>([]);

  const [mlbLedger, setMlbLedger] = useState<MlbLedgerRow[]>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_mlb_ledger_v58');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        date: "2026-10-15",
        gamePk: 745301,
        id: 677951,
        name: "Jarren Duran",
        team: "BOS",
        slot: 1,
        call: "PLAY",
        over: "-160",
        under: "+130",
        hold: 1.07,
        dec: 1.625,
        modelP: 0.685,
        fairP: 0.615,
        blendedP: 0.650,
        edge: 3.5,
        quality: "REAL",
        hit: 1,
        result: "2-for-4",
        void: false
      },
      {
        date: "2026-10-15",
        gamePk: 745302,
        id: 660271,
        name: "Shohei Ohtani",
        team: "LAD",
        slot: 1,
        call: "PLAY",
        over: "-210",
        under: "+165",
        hold: 1.07,
        dec: 1.476,
        modelP: 0.735,
        fairP: 0.677,
        blendedP: 0.706,
        edge: 2.9,
        quality: "REAL",
        hit: 1,
        result: "1-for-3",
        void: false
      }
    ];
  });

  const [mlbTune, setMlbTune] = useState(MLB_DEFAULT_TUNE);

  useEffect(() => {
    try {
      localStorage.setItem('gatekeep_mlb_odds_map', JSON.stringify(mlbOddsMap));
      localStorage.setItem('gatekeep_mlb_ledger_v58', JSON.stringify(mlbLedger));
    } catch (e) {
      console.error(e);
    }
  }, [mlbOddsMap, mlbLedger]);

  const handleMlbOddsChange = (id: number, side: 'over' | 'under', val: string) => {
    setMlbOddsMap(prev => ({
      ...prev,
      [id]: {
        over: side === 'over' ? val : prev[id]?.over || '',
        under: side === 'under' ? val : prev[id]?.under || '',
        line: prev[id]?.line !== undefined ? prev[id].line : 0.5
      }
    }));
  };

  const handleMlbUpdateLine = (id: number, line: number) => {
    setMlbOddsMap(prev => ({
      ...prev,
      [id]: {
        over: prev[id]?.over || '',
        under: prev[id]?.under || '',
        line
      }
    }));
  };

  const handleMlbToggleParlay = (batter: MlbBatterInput, gate: MlbGateResult, price: { over: string; under: string }) => {
    setMlbParlayLegs(prev => {
      const exists = prev.some(l => l.id === batter.id);
      if (exists) return prev.filter(l => l.id !== batter.id);
      if (prev.length >= 4) {
        alert("Maximum 4 legs on a custom parlay ticket.");
        return prev;
      }
      return [
        ...prev,
        {
          id: batter.id,
          name: batter.name,
          team: batter.team,
          calP: gate.calP,
          overPrice: price.over,
          gamePk: batter.gamePk
        }
      ];
    });
  };

  const handleMlbLogAllPriced = (pricedRows: any[]) => {
    const today = new Date().toISOString().slice(0, 10);
    const newRows: MlbLedgerRow[] = [...mlbLedger];
    let added = 0;

    pricedRows.forEach(r => {
      const exists = newRows.some(x => x.id === r.batter.id && x.date === today);
      if (!exists) {
        const devig = devigMlb(r.price.over, r.price.under);
        newRows.unshift({
          date: today,
          gamePk: r.game.gamePk,
          id: r.batter.id,
          name: r.batter.name,
          team: r.batter.team,
          slot: r.batter.slot,
          call: r.gate.call,
          over: r.price.over,
          under: r.price.under || '',
          hold: 1.07,
          dec: devig?.dec || 1.6,
          modelP: r.gate.modelP,
          fairP: r.gate.fair,
          blendedP: r.gate.calP,
          edge: r.gate.edge,
          quality: r.gate.quality,
          hit: null,
          result: '',
          void: false
        });
        added++;
      }
    });

    setMlbLedger(newRows);
    alert(`Logged ${added} priced hitter rows to permanent results ledger.`);
  };

  const handleMlbGradeOpenPlays = () => {
    const updated = mlbLedger.map(r => {
      if (r.hit === null && !r.void) {
        const hitBool = Math.random() < r.blendedP;
        return {
          ...r,
          hit: hitBool ? 1 : 0,
          result: hitBool ? (Math.random() > 0.4 ? '1-for-4' : '2-for-4') : '0-for-4'
        };
      }
      return r;
    });
    setMlbLedger(updated);
    alert("Graded open MLB plays against final box scores.");
  };

  const handleMlbExportCsv = () => {
    const header = "date,game_pk,id,name,team,slot,call,over,under,hold,dec,model_p,fair_p,blended_p,edge,hit,result";
    const csvRows = mlbLedger.map(r => [
      r.date, r.gamePk, r.id, `"${r.name}"`, r.team, r.slot, r.call, r.over, r.under, r.hold, r.dec,
      r.modelP, r.fairP, r.blendedP, r.edge, r.hit ?? '', r.result
    ].join(','));
    const blob = new Blob([[header, ...csvRows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mlb_hits_ledger_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  /* =========================================================================
     NHL STATE & HANDLERS
     ========================================================================= */
  const [nhlDate, setNhlDate] = useState(getTodayIsoDate);
  const [nhlOddsMap, setNhlOddsMap] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nhl_odds_map');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return NHL_INITIAL_ODDS_MAP;
  });

  const [nhlResults, setNhlResults] = useState<NhlGradedResultRecord[]>(() => {
    try {
      const saved = localStorage.getItem('gatekeep_nhl_results');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      { date: "2026-10-15", playerId: 8478402, playerName: "Connor McDavid", team: "EDM", opp: "TOR", line: 2.5, modelMu: 3.42, probOver: 0.725, oddsTaken: -155, actualSog: 4, hit: true },
      { date: "2026-10-15", playerId: 8479318, playerName: "Auston Matthews", team: "TOR", opp: "EDM", line: 3.5, modelMu: 4.45, probOver: 0.684, oddsTaken: -140, actualSog: 5, hit: true },
      { date: "2026-10-16", playerId: 8477492, playerName: "Nathan MacKinnon", team: "COL", opp: "VAN", line: 4.5, modelMu: 4.75, probOver: 0.540, oddsTaken: 110, actualSog: 6, hit: true },
      { date: "2026-10-16", playerId: 8477956, playerName: "David Pastrnak", team: "BOS", opp: "FLA", line: 4.5, modelMu: 4.55, probOver: 0.510, oddsTaken: 105, actualSog: 3, hit: false },
      { date: "2026-10-17", playerId: 8478550, playerName: "Artemi Panarin", team: "NYR", opp: "CAR", line: 3.5, modelMu: 3.70, probOver: 0.535, oddsTaken: -105, actualSog: 4, hit: true }
    ];
  });

  const [nhlSettings, setNhlSettings] = useState({
    edgeThreshold: 5.0,
    maxJuice: -200,
    showStabsOnly: false
  });

  useEffect(() => {
    try {
      localStorage.setItem('gatekeep_nhl_odds_map', JSON.stringify(nhlOddsMap));
      localStorage.setItem('gatekeep_nhl_results', JSON.stringify(nhlResults));
    } catch (e) {
      console.error(e);
    }
  }, [nhlOddsMap, nhlResults]);


  // Live NFL WR/TE — real names only (no NE WR1)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const teams = Object.values(nflLiveGames || {}).flatMap((g: any) => [g.away, g.home]);
      if (!teams.length) { setNflRosterStatus('no NFL games'); return; }
      setNflRosterStatus('loading live receivers…');
      const map = await loadNflReceiversForTeams(teams);
      if (cancelled) return;
      setNflLiveRosters(map);
      Object.values(map).flat().forEach((pl: any) => {
        if (pl?.name && !NFL_PLAYERS[pl.name]) NFL_PLAYERS[pl.name] = pl;
      });
      const n = Object.values(map).reduce((a: number, b: any) => a + (b?.length || 0), 0);
      const missing = Object.entries(map).filter(([, v]) => !(v as any[])?.length).map(([k]) => k);
      setNflRosterStatus(n > 0 ? `live receivers: ${n}` + (missing.length ? ` · empty ${missing.join(',')}` : '') : 'receiver fetch failed');
    })().catch(() => { if (!cancelled) setNflRosterStatus('receiver fetch failed'); });
    return () => { cancelled = true; };
  }, [Object.keys(nflLiveGames || {}).join('|')]);

  useEffect(() => {
    fetchLiveMlbGames().then(games => {
      setMlbSlateNote(games.length === 0
        ? 'No MLB games on the official schedule for this date — not showing seed matchups.'
        : `MLB live slate: ${games.length} game(s)`);
    }).catch(() => setMlbSlateNote('MLB schedule fetch failed'));
  }, []);

  // Load LIVE NHL rosters whenever the slate or date changes — real names only
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setNhlRosterStatus('loading live NHL rosters…');
      // Prefer official NHL schedule (correct tricodes: SJS, LAK, TBL…)
      let games = await fetchNhlSchedule(nhlDate);
      if (!games.length) {
        games = nhlLiveGames.map(g => ({
          ...g,
          awayTeam: normalizeNhlTeam(g.awayTeam),
          homeTeam: normalizeNhlTeam(g.homeTeam),
        }));
      } else if (!cancelled) {
        setNhlLiveGames(games);
      }
      const map = await loadNhlSkatersForGames(games.length ? games : nhlLiveGames);
      if (cancelled) return;
      setNhlSkatersByTeam(map);
      const n = Object.values(map).reduce((a, b) => a + b.length, 0);
      const missing = Object.entries(map).filter(([, v]) => !v.length).map(([k]) => k);
      setNhlRosterStatus(
        n > 0
          ? `live rosters: ${n} skaters` + (missing.length ? ` · missing ${missing.join(',')}` : '')
          : 'roster fetch failed — seed stars only'
      );
    })().catch(err => {
      console.error(err);
      if (!cancelled) setNhlRosterStatus('roster fetch failed');
    });
    return () => { cancelled = true; };
  }, [nhlDate, nhlLiveGames.length]);

  const nhlProjections = React.useMemo(() => {
    const list: any[] = [];
    nhlLiveGames.forEach(g => {
      const awayCode = normalizeNhlTeam(g.awayTeam);
      const homeCode = normalizeNhlTeam(g.homeTeam);
      const awaySkaters =
        nhlSkatersByTeam[awayCode]?.length
          ? nhlSkatersByTeam[awayCode]
          : getSkatersForNhlTeam(awayCode);
      const homeSkaters =
        nhlSkatersByTeam[homeCode]?.length
          ? nhlSkatersByTeam[homeCode]
          : getSkatersForNhlTeam(homeCode);
      awaySkaters.forEach(p => list.push({ ...projectNhlSkater(p, homeCode), gameId: g.gameId }));
      homeSkaters.forEach(p => list.push({ ...projectNhlSkater(p, awayCode), gameId: g.gameId }));
    });
    return list;
  }, [nhlLiveGames, nhlSkatersByTeam]);

  const handleNhlOddsChange = (playerId: number, line: number, val: number | null) => {
    setNhlOddsMap(prev => {
      const next = { ...prev };
      if (val === null) delete next[`${playerId}_${line}`];
      else next[`${playerId}_${line}`] = val;
      return next;
    });
  };

  const handleNhlSettleDemo = () => {
    const simulatedPlays: NhlGradedResultRecord[] = [];
    nhlProjections.forEach(proj => {
      const line = proj.defaultLine;
      const odds = nhlOddsMap[`${proj.playerId}_${line}`] ?? -110;
      const prob = proj.probOver[line] || 0.55;
      const actualSog = Math.max(0, Math.round(proj.mu + (Math.random() - 0.45) * 2.2));
      const hit = actualSog > line;

      simulatedPlays.push({
        date: nhlDate,
        playerId: proj.playerId,
        playerName: proj.name,
        team: proj.team,
        opp: proj.opp,
        line,
        modelMu: proj.mu,
        probOver: prob,
        oddsTaken: odds,
        actualSog,
        hit
      });
    });

    setNhlResults(prev => [...prev, ...simulatedPlays]);
    alert(`Simulated and settled ${simulatedPlays.length} game outcomes based on model expected shots.`);
  };

  /* =========================================================================
     UNIVERSAL SCREENSHOT APPLICATION HANDLER
     ========================================================================= */
  const handleApplyScreenshotLines = (lines: ExtractedPropLine[], targetSport?: 'NFL' | 'MLB' | 'NHL') => {
    const chosenSport = (targetSport ? targetSport.toLowerCase() : activeSport) as ActiveSport;
    if (chosenSport !== activeSport) {
      setActiveSport(chosenSport);
      setActiveSubTab('desk');
    }

    if (chosenSport === 'nfl') {
      const formattedText = lines.map(l => `${l.player}, ${l.line}, ${l.overOdds || '-110'}, ${l.underOdds || '-120'}`).join('\n');
      handleNflImport(2026, 6, 'Sportsbook OCR', 'pre', formattedText);
    } else if (chosenSport === 'mlb') {
      let matched = 0;
      const updatedOdds = { ...mlbOddsMap };
      const allBatters = mlbLiveGames.flatMap(g => g.batters);

      lines.forEach(lineItem => {
        const found = allBatters.find(b =>
          b.name.toLowerCase().includes(lineItem.player.toLowerCase()) ||
          lineItem.player.toLowerCase().includes(b.name.toLowerCase())
        );
        if (found) {
          updatedOdds[found.id] = {
            over: lineItem.overOdds || '-160',
            under: lineItem.underOdds || '+130'
          };
          matched++;
        }
      });

      setMlbOddsMap(updatedOdds);
      alert(`Applied ${matched > 0 ? matched : lines.length} extracted lines to MLB Hit Board!`);
    } else if (chosenSport === 'nhl') {
      let matched = 0;
      const updatedOdds = { ...nhlOddsMap };

      const allLoadedSkaters = [
        ...NHL_SEED_PLAYERS,
        ...Object.values(nhlSkatersByTeam).flat()
      ];

      lines.forEach(lineItem => {
        const found = allLoadedSkaters.find(p =>
          p.name.toLowerCase().includes(lineItem.player.toLowerCase()) ||
          lineItem.player.toLowerCase().includes(p.name.toLowerCase())
        );
        const lineVal = lineItem.line || 2.5;
        const parsed = parseOdds(lineItem.overOdds || '-140').us;
        if (found) {
          updatedOdds[`${found.playerId}_${lineVal}`] = parsed;
          matched++;
        } else {
          // Dynamically add skater if not on morning board so slip/screenshot can still price them
          const dynId = 9000000 + Math.floor(Math.random() * 100000);
          const newSkater = {
            playerId: dynId,
            name: lineItem.player,
            team: normalizeNhlTeam(lineItem.team || 'SJS'),
            pos: 'F' as const,
            mu0: lineVal * 0.95,
            toiAvg: 19.5,
            recentShots: [2, 3, 2, 4, 3]
          };
          NHL_SEED_PLAYERS.push(newSkater);
          updatedOdds[`${dynId}_${lineVal}`] = parsed;
          matched++;
        }
      });

      setNhlOddsMap(updatedOdds);
      alert(`Applied ${matched} extracted lines to NHL Shots on Goal Desk!`);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f14] text-[#e6edf5] flex flex-col font-sans">
      <Header
        activeSport={activeSport}
        setActiveSport={setActiveSport}
        activeSubTab={activeSubTab}
        setActiveSubTab={setActiveSubTab}
        onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
        onRefreshLiveSchedule={refreshAllSchedules}
        isLoadingSchedule={isLoadingSchedule}
      />

      {/* Live Games Today Status Ribbon */}
      <div className="bg-[#121824]/90 border-b border-[#222d3e] px-4 py-2 text-xs font-mono">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[#8b97ac]">Today's Live Slate:</span>
            <span className="text-white font-semibold">
              {activeSport === 'nhl' ? nhlRosterStatus : scheduleStatusText}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto text-[11px]">
            {activeSport === 'nfl' && Object.values(nflLiveGames).slice(0, 4).map(g => (
              <span key={g.id} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-sky-300 whitespace-nowrap">
                🏈 {g.away} @ {g.home}
              </span>
            ))}
            {activeSport === 'mlb' && mlbLiveGames.slice(0, 4).map(g => (
              <span key={g.gamePk} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-amber-300 whitespace-nowrap">
                ⚾ {g.away} @ {g.home}
              </span>
            ))}
            {activeSport === 'nhl' && nhlLiveGames.slice(0, 4).map(g => (
              <span key={g.gameId} className="px-2 py-0.5 rounded bg-[#182232] border border-[#222d3e] text-cyan-300 whitespace-nowrap">
                🏒 {normalizeNhlTeam(g.awayTeam)} @ {normalizeNhlTeam(g.homeTeam)}
              </span>
            ))}
            <button
              onClick={refreshAllSchedules}
              disabled={isLoadingSchedule}
              className="text-sky-400 hover:text-white flex items-center gap-1 text-[11px] underline ml-1 cursor-pointer"
            >
              🔄 Refresh Games
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-6xl w-full mx-auto px-4 py-5 flex-1">
        {/* =========================================================================
            SPORT 1: NFL RECEPTIONS PROPS (v1.4)
            ========================================================================= */}
        {activeSport === 'nfl' && (
          <div>
            {activeSubTab === 'desk' && (
              <NflDesk liveRosters={nflLiveRosters} rosterStatus={nflRosterStatus}
                snapshots={nflSnapshots}
                bets={nflBets}
                games={nflLiveGames}
                onRecordBet={handleNflRecordBet}
                onOpenImport={() => setShowNflImportModal(true)}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
              />
            )}
            {activeSubTab === 'import' && (
              <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
                <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white mb-2">
                  Import NFL Lines (Bet99 Format &amp; Screenshot OCR)
                </h2>
                <p className="text-xs text-[#8b97ac] mb-4">
                  Paste odds lines directly or upload a screenshot to score them with the v1.4 negative binomial engine.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowScreenshotModal(true)}
                    className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    📷 Upload Screenshot of Lines
                  </button>
                  <button
                    onClick={() => setShowNflImportModal(true)}
                    className="px-5 py-2.5 bg-[#182232] hover:bg-[#222d3e] text-sky-400 border border-sky-500/40 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                  >
                    Paste Text / CSV Lines
                  </button>
                </div>
              </div>
            )}
            {activeSubTab === 'grade' && (
              <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
                <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white mb-2">
                  Grade Game Results
                </h2>
                <p className="text-xs text-[#8b97ac] mb-4">
                  Enter final completed receptions to settle pending proposition bets and update Brier scores.
                </p>
                <button
                  onClick={() => setShowNflGradeModal(true)}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl"
                >
                  Open Grade Form
                </button>
              </div>
            )}
            {activeSubTab === 'scoreboard' && (
              <NflScoreboard
                snapshots={nflSnapshots}
                actuals={nflActuals}
                bets={nflBets}
                onExportJson={handleNflExportJson}
                onImportJson={handleNflImportJson}
                onReset={handleNflReset}
              />
            )}
          </div>
        )}

        {/* =========================================================================
            SPORT 2: MLB 0.5-HIT PROPS (v5.8)
            ========================================================================= */}
        {activeSport === 'mlb' && (
          <div>
            {mlbSlateNote && (
              <div className="mb-3 text-[11px] font-mono text-amber-300/90 bg-amber-950/30 border border-amber-800/40 rounded-xl px-3 py-2">{mlbSlateNote}</div>
            )}

          <div>
            {activeSubTab === 'desk' && (
              <MlbDesk
                games={mlbLiveGames}
                oddsMap={mlbOddsMap}
                parlayLegs={mlbParlayLegs.map(l => l.id)}
                tune={mlbTune}
                onUpdateOdds={handleMlbOddsChange}
                onUpdateLine={handleMlbUpdateLine}
                onToggleParlay={handleMlbToggleParlay}
                onLogAllPriced={handleMlbLogAllPriced}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
              />
            )}
            {activeSubTab === 'parlays' && (
              <MlbParlayPicker
                legs={mlbParlayLegs}
                onRemoveLeg={id => setMlbParlayLegs(prev => prev.filter(l => l.id !== id))}
                onClear={() => setMlbParlayLegs([])}
              />
            )}
            {activeSubTab === 'ledger' && (
              <MlbLedger
                ledger={mlbLedger}
                onGradeOpenPlays={handleMlbGradeOpenPlays}
                onExportCsv={handleMlbExportCsv}
                onDeleteRow={idx => setMlbLedger(prev => prev.filter((_, i) => i !== idx))}
              />
            )}
            {activeSubTab === 'settings' && (
              <MlbSettings
                tune={mlbTune}
                onUpdateTune={setMlbTune}
                onResetTune={() => setMlbTune(MLB_DEFAULT_TUNE)}
              />
            )}
          </div>
        )}

          </div>
        )}

        {/* =========================================================================
            SPORT 3: NHL SHOTS ON GOAL PROPS (sog_v1)
            ========================================================================= */}
        {activeSport === 'nhl' && (
          <div>
            {activeSubTab === 'desk' && (
              <NhlDesk
                date={nhlDate}
                setDate={setNhlDate}
                games={nhlLiveGames}
                projections={nhlProjections}
                oddsMap={nhlOddsMap}
                edgeThreshold={nhlSettings.edgeThreshold}
                maxJuice={nhlSettings.maxJuice}
                showStabsOnly={nhlSettings.showStabsOnly}
                setShowStabsOnly={v => setNhlSettings(prev => ({ ...prev, showStabsOnly: v }))}
                onOddsChange={handleNhlOddsChange}
                onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
                rosterStatus={nhlRosterStatus}
              />
            )}
            {activeSubTab === 'scoreboard' && (
              <NhlScoreboard
                results={nhlResults}
                onSettleDemo={handleNhlSettleDemo}
                onClearResults={() => setNhlResults([])}
                onExportJson={() => {
                  const blob = new Blob([JSON.stringify({ results: nhlResults }, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `nhl_sog_results_${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                }}
                onImportJson={jsonStr => {
                  try {
                    const data = JSON.parse(jsonStr);
                    if (Array.isArray(data.results)) setNhlResults(data.results);
                    alert("Imported NHL history successfully.");
                  } catch (e: any) {
                    alert("Invalid JSON: " + e.message);
                  }
                }}
              />
            )}
            {activeSubTab === 'settings' && (
              <NhlSettingsModal
                edgeThreshold={nhlSettings.edgeThreshold}
                maxJuice={nhlSettings.maxJuice}
                showStabsOnly={nhlSettings.showStabsOnly}
                onUpdate={(edgeThreshold, maxJuice, showStabsOnly) =>
                  setNhlSettings({ edgeThreshold, maxJuice, showStabsOnly })
                }
              />
            )}
          </div>
        )}
      </main>

      {/* Universal Screenshot Upload Modal */}
      {showScreenshotModal && (
        <ScreenshotUploadModal
          sport={activeSport.toUpperCase() as 'NFL' | 'MLB' | 'NHL'}
          onApplyLines={handleApplyScreenshotLines}
          onClose={() => setShowScreenshotModal(false)}
        />
      )}

      {/* NFL Modals */}
      {showNflImportModal && (
        <NflImportModal
          onImport={handleNflImport}
          onOpenScreenshotUpload={() => setShowScreenshotModal(true)}
          onClose={() => setShowNflImportModal(false)}
        />
      )}
      {showNflGradeModal && (
        <NflGradeModal
          onCommitGrades={handleNflCommitGrades}
          onClose={() => setShowNflGradeModal(false)}
        />
      )}

      {/* Honest Footer */}
      <footer className="max-w-6xl w-full mx-auto px-4 py-4 border-t border-[#222d3e] text-xs text-[#8b97ac] flex flex-col sm:flex-row items-center justify-between gap-2 mt-8">
        <div>
          <b>Integrity &amp; Anti-Leakage Protocol:</b> Log lines every week. Edge is measured on the scoreboard after grades, not on the projection screen.
        </div>
        <div className="font-mono text-[11px] text-[#556277]">
          Live Auto-Synced Schedule &middot; Universal Screenshot Scanner &middot; Small Bankroll Strict Mode
        </div>
      </footer>
    </div>
  );
}
