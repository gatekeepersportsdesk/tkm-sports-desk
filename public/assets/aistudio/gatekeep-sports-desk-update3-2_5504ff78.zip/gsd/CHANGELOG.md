# Update 3b — NHL fitted on your MoneyPuck files

The files arrived. `scripts/fit_nhl_moneypuck.py` was run on `2025.csv` (47,212 skater-games) + `2026.csv` (6,011; only ~167 games so far this season). Population = skaters averaging 12+ min (the app prices ~top-16 per team); regular season only. Because 2026 is a week old, the larger share of rows is a first-half/second-half split of 2025 (first half acts as "last season"). All numbers below are walk-forward and scored on held-out skaters.

| Parameter | Was | Now | Evidence |
|---|---|---|---|
| Shots r | 15.13 (frozen) | 16 | held-out LL +0.0014/row; coverage 50.0/80.2/90.0 (was 50.1/80.4/90.5) — the old value was already close |
| Shots shrink K / prior K | 20 / 20 | 20 / 10 | |
| Points r | 12 (prior) | **36** | LL +0.0038/row; 80% coverage 79.8 (was 80.6); the old r was too fat |
| Points shrink K / prior K | 40 / 40 | 30 / 10 | |
| Forward / Defense shots per game prior | 2.0 / 1.6 | 1.90 / **1.30** | defense was overstated by ~19% |
| Forward / Defense points per game prior | 0.45 / 0.25 | **0.59 / 0.35** | |
| Shots↔points correlation (copula ρ) | 0.35 (guess) | 0.28 | matched to observed residual correlation 0.218 on the app's own copula scale |

Also tested on this data:
* **5v5 + power-play split rate vs all-situations rate:** adds nothing (best blend weight 0). Not wired in.
* **Live opponent shots-against factor:** real signal. +0.0015 to +0.0022 LL/row in both seasons, pass-through exponent about 1 at K 10–20, so the app's K = 15 stands. (`scripts/nhl_opp_factor_test.py`)

Fix that matters: tuning is now stored as overrides only (`gatekeep_nhl_tuning_v2`). The old key stored every default and would have pinned the old priors on top of the fitted ones.

Limits, plainly: the gains are small except for points dispersion and the defense prior; 2026 has only ~5k scorable rows so far, and 2025 rows come from a pseudo-split rather than a true prior season. Re-run the script every few weeks as 2026 fills in. xGoals/corsi were not used (no measured gain was tested). Fitted values are still overridable in Settings.

---

# Update 3 — NHL calibration pipeline, NFL feature evidence

## NHL: fitted from your MoneyPuck files (2025 full season + 2026 to date)
`scripts/fit_nhl_moneypuck.py` ran on `2025.csv` (1,312 games) and `2026.csv` (167 games so far), regular season only, skaters averaging 12+ min (the population the app prices). Walk-forward only; held-out = player cross-fit (fit on half the skaters, score the other half).

| Parameter | Was | Now | Evidence |
|---|---|---|---|
| SOG dispersion r | 15.13 (frozen) | **16** | held-out LL +0.0014/row; real-2026-only run gives 17 and no gain: the old value was essentially right |
| SOG shrink K / prior K | 20 / 20 | **20 / 10** | same |
| Points dispersion r | 12 (prior) | **36** | held-out LL +0.0038/row; real-2026-only run gives 24. Points were far less over-dispersed than assumed |
| Points shrink K / prior K | 40 / 40 | **30 / 10** | real-2026-only run prefers 60: treat as 30-60 |
| Position priors (per game) | F 2.0 / D 1.6 SOG; F .45 / D .25 pts | **F 1.90 / D 1.30 SOG; F .59 / D .35 pts** | league means for 12+ min skaters |
| Shots↔points ρ | 0.35 (prior) | **0.276** | matched on the app's own copula scale; real-2026-only run gives 0.258 |
* Held-out PIT coverage 50/80/90: SOG 50.0/80.2/90.0, points 50.0/79.8/89.9 (defaults were 50.1/80.4/90.5 and 50.7/80.6/90.6, so coverage was already fine; the gain is sharper probabilities, not new calibration).
* **5v5 + power-play split rate did not beat the all-situations rate** (best blend weight 0). Not adopted.
* Caveats: 80% of the fitted rows come from a first-half/second-half split of 2025 (less than a full prior season, so the Ks are approximate); 2026 is only ~17 games per team, so re-run the script every few weeks. Gains are small per row. The big corrections are points r and the position priors.
* The app overlays these (bounds-checked) and shows them green "fitted from data" in NHL Settings. Opponent-factor K, stale-table weight and Monte Carlo draws are still settings/priors. `skaters-5.csv` is a season summary and was not needed.
* The script originally checked itself on synthetic data with known answers (ρ recovered 0.403 vs 0.40).

## NFL: tested every suggested feature; none earned a place
Free data only (nflverse play-by-play + FTN charting for blitzers). Each feature uses games before the week, shrunk to league mean, fit on one season and scored on the next (`scripts/nfl_experiments/`).
| Feature | Result (log-lik per row, + = better) |
|---|---|
| EPA/play, success rate, sack+QB-hit rate, blitz rate, play-action, pace (all) | −0.0003 (2025), +0.0001 (2026) |
| Best single features | under 0.002 and sign flips between seasons |
| Teammate absence / target redistribution | first run looked like +0.0011 — that was **a name-matching bug creating phantom absences**; fixed it was −0.0002 |
| Trailing 3-game receptions / targets | +0.0012 (2025), −0.0053 (2026) |
So v1.5 stays as is. The mean already sits on spread, total, routes and trailing production, and these add noise rather than signal at this sample. Re-test around week 12 of 2026. (Note: real pressure and coverage-vs-route data is paid charting; sack+hit rate is only a proxy, and FTN blitz data is free but CC-BY-SA.)

## Honest limits
* The Monte Carlo layer is still a copula over validated marginals, not a snap-by-snap or Dirichlet-multinomial game simulator. Nothing measured so far says it would improve single-leg prices; it would matter for correlated NFL props. Not built this round.
* Not verified: UI rendering, box-score grading on live games, screenshot OCR on a real slip.
* Tests: 80 passing (added the fit-overlay test). `tsc` clean on engine/tests; the Settings modal only shows stub-type noise in my sandbox.

---

# Update 2 — tab reset, OCR integrity, sampling layer, NHL tuning

## Bugs found and fixed
* **"Kicked back to NFL"** — two causes. (1) `activeSport` lived only in React state, so any reload / hot reload / remount reset it to NFL; it is now persisted (`gatekeep_nav_v1`) and validated on load. (2) The screenshot scanner let Gemini's guess at the sport (`detectedSport`) override the target you picked, and Apply then switched the whole app to that sport (often NFL). The guess is now only a hint banner; your selection is never overridden.
* **Fabricated lines in the scanner (missed in the first pass).** On any OCR failure — and whenever you clicked a sport pill with lines loaded — the modal injected hard-coded sample lines with fake odds (JSN, Matthews, Judge…), and "Try Sample Slip" fed a fake slip through OCR. All removed. A failed scan now says so and adds nothing; manual rows start blank (no pre-filled -115/-115); Apply requires a player and at least one price.
* A render error in one desk can no longer blank the app: an error boundary wraps the content area (the sport switcher stays alive) and resets when you change tab.
* OCR prompt now returns a per-line `prop` (shots / points), tells the model not to guess unreadable values; NHL rows get a SOG/PTS market selector in the review table.

## Sampling layer (`src/model/sampler.ts`)
* Seeded Gaussian copula over the existing, validated negative-binomial marginals. Marginals stay exactly as priced (tested: sampled mean/variance/P(over) match the closed form); only the dependence between legs is added. Deterministic (same inputs → same answer).
* Why a copula rather than a from-scratch game simulator: the NFL marginals were validated by backtest and interval coverage; a game simulator would have to re-earn that calibration. Joint questions are where simulation matters, so that is where it is used. Closed form remains the path for single-leg prices.
* **Measured on real data** (`scripts/estimate_nfl_corr.ts`, nflverse 2025 wk3-18 + 2026 wk3-6, walk-forward residuals): WR/TE teammates ρ = +0.027 (±0.016), WR-WR +0.040, WR-TE +0.028, opposing receivers −0.001 (±0.015). So teammate receptions are NOT meaningfully negatively correlated once game script is in the mean, and an NFL stack is close to independent. The sampler's NFL priors use these numbers.
* **NHL same-skater shots↔points ρ = 0.35 is a PRIOR (not measured)** — the NHL feed could not be reached to measure it. Editable in Settings.
* UI: NHL player drawer has a shots + points combo panel (over/under any SOG line + any points line, joint vs independent, fair price, ±MC error). NFL has the library (`jointProbability`, `teamCorrelation`) but no screen yet.

## NHL Settings now expose every prior / frozen value
SOG r (frozen from sog_v1), points r, shrink Ks, position priors, opponent-factor K, stale-table weight, shots↔points ρ, Monte Carlo draws — each labelled "frozen" / "prior — not fitted" / "prior — not measured" / "setting", persisted, with Reset. Ledger rows keep the r they were priced with.

## Verified here
`tsc` clean, **79 tests** passing (sampler, OCR cleaning, tuning added), server + app bundle with esbuild.
Not verified: UI rendering, and the browser behaviour of the error boundary / persistence (logic only).

---

# Gatekeep Sports Desk — audit & fix pass (NFL v1.5 · MLB v5.9 · NHL sog_v2)

Benchmark in mind: RotoBot-style honesty — distributions not point guesses, calibration you can check,
injury/availability awareness, and no number on screen that did not come from data.

## What was wrong everywhere (and is now fixed in all three sports)
| Problem | Fix |
|---|---|
| "Edge" measured against the de-vigged line was treated as a bet signal, but you pay the vig | Every sport now requires **EV > 0 at the price offered** (shared `src/lib/odds.ts`) |
| Blank / garbage odds silently became +100 (fake 50% market, fake two-way) | Parsers return `null`; unpriced rows are model-only and can never qualify |
| Estimated / guessed inputs could still show BET / PLAY / STAB | One universal gate (availability → input quality → edge). ESTIMATED can never qualify |
| Hand-typed injury / roster lists | Removed. Availability comes from live feeds; no feed = UNKNOWN = cannot qualify |
| Random "settle demo" results flattered the scoreboards | Removed. Grading is from official box scores / nflverse. Legacy rows are tagged DEMO and excluded from every metric |
| Odds saved in localStorage with no date (yesterday's price on today's line) | Odds maps are date-stamped and discarded on another day |
| No way to tell if the model is calibrated | Shared calibration lib: Brier vs market, reliability bins, randomized-PIT 50/80/90% interval coverage |

## NFL receptions (v1.4 → v1.5) — validated on real nflverse data
* Real ingestion (`stats_player_week`, `snap_counts`, `injuries`, `games`): routes proxy = team dropbacks × snap %, TPRR shrunk to prior season, walk-forward (week W sees only weeks < W).
* Backtest reproduced the 2025 WR over-prediction; fixed with an in-season **decay-weighted** position ratio (actual/mu 0.935 → 0.991). Carrying the prior-season ratio made 2026 worse, so it is off.
* Early-season dispersion inflation α·(1 + 2.5/games). WR α .10 / TE α .125 re-validated.
* Game cap (3 BETs/game), one-sided price can never be BET, no fabricated -115/-115 baseline rows, receiver/team resolution bug fixed, schedule from nflverse (no hard-coded week, no ESPN spread guessing), real grades from nflverse.

## MLB hits (v5.8 → v5.9)
* Line probabilities from the PA model's hit-count distribution (Poisson-binomial), not a Poisson shortcut, so 1.5 / 2.5 lines are priced correctly (still not PLAY until you opt in).
* Real batter/pitcher inputs from statsapi (season, game log, platoon splits, K%, recent IP). Missing pieces → EST → PASS.
* PLAY requires confirmed lineup, slot 1–3, price window, **EV > 0**, REAL inputs.
* Ledger grades from official box scores (DNP = void, postponed = void); no random grading.
* Parlay picker: EV at the offered price; same-game haircut applied only when no quoted price; deterministic simulation.
* Reference-cache key now includes the tune (changing a setting no longer returns stale numbers).

## NHL (sog_v1 → sog_v2) — and the points market you asked for
* **Points market added** (NB, r = 12 is a prior to calibrate; lines 0.5 / 1.5 / 2.5). Shots / Points toggle on the desk.
* Skater rates are **shrunk** toward last season and a position prior (a 4-game 6.0 shots/game start is no longer priced as a 6.0 shooter).
* Real game logs (last 10 games) replace the fake `[round(mu) ×5]` form chips.
* Opponent factor from live shots-against / goals-against, shrunk by games played; the old hand-typed table is a labelled half-weight fallback.
* **FADE** now needs a real under price and +EV; over/under entered separately and de-vigged together.
* Removed: the 2024 hand-typed roster (players on teams they no longer play for), seeded odds, the fake fallback slate, ESPN game ids (can't be graded), `mu from the line` for screenshot players (now ESTIMATED from the position prior, cannot qualify), mutation of the seed array.
* Ledger: log priced rows → grade from the official box score; scoreboard shows per-market calibration, interval coverage, W-L and units for STAB/FADE only.

## Verified here
* `tsc` clean, **65 / 65 tests** (NFL 17, MLB 19, NHL 29) incl. fixtures for every parser and grader; `server.ts` and the whole app bundle with esbuild.
* NFL pipeline run end-to-end on real nflverse 2024-2026 files.

## NOT verified (be straight about it)
* The sandbox cannot reach the NHL, MLB or ESPN hosts. Those fetchers/parsers are tested against fixtures that follow the documented JSON shapes, **not live responses**. First run on your machine: open each tab and read the status chips (they say exactly which feed failed).
* The UI was typechecked and bundled, **not rendered** (React isn't installable offline here).
* NHL has no historical backtest here: shrinkage K (20 / 40), position priors, the points `r = 12`, and the opponent clamp are sensible priors, not fitted values. Let the ledger's reliability bins and interval coverage tell you what to move; don't trust them before ~200+ graded rows per market.
* ESPN's injury JSON shape was written defensively but is the least certain parser.

## Setup
`npm install && npm run dev` (needs Node 20+; `GEMINI_API_KEY` for screenshot OCR). Tests: `npx tsx --test src/model/*.test.ts`.
