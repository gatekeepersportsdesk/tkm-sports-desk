"""
NBA + NFL model accuracy upgrades
Uses free data: nba_api and nfl_data_py
Drop-in logic for your existing negative binomial models.
"""

import pandas as pd
import numpy as np

# ==================== NBA ====================
def nba_adjusted_mu(player_recent_logs, opponent_def_rating, league_avg_def=110.0, pace_factor=1.0):
    """
    player_recent_logs: DataFrame with columns ['PTS','AST','REB','FG3M','MIN'] sorted newest first
    Returns adjusted mean for the stat you pass.
    """
    if len(player_recent_logs) == 0:
        return None
    
    last5 = player_recent_logs.head(5)
    last10 = player_recent_logs.head(10)
    season = player_recent_logs
    
    def weighted(stat):
        return (0.55 * last5[stat].mean() +
                0.30 * last10[stat].mean() +
                0.15 * season[stat].mean())
    
    # Opponent adjustment (lower def rating = easier)
    opp_factor = league_avg_def / max(opponent_def_rating, 90)
    return weighted, opp_factor * pace_factor

# Example usage for points:
# mu_pts, factor = nba_adjusted_mu(logs, opp_def_rating=108.5, pace_factor=1.02)
# final_mu = mu_pts * factor

# ==================== NFL RECEPTIONS ====================
def nfl_receptions_mu(target_share, team_pass_attempts_proj, recent_rec_per_game, blend=0.70):
    """
    target_share: player's share of team targets (0-1)
    team_pass_attempts_proj: projected pass attempts for the game
    recent_rec_per_game: last 4-6 games receptions average
    """
    target_driven = target_share * team_pass_attempts_proj
    blended = blend * target_driven + (1 - blend) * recent_rec_per_game
    return blended

# Example:
# mu = nfl_receptions_mu(target_share=0.22, team_pass_attempts_proj=34, recent_rec_per_game=5.1)
# Then feed mu into your negative binomial

print("NBA + NFL adjustment functions ready.")
print("See comments for drop-in usage.")
