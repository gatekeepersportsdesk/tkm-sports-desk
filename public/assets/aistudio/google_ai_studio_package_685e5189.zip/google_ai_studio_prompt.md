# Prompt for Google AI Studio — Player Prop Model Upgrades

You are an expert sports modeling assistant. I am giving you a package of changes I have already made to my negative binomial player-prop models (NHL shots/points, NBA props, NFL receptions) plus the supporting data. Your job is to:

1. Review the changes and the reasons.
2. Validate or refine the logic.
3. Produce clean, production-ready code snippets I can drop into my existing models.
4. Suggest any additional high-ROI improvements that use only free data sources (MoneyPuck, nba_api, nfl_data_py/nflverse).

## Context
I bet player props close to game time. I do not need opening/closing line value. I need accurate directional projections (Over/Under) at the moment I research and bet.

Current sports and markets:
- NHL: shots on goal, points
- NBA: points, assists, rebounds, PRA, 3PM
- NFL: receptions (considering yards later)

## Changes already made (and why)

### NHL (tested on 132 graded props)
**Change**
- Shots: mu = 0.65 × modelMu + 0.35 × MoneyPuck shots/game
- Points: mu = 0.80 × modelMu + 0.20 × MoneyPuck points/game
- Increase negative binomial dispersion (r) by ~15-20% on shots

**Reason**
Pure recent-form model over-projected shots (bias +0.22) and produced too many false overs on players who finished with 0 shots. Blending with the player’s established MoneyPuck rate anchors extremes while keeping game-specific signal.

**Result on graded sample**
- Overall hit: 50.0% → 53.8%
- Shots: 45.5% → 48.5%
- Points: 54.5% → 59.1%

### NBA (nba_api)
**Change**
- Weighted mean: 55% last-5 + 30% last-10 + 15% season rate
- Multiply by (league_avg_def / opponent_def_rating) × pace_factor

**Reason**
Equal-weighted recent averages over-react to small samples and ignore matchup. nba_api supplies both player game logs and opponent defensive ratings for free.

### NFL Receptions (nfl_data_py)
**Change**
- Primary mean = target_share × projected team pass attempts
- Blend: 70% target-driven + 30% recent receptions/game

**Reason**
Targets are the stronger predictor of receptions. Pure past receptions miss opportunity and game script. nfl_data_py weekly data contains both.

## Files in the package
- nhl_corrected_projections.csv — original modelMu vs corrected mu_final on every graded NHL prop
- nhl_player_rates_moneypuck.csv — clean historical rates (shots/game, points/game, TOI) 2021-2026
- nba_nfl_model_changes.py — drop-in Python functions for the NBA and NFL adjustments
- ALL_CHANGES_AND_REASONS.md — full summary

## What I need from you
1. Clean, commented Python functions that implement the NHL blend, NBA weighting, and NFL target-share logic.
2. Any small refinements you would make to the weights or logic, with clear reasons.
3. A short note on how these changes should affect the parlay/SGP picker (I understand correlation still matters).
4. Output the code so I can copy-paste it directly into my pipeline.

Be concise and practical. Focus on accuracy improvements that use only the free data sources listed above.
