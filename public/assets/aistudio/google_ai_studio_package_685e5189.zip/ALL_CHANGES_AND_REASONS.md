# All Model Changes — Single Reference
Drop this folder into Claude (or any other AI) for full context.

## NHL (tested on 132 graded props)
### Change
- Shots: mu = 0.65 × modelMu + 0.35 × MoneyPuck shots/game
- Points: mu = 0.80 × modelMu + 0.20 × MoneyPuck points/game
- Increase negative binomial dispersion (r) ~15-20% on shots

### Reason
Pure recent-form model over-projected shots (bias +0.22) and missed on zero-shot games. Historical rate anchors extremes while keeping game-specific signal.

### Result
- Overall: 50.0% → 53.8%
- Shots: 45.5% → 48.5%
- Points: 54.5% → 59.1%

## NBA (nba_api)
### Change
- 55% last-5 + 30% last-10 + 15% season rate
- Multiply by (league_avg_def / opponent_def_rating) × pace_factor

### Reason
Equal-weighted recent averages over-react to small samples and ignore matchup. nba_api supplies both player logs and opponent numbers.

## NFL Receptions (nfl_data_py)
### Change
- Primary: target_share × projected team pass attempts
- Blend: 70% target-driven + 30% recent receptions/game

### Reason
Targets are the stronger predictor. Pure past receptions miss opportunity and game script.

## Parlay Picker
No direct code change. Accuracy of the individual prop models is the main lever. Better component probabilities improve SGP selection, but correlation and book pricing still dominate.

## Files in this package
- nhl_corrected_projections.csv — before/after on every graded NHL prop
- nhl_player_rates_moneypuck.csv — clean historical rates
- nba_nfl_model_changes.py — drop-in functions for NBA and NFL
- MODEL_CHANGES.md / NBA_NFL_CHANGES.md — shorter summaries
