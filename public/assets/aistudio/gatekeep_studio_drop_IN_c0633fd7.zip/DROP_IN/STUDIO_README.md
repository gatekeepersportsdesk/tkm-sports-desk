# Gatekeep Studio drop-in (odds + gap fixes)

Copy these paths into your Google AI Studio Gatekeep project (merge/overwrite same paths):

```
src/App.tsx
src/lib/parlay_core.ts
src/components/common/OddsImportPanel.tsx   # if present in this pack
CHANGELOG.md
scripts/odds/                              # entire folder
```

## Fixed in this pack
1. **NFL Parlay Lab** — `pricedNflLegs` from `nflSnapshots` via `legsFromNflSnapshots` (no more `[]`).
2. **Paper tickets** — NFL priced legs included in the daily paper pool.
3. **CHANGELOG** — FINAL PACKAGE header.
4. **scripts/odds/** — Bet99/Bet365 local pipeline (parse table / write JSON / optional Playwright fetch). App stays scrape-free.

## Odds (your machine)
```bash
cd scripts/odds
python3 write_gatekeep_json.py --in examples/sample_nba.json --out out
# Gatekeep → Odds import → out/odds_nba_YYYY-MM-DD.json → Apply

# From a copied table:
python3 parse_table.py --text copied.txt --book bet99 --sport nba --out raw.json
python3 write_gatekeep_json.py --in raw.json --out out
```

Cadence: 2–3×/day pre-match only. See scripts/odds/README.md.
