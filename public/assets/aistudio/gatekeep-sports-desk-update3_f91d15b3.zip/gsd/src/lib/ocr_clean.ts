/**
 * Turns the raw OCR JSON into reviewable lines. Pure and tested: it only ever
 * DROPS or normalises what the scanner returned. It never adds a player, line
 * or price that was not in the response.
 */
export interface ExtractedPropLine {
  player: string;
  line: number;
  overOdds: string;
  underOdds: string;
  team?: string;
  prop?: string;
}

export function cleanOcrLines(json: any): ExtractedPropLine[] {
  const raw: any[] = Array.isArray(json?.lines) ? json.lines : [];
  return raw
    .filter(l => l && typeof l.player === 'string' && l.player.trim() && l.line !== null && l.line !== '' && Number.isFinite(Number(l.line)))
    .map(l => ({
      player: String(l.player).trim(),
      line: Number(l.line),
      overOdds: l.overOdds ? String(l.overOdds).trim() : '',
      underOdds: l.underOdds ? String(l.underOdds).trim() : '',
      team: l.team ? String(l.team).trim() : '',
      prop: l.prop ? String(l.prop) : json?.propType ? String(json.propType) : ''
    }));
}

/** The model's guess at the sport is a hint only; it is never allowed to change the user's target. */
export function sportHint(json: any): 'NFL' | 'MLB' | 'NHL' | null {
  const g = String(json?.detectedSport || '').toUpperCase();
  return g === 'NFL' || g === 'MLB' || g === 'NHL' ? g : null;
}
