#!/usr/bin/env python3
"""Fit the NHL model's frozen/prior parameters from MoneyPuck game-by-game skater files.

usage:  python3 -I scripts/fit_nhl_moneypuck.py --out src/data/nhl_fit.ts  2025.zip 2026.zip   (or .csv)
        files are read in the order given; the season is read from the data (season / gameDate).

What it does (everything walk-forward: a game only ever sees games BEFORE it):
  1. Builds one row per skater-game from the situation == "all" rows (shots on goal, points, icetime), and
     attaches 5on5 / 5on4 / 4on5 icetime + shots when those situations exist.
  2. Rate model identical to src/model/nhl_engine.ts shrinkRate():
        priorRate = (priorTotal + priorK*posPrior) / (priorGp + priorK)
        mu0       = (total      + shrinkK*priorRate) / (gp + shrinkK)
  3. Grid-fits shrinkK / priorK per market, maximum-likelihood r (negative binomial, var = mu + mu^2/r),
     data-driven position priors, and the measured shots<->points correlation (normal scores of
     randomized PITs).
  4. Honest validation: parameters are FIT on the earlier season's walk-forward rows and SCORED on the
     later season. It prints log-likelihood vs the current defaults, PIT 50/80/90% coverage, and whether a
     5v5 + PP split rate beats the all-situations rate. Nothing is written unless --out is given.

The output file only records numbers that were actually fitted, tagged with how many rows backed them.
Untouched parameters keep their old labels in the app.
"""
import argparse, io, json, math, sys, zipfile
import numpy as np
import pandas as pd
from scipy.special import gammaln
from scipy.stats import norm

ALIASES = {
    'player_id': ['playerId', 'player_id', 'playerid'],
    'name': ['name', 'playerName', 'player_name'],
    'season': ['season'],
    'date': ['gameDate', 'game_date', 'date'],
    'game_id': ['gameId', 'game_id'],
    'team': ['playerTeam', 'team'],
    'opp': ['opposingTeam', 'opponent'],
    'pos': ['position', 'pos'],
    'situation': ['situation'],
    'toi': ['icetime', 'timeOnIce', 'toi'],
    'shots': ['I_F_shotsOnGoal', 'shotsOnGoal', 'sog'],
    'goals': ['I_F_goals', 'goals'],
    'a1': ['I_F_primaryAssists', 'primaryAssists'],
    'a2': ['I_F_secondaryAssists', 'secondaryAssists'],
    'points': ['I_F_points', 'points'],
    'playoff': ['playoffGame', 'playoff'],
}


def read_any(path):
    if path.lower().endswith('.zip'):
        z = zipfile.ZipFile(path)
        names = [n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX')]
        if not names:
            sys.exit(f'{path}: no .csv inside the zip')
        return pd.concat([pd.read_csv(io.BytesIO(z.read(n)), low_memory=False) for n in names])
    return pd.read_csv(path, low_memory=False)


def pick(df, key, required=True):
    for c in ALIASES[key]:
        if c in df.columns:
            return c
    if required:
        sys.exit(f'Missing a "{key}" column. Tried {ALIASES[key]}.\nColumns present ({len(df.columns)}): {list(df.columns)[:60]} ...')
    return None


def nb_logpmf(y, mu, r):
    mu = np.maximum(mu, 1e-9)
    return gammaln(y + r) - gammaln(r) - gammaln(y + 1) + r * np.log(r / (r + mu)) + y * np.log(mu / (r + mu))


def nb_cdf_table(mu, r, kmax):
    """P(Y<=k) for k=0..kmax for each mu (vector). Returns array (n, kmax+1)."""
    k = np.arange(kmax + 1)[None, :]
    pmf = np.exp(nb_logpmf(k, mu[:, None], r))
    return np.cumsum(pmf, axis=1)


def randomized_pit(y, mu, r, rng):
    kmax = int(max(25, y.max() + 5))
    cdf = nb_cdf_table(mu, r, kmax)
    idx = y.astype(int)
    hi = cdf[np.arange(len(y)), np.minimum(idx, kmax)]
    lo = np.where(idx > 0, cdf[np.arange(len(y)), np.maximum(idx - 1, 0)], 0.0)
    return lo + rng.random(len(y)) * (hi - lo)


def build_games(raw):
    c = {k: pick(raw, k, required=k in ('player_id', 'season', 'situation', 'toi', 'shots', 'pos')) for k in ALIASES}
    df = raw.copy()
    if c['playoff'] and df[c['playoff']].notna().any():
        df = df[df[c['playoff']].fillna(0).astype(float) == 0]
    if c['points']:
        pts = df[c['points']]
    elif c['goals'] and c['a1'] and c['a2']:
        pts = df[c['goals']] + df[c['a1']] + df[c['a2']]
    else:
        sys.exit('No points column and no goals+primaryAssists+secondaryAssists to build one.')
    date = pd.to_datetime(df[c['date']].astype(str), format='%Y%m%d', errors='coerce') if c['date'] else pd.NaT
    if c['date'] and date.isna().all():
        date = pd.to_datetime(df[c['date']], errors='coerce')
    gid = df[c['game_id']] if c['game_id'] else date.dt.strftime('%Y%m%d') + '_' + df[c['team']].astype(str)
    base = pd.DataFrame({
        'pid': df[c['player_id']], 'season': df[c['season']].astype(int), 'date': date, 'gid': gid,
        'sit': df[c['situation']].astype(str), 'toi': df[c['toi']].astype(float) / 60.0,  # icetime is seconds
        'shots': df[c['shots']].astype(float), 'points': pts.astype(float),
        'pos': df[c['pos']].astype(str),
    })
    base['team'] = df[c['team']].astype(str) if c['team'] else ''
    base['name'] = df[c['name']].astype(str) if c['name'] else base['pid'].astype(str)
    base = base[base.pos.isin(['C', 'L', 'R', 'D', 'W', 'F'])]
    base['pos'] = np.where(base.pos == 'D', 'D', 'F')
    allr = base[base.sit == 'all'].drop(columns='sit')
    allr = allr[allr.toi > 0].drop_duplicates(['pid', 'gid'])
    for sit, tag in (('5on5', 'ev'), ('5on4', 'pp'), ('4on5', 'pk')):
        s = base[base.sit == sit][['pid', 'gid', 'toi', 'shots']].rename(columns={'toi': f'toi_{tag}', 'shots': f'sog_{tag}'})
        allr = allr.merge(s.drop_duplicates(['pid', 'gid']), on=['pid', 'gid'], how='left')
    for col in ('toi_ev', 'sog_ev', 'toi_pp', 'sog_pp', 'toi_pk', 'sog_pk'):
        if col in allr:
            allr[col] = allr[col].fillna(0.0)
    return allr.sort_values(['pid', 'season', 'date', 'gid']).reset_index(drop=True)


def walk_forward_inputs(g, season):
    """Per skater-game of `season`: games-before and totals-before this season, plus prior-season totals."""
    cur = g[g.season == season].copy()
    grp = cur.groupby('pid')
    cur['gp'] = grp.cumcount()
    cur['cum_shots'] = grp.shots.cumsum() - cur.shots
    cur['cum_pts'] = grp.points.cumsum() - cur.points
    for c in ('sog_ev', 'sog_pp', 'toi_ev', 'toi_pp'):
        if c in cur:
            cur['cum_' + c] = grp[c].cumsum() - cur[c]
    cur['cum_toi'] = grp.toi.cumsum() - cur.toi
    pr = g[g.season == season - 1].groupby('pid').agg(priorGp=('shots', 'size'), priorShots=('shots', 'sum'), priorPoints=('points', 'sum'),
                                                       priorToi=('toi', 'sum'))
    cur = cur.merge(pr, left_on='pid', right_index=True, how='left')
    for c in ('priorGp', 'priorShots', 'priorPoints', 'priorToi'):
        cur[c] = cur[c].fillna(0.0)
    return cur


def pos_priors(g, season):
    """League per-game means by position for `season` (the data-driven position prior)."""
    s = g[g.season == season]
    out = {}
    for p in ('F', 'D'):
        q = s[s.pos == p]
        out[p] = {'sog': float(q.shots.mean()), 'pts': float(q.points.mean()), 'n': int(len(q))}
    return out


def mu_for(cur, market, shrinkK, priorK, prior):
    tot, ptot = ('cum_shots', 'priorShots') if market == 'sog' else ('cum_pts', 'priorPoints')
    pp = np.where(cur.pos == 'D', prior['D'][market], prior['F'][market])
    prior_rate = (cur[ptot] + priorK * pp) / (cur.priorGp + priorK)
    return (cur[tot] + shrinkK * prior_rate) / (cur.gp + shrinkK)


def fit_r(y, mu):
    best = (None, -np.inf)
    for r in np.concatenate([np.arange(2, 30, 0.5), np.arange(30, 120, 3)]):
        ll = nb_logpmf(y, mu, r).sum()
        if ll > best[1]:
            best = (float(r), float(ll))
    return best


def grid_fit(cur, market, prior):
    y = (cur.shots if market == 'sog' else cur.points).values
    best = None
    for sk in (5, 10, 20, 30, 40, 60, 90, 130):
        for pk in (10, 20, 40, 80):
            mu = mu_for(cur, market, sk, pk, prior).values
            r, ll = fit_r(y, mu)
            if best is None or ll > best['ll']:
                best = dict(shrinkK=sk, priorK=pk, r=r, ll=ll)
    best['n'] = int(len(y))
    return best


def coverage(y, mu, r, rng):
    u = randomized_pit(y.astype(int), mu, r, rng)
    return {lvl: float(((u > (1 - lvl) / 2) & (u < 1 - (1 - lvl) / 2)).mean()) for lvl in (0.5, 0.8, 0.9)}, u


def hash_str(x):
    h = 0
    for ch in str(x): h = (h * 131 + ord(ch)) % 1000003
    return h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('files', nargs='+')
    ap.add_argument('--out', default=None)
    ap.add_argument('--min-gp-eval', type=int, default=0, help='only score rows with at least this many prior games this season')
    ap.add_argument('--current', default=None, help='file/zip with the in-progress season (optional; included when given)')
    a = ap.parse_args()
    raw = pd.concat([read_any(f) for f in a.files], ignore_index=True)
    g = build_games(raw)
    seasons = sorted(g.season.unique())
    print(f'skater-games: {len(g):,}  seasons: {seasons}  players: {g.pid.nunique():,}')
    print(g.groupby('season').agg(rows=('pid', 'size'), games=('gid', 'nunique'), sog_pg=('shots', 'mean'), pts_pg=('points', 'mean')).round(3))
    if len(seasons) < 2:
        sys.exit('Need two seasons (prior + current): the app runs with a prior season, so that is the regime fitted.')
    rng = np.random.default_rng(7)
    # Only seasons that have a PRIOR season in the files are used, because that is the regime the app runs in.
    cur_s = seasons[-1]
    cur = walk_forward_inputs(g, cur_s)
    prior = pos_priors(g, cur_s - 1)
    print(f'\nUsing {cur_s} walk-forward rows (n={len(cur):,}); prior season {cur_s - 1}; position priors per game:',
          json.dumps({k: {m: round(v[m], 3) for m in ('sog', 'pts')} for k, v in prior.items()}))
    # two-fold cross-fit BY PLAYER: fit on half the skaters, score on the other half (and swap)
    fold = (cur.pid.astype(str).map(lambda x: hash_str(x)) % 2).values
    defaults = dict(sog=dict(shrinkK=20, priorK=20, r=15.13), pts=dict(shrinkK=40, priorK=40, r=12.0))
    fitted, evidence = {}, {}
    for m in ('sog', 'pts'):
        ycol = 'shots' if m == 'sog' else 'points'
        ll_f, ll_d, n_tot = 0.0, 0.0, 0
        cov_f_acc = np.zeros(3); cov_d_acc = np.zeros(3)
        for k in (0, 1):
            tr, te = cur[fold == k], cur[fold != k]
            f = grid_fit(tr, m, prior)
            d = defaults[m]
            yte = te[ycol].values
            mu_f = mu_for(te, m, f['shrinkK'], f['priorK'], prior).values
            mu_d = mu_for(te, m, d['shrinkK'], d['priorK'], prior).values
            ll_f += nb_logpmf(yte, mu_f, f['r']).sum(); ll_d += nb_logpmf(yte, mu_d, d['r']).sum(); n_tot += len(te)
            cf, _ = coverage(yte, mu_f, f['r'], rng); cd, _ = coverage(yte, mu_d, d['r'], rng)
            cov_f_acc += np.array([cf[.5], cf[.8], cf[.9]]) * len(te); cov_d_acc += np.array([cd[.5], cd[.8], cd[.9]]) * len(te)
        f = grid_fit(cur, m, prior)  # final parameters use every row
        fitted[m] = f
        cf, cd = cov_f_acc / n_tot, cov_d_acc / n_tot
        print(f"\n[{m}] FINAL fit: shrinkK {f['shrinkK']} priorK {f['priorK']} r {f['r']:.2f}  (n={f['n']:,})")
        print(f"     held-out (player cross-fit) LL/row: fitted {ll_f / n_tot:.4f} vs current defaults {ll_d / n_tot:.4f}  delta {(ll_f - ll_d) / n_tot:+.4f}")
        print(f"     held-out PIT coverage 50/80/90  fitted: {cf[0]:.3f} {cf[1]:.3f} {cf[2]:.3f}   defaults: {cd[0]:.3f} {cd[1]:.3f} {cd[2]:.3f}")
        print("     note: r is the PREDICTIVE dispersion given the shrunk rate, so it includes rate-estimation error and is lower than a true-rate r.")
        evidence[m] = dict(heldOutLLFitted=round(float((ll_f) / n_tot), 4), heldOutLLDefault=round(float(ll_d / n_tot), 4),
                           heldOutCoverage={'0.5': round(float(cf[0]), 3), '0.8': round(float(cf[1]), 3), '0.9': round(float(cf[2]), 3)})

    # 5v5 + PP split vs all-situations (SOG only; needs the situation rows)
    split_note = 'situation rows not present in the files'
    if {'cum_sog_ev', 'cum_toi_ev', 'cum_sog_pp', 'cum_toi_pp'} <= set(cur.columns):
        te = cur[cur.gp >= 8].copy()
        f = fitted['sog']
        te['mu_all'] = mu_for(te, 'sog', f['shrinkK'], f['priorK'], prior)
        # unshrunk per-minute split rates times the skater's own expected minutes in each situation (all strictly pre-game)
        te['exp_toi_ev'] = te.cum_toi_ev / te.gp.clip(lower=1); te['exp_toi_pp'] = te.cum_toi_pp / te.gp.clip(lower=1)
        te['mu_split'] = (te.cum_sog_ev / te.cum_toi_ev.clip(lower=1e-6)) * te.exp_toi_ev + (te.cum_sog_pp / te.cum_toi_pp.clip(lower=1e-6)) * te.exp_toi_pp
        t2 = te[np.isfinite(te.mu_split) & (te.mu_split > 0)]
        base_ll = nb_logpmf(t2.shots.values, t2.mu_all.values, f['r']).mean()
        best = (0.0, base_ll)
        for w in (0.0, 0.25, 0.5, 0.75, 1.0):
            mu = ((1 - w) * t2.mu_all + w * t2.mu_split).values
            ll = nb_logpmf(t2.shots.values, mu, f['r']).mean()
            print(f'     5v5+PP split blend w={w:.2f}: LL/row {ll:.4f}')
            if ll > best[1] + 1e-9: best = (w, ll)
        split_note = f'best blend weight {best[0]:.2f} of 5v5+PP split rate (0 = all-situations only); gain {best[1] - base_ll:+.4f} LL/row on {len(t2):,} rows (in-sample blend choice, 5 candidates)'
        print('     ->', split_note)

    # measured shots<->points dependence, expressed on the SAME latent-Gaussian scale the app's copula uses:
    # match the observed Pearson correlation of standardized residuals to a simulated copula with the fitted marginals.
    fs, fp = fitted['sog'], fitted['pts']
    mu_s = mu_for(cur, 'sog', fs['shrinkK'], fs['priorK'], prior).values
    mu_p = mu_for(cur, 'pts', fp['shrinkK'], fp['priorK'], prior).values
    sd_s = np.sqrt(mu_s + mu_s ** 2 / fs['r']); sd_p = np.sqrt(mu_p + mu_p ** 2 / fp['r'])
    obs = float(np.corrcoef((cur.shots.values - mu_s) / sd_s, (cur.points.values - mu_p) / sd_p)[0, 1])
    from scipy.stats import nbinom
    idx = rng.integers(0, len(cur), 120000)
    def sim_corr(rho):
        z1 = rng.normal(size=len(idx)); z2 = rho * z1 + math.sqrt(1 - rho ** 2) * rng.normal(size=len(idx))
        ys = nbinom.ppf(np.clip(norm.cdf(z1), 1e-9, 1 - 1e-9), fs['r'], fs['r'] / (fs['r'] + mu_s[idx]))
        yp = nbinom.ppf(np.clip(norm.cdf(z2), 1e-9, 1 - 1e-9), fp['r'], fp['r'] / (fp['r'] + mu_p[idx]))
        return float(np.corrcoef((ys - mu_s[idx]) / sd_s[idx], (yp - mu_p[idx]) / sd_p[idx])[0, 1])
    grid = np.round(np.arange(0.0, 0.96, 0.05), 2)
    sims = [sim_corr(r) for r in grid]
    rho = float(np.interp(obs, sims, grid)) if obs <= max(sims) else float(grid[-1])
    print(f'\nobserved residual Pearson (shots, points) = {obs:.3f}  ->  copula rho {rho:.3f}  (app prior was 0.35)')

    out = dict(
        source=f"MoneyPuck game-by-game skaters, seasons {seasons}", fitSeason=int(cur_s), testSeason=int(cur_s),
        nTrainRows=int(len(cur)), nTestRows=int(len(cur)),
        values=dict(
            sogR=round(fs['r'], 2), ptsR=round(fp['r'], 2),
            sogShrinkK=fs['shrinkK'], sogPriorK=fs['priorK'], ptsShrinkK=fp['shrinkK'], ptsPriorK=fp['priorK'],
            posPriorSogF=round(prior['F']['sog'], 3), posPriorSogD=round(prior['D']['sog'], 3),
            posPriorPtsF=round(prior['F']['pts'], 3), posPriorPtsD=round(prior['D']['pts'], 3),
            rhoShotsPoints=round(rho, 3),
        ),
        evidence=evidence, splitNote=split_note,
    )
    if a.out:
        with open(a.out, 'w') as fh:
            fh.write('// GENERATED by scripts/fit_nhl_moneypuck.py. Do not edit by hand; re-run the script on new files.\n')
            fh.write('// Only numbers that were actually fitted appear here. null = nothing has been fitted yet.\n')
            fh.write('export interface NhlFit { source: string; fitSeason: number; testSeason: number; nTrainRows: number; nTestRows: number; values: Record<string, number>; evidence: Record<string, unknown>; splitNote: string; }\n')
            fh.write('export const NHL_FIT: NhlFit | null = ' + json.dumps({
                'source': out['source'], 'fitSeason': out['fitSeason'], 'testSeason': out['testSeason'],
                'nTrainRows': out['nTrainRows'], 'nTestRows': out['nTestRows'], 'values': out['values'],
                'evidence': out['evidence'], 'splitNote': out['splitNote']}, indent=2) + ';\n')
        print(f'\nwrote {a.out}')
    else:
        print('\n(dry run; pass --out src/data/nhl_fit.ts to write)')


if __name__ == '__main__':
    main()
