# NFL feature experiments (Update 3)

Question: do free nflverse / FTN-charting team-context features make the v1.5 receptions model more accurate?

Method: every feature for week W uses only games before W of the same season (shrunk 4 pseudo-games toward the
league mean). Each is a multiplicative adjustment on the v1.5 walk-forward `mu`, fit with a ridge on one
season and scored on the NEXT season by negative-binomial log-likelihood per row.

Order to run (data in /home/claude/data, see header of each file):
1. `dump_nfl_rows.ts`        baseline walk-forward predictions (7,964 WR/TE player-games, 2024-2026 wk 3+)
2. `nfl_features_exp.py`     team-game aggregates from play-by-play + FTN charting (EPA, success, sack+hit rate, blitz rate, play-action, pace)
3. `nfl_features_test.py`    out-of-sample test of each feature
4. `nfl_absence_test.py`     teammate-absence (target redistribution)
5. `nfl_recency_test.py`     trailing 3-game receptions / targets

Result (all deltas are LL per row; positive = better than v1.5):
- team EPA / success / pressure / blitz / pace / play-action, all together: -0.0003 (2025), +0.0001 (2026)
- best single features: |delta| < 0.0020 and the sign flips between 2025 and 2026 -> NOT adopted
- teammate absence: a first run showed +0.0011 but it came from player-name mismatches creating phantom absences;
  after fixing the matching it was -0.0002 / -0.0000 -> NOT adopted
- recency: +0.0012 on 2025, -0.0053 on 2026 -> NOT adopted

Nothing here is wired into pricing. The mean model stays v1.5; the evidence is kept so it can be re-run when more
2026 weeks exist (re-test around week 12).
