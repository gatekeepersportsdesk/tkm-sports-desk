#!/usr/bin/env python3
"""
Build a dated NBA minutes / game-log feature JSON for Gatekeep.
Focus: minutes, back-to-backs, team pace. No tracking or hustle yet.

Usage:
  python3 build_nba_minutes.py --season 2025-26 --out nba_minutes_2025-11-04.json
"""
import argparse, json
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season", type=str, required=True)
    ap.add_argument("--out", type=str, default="nba_minutes_features.json")
    args = ap.parse_args()

    features = {
        "asOf": "2025-11-04",
        "season": args.season,
        "note": "As-of features only. Minutes, b2b, team pace. Game logs from nba_api.",
        "players": [
            {
                "player": "Example Player",
                "team": "DEN",
                "minutesAvg": 34.2,
                "last5Min": 33.8,
                "b2b": False,
                "teamPace": 100.4
            }
        ]
    }
    Path(args.out).write_text(json.dumps(features, indent=2))
    print(f"Wrote {args.out} (template — wire to nba_api game logs)")

if __name__ == "__main__":
    main()
