# NHL As-Of Status

The existing `scripts/fit_nhl_moneypuck.py` already states:

> everything walk-forward: a game only ever sees games BEFORE it

So the core as-of discipline is present in the current fit.

Next step for NHL:
1. Re-run the fit on the latest MoneyPuck game-by-game files.
2. Confirm the output `src/data/nhl_fit.ts` is regenerated.
3. Spot-check a few players that their rate for a given date excludes that game and later games.

No major rewrite needed — just refresh and validate.
