#!/usr/bin/env python3
"""
Build a dated NFL opportunity feature JSON for Gatekeep.
Uses nflverse-style weekly data (targets, snaps, team pass attempts, injuries).
Output is a small JSON the app can import — same pattern as odds imports.

Usage:
  python3 build_nfl_opportunity.py --season 2025 --out nfl_features_2025-11-04.json
"""
import argparse, json
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season", type=int, required=True)
    ap.add_argument("--out", type=str, default="nfl_opportunity_features.json")
    args = ap.parse_args()

    # Placeholder structure — replace with real nflverse load once data is local
    features = {
        "asOf": "2025-11-04",
        "season": args.season,
        "note": "As-of features only. Targets, targetShare, snaps, teamPassAttempts, injuryStatus.",
        "players": [
            # Example row
            {
                "player": "Example Player",
                "team": "KC",
                "week": 9,
                "targets": 7.2,
                "targetShare": 0.21,
                "snaps": 58,
                "teamPassAttempts": 34.5,
                "injuryStatus": "active"
            }
        ]
    }
    Path(args.out).write_text(json.dumps(features, indent=2))
    print(f"Wrote {args.out} (template — wire to nflverse weekly data)")

if __name__ == "__main__":
    main()
