# Prompt: Gatekeep Data Foundation Updates

The project is connected to GitHub. Make these focused changes only.

## 1. NHL
- Keep the existing walk-forward MoneyPuck fit (`scripts/fit_nhl_moneypuck.py`).
- Add a short comment or README note confirming as-of behavior.
- Do not expand to new data sources yet.

## 2. NFL
- Add a script `scripts/build_nfl_opportunity.py` that produces a small dated JSON of as-of features:
  - targets, targetShare, snaps, teamPassAttempts, injuryStatus
- The JSON should be importable by the app the same way odds JSON is imported.
- Use nflverse weekly data as the source (document the load step).

## 3. NBA
- Add a script `scripts/build_nba_minutes.py` that produces a small dated JSON of as-of features:
  - minutes averages, last-5 minutes, back-to-back flag, team pace
- Source: nba_api game logs.
- No tracking, hustle, or matchup data yet.

## 4. App integration
- Ensure the app can import these feature JSONs (same pattern as existing odds import).
- Do not change the live prediction engines beyond reading the new feature fields if present.
- Keep all existing edge gates, grading, and UI behavior intact.

## Output
- The two new scripts.
- Any small import helper needed.
- Brief comments on as-of rules.
