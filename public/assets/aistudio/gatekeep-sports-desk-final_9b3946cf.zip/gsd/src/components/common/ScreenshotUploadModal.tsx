import React, { useState, useRef, useEffect } from 'react';
import { inferNbaMarket } from '../../lib/nba_board';
import { cleanOcrLines, sportHint, ExtractedPropLine } from '../../lib/ocr_clean';
import { Camera, Upload, CheckCircle2, AlertCircle, RefreshCw, X, Sparkles, Plus, Trash2, Image as ImageIcon } from 'lucide-react';

export type { ExtractedPropLine };

interface ScreenshotUploadModalProps {
  sport: 'NFL' | 'MLB' | 'NHL' | 'NBA';
  onApplyLines: (lines: ExtractedPropLine[], targetSport: 'NFL' | 'MLB' | 'NHL' | 'NBA') => void;
  onClose: () => void;
}

export const ScreenshotUploadModal: React.FC<ScreenshotUploadModalProps> = ({
  sport: initialSport,
  onApplyLines,
  onClose
}) => {
  const [activeModalSport, setActiveModalSport] = useState<'NFL' | 'MLB' | 'NHL' | 'NBA'>(initialSport);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedLines, setExtractedLines] = useState<ExtractedPropLine[]>([]);
  const [statusMessage, setStatusMessage] = useState<string>('Upload a sportsbook screenshot or paste from clipboard (Ctrl+V)');
  const [detectedBook, setDetectedBook] = useState<string>('Bet99 / Sportsbook');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [detectedSportHint, setDetectedSportHint] = useState<'NFL' | 'MLB' | 'NHL' | 'NBA' | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Listen for clipboard image paste (Ctrl+V)
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            processImageFile(file);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [activeModalSport]);

  const processImageFile = async (file: File) => {
    setErrorMsg(null);
    setIsProcessing(true);
    setStatusMessage(`Scanning screenshot with AI Vision for ${activeModalSport} props...`);

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      setImagePreview(base64Data);

      try {
        // 1. Call server-side Gemini Vision OCR endpoint
        const res = await fetch('/api/ocr-lines', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Data,
            mimeType: file.type || 'image/jpeg',
            sport: activeModalSport
          })
        });

        if (!res.ok) {
          const detail = await res.json().catch(() => ({} as any));
          throw new Error(detail?.details || detail?.error || `OCR HTTP ${res.status}`);
        }
        const json = await res.json();
        if (!Array.isArray(json.lines) || json.lines.length === 0) {
          throw new Error('The scanner found no prop lines in that image');
        }
        setDetectedBook(json.book || 'Sportsbook');
        const clean = cleanOcrLines(json);
        if (!clean.length) throw new Error('No usable lines (player + numeric line) in the scan');
        setExtractedLines(clean);
        // The user's chosen target sport is NEVER overridden by the model's guess; a mismatch is only flagged.
        setDetectedSportHint(sportHint(json));
        setErrorMsg(null);
        setStatusMessage(`Extracted ${clean.length} line(s) — review before applying. Nothing is applied until you press Apply.`);
        setIsProcessing(false);
      } catch (err: any) {
        console.warn('Screenshot scan failed:', err);
        // No sample / placeholder lines are ever substituted for a failed scan.
        setExtractedLines([]);
        setErrorMsg(`Scan failed: ${err?.message || 'unknown error'}. No lines were invented — retry, or add rows by hand.`);
        setStatusMessage('Scan failed');
        setIsProcessing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleUpdateLine = (index: number, field: keyof ExtractedPropLine, value: any) => {
    setExtractedLines(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  const handleAddLine = () => {
    setExtractedLines(prev => [
      ...prev,
      {
        player: '',
        line: activeModalSport === 'NFL' ? 4.5 : activeModalSport === 'MLB' ? 0.5 : 2.5,
        overOdds: '',
        underOdds: '',
        prop: activeModalSport === 'NFL' ? 'receptions' : activeModalSport === 'MLB' ? 'hits' : 'shots'
      }
    ]);
  };

  const handleRemoveLine = (index: number) => {
    setExtractedLines(prev => prev.filter((_, i) => i !== index));
  };

  const handleApply = () => {
    if (extractedLines.length === 0) {
      alert('No lines to apply. Upload a screenshot or add rows by hand first.');
      return;
    }
    const usable = extractedLines.filter(l => l.player.trim() && (l.overOdds.trim() || l.underOdds.trim()));
    if (!usable.length) { alert('Every row needs a player and at least one price.'); return; }
    onApplyLines(usable, activeModalSport);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#121824] border border-[#222d3e] rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#222d3e] pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/10 rounded-xl border border-emerald-500/30">
              <Camera className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white flex items-center gap-2">
                Sportsbook Screenshot Scanner
              </h2>
              <p className="text-xs text-[#8b97ac]">
                Bet99, Bet365, DraftKings, FanDuel, Bovada &middot; Direct Multimodal AI Vision
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#8b97ac] hover:text-white p-1 text-xl font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Sport Switcher */}
        <div className="flex items-center justify-between gap-2 bg-[#0f1520] p-1.5 rounded-xl border border-[#222d3e]">
          <span className="text-[11px] font-mono uppercase tracking-wider text-[#8b97ac] pl-2 font-semibold">
            Target Sport:
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveModalSport('NFL')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition ${
                activeModalSport === 'NFL' ? 'bg-sky-500 text-slate-950 shadow-sm' : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              🏈 NFL Receptions
            </button>
            <button
              onClick={() => setActiveModalSport('MLB')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition ${
                activeModalSport === 'MLB' ? 'bg-amber-400 text-amber-950 shadow-sm' : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              ⚾ MLB Hits
            </button>
            <button
              onClick={() => setActiveModalSport('NHL')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition ${
                activeModalSport === 'NHL' ? 'bg-cyan-400 text-slate-950 shadow-sm' : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              🏒 NHL SOG + PTS
            </button>
            <button
              onClick={() => setActiveModalSport('NBA')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition ${
                activeModalSport === 'NBA' ? 'bg-orange-400 text-orange-950 shadow-sm' : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              🏀 NBA Props
            </button>
          </div>
        </div>

        {/* Upload Dropzone */}
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={e => e.preventDefault()}
          onDrop={e => {
            e.preventDefault();
            const file = e.dataTransfer.files?.[0];
            if (file) processImageFile(file);
          }}
          className="border-2 border-dashed border-[#222d3e] hover:border-sky-500/60 rounded-xl p-5 text-center cursor-pointer transition bg-[#0f1520] group relative"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={e => {
              const file = e.target.files?.[0];
              if (file) processImageFile(file);
            }}
          />

          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-[#182232] rounded-full group-hover:bg-sky-500/20 transition">
              <Upload className="w-6 h-6 text-sky-400" />
            </div>
            <div className="text-xs text-white font-medium">
              Click to browse screenshot or drag image file here
            </div>
            <div className="text-[11px] text-[#556277] font-mono">
              Supports PNG, JPG, WEBP, or press <kbd className="px-1.5 py-0.5 rounded bg-[#182232] text-sky-300 border border-[#222d3e]">Ctrl+V</kbd> to paste
            </div>
          </div>
        </div>

        {/* Image thumbnail if present */}
        {imagePreview && (
          <div className="p-2 bg-[#0f1520] rounded-xl border border-[#222d3e] flex items-center gap-3">
            <img src={imagePreview} alt="Screenshot preview" className="w-16 h-12 object-cover rounded-lg border border-[#222d3e]" />
            <div className="text-xs font-mono text-[#8b97ac] flex-1 truncate">
              Screenshot loaded &middot; <span className="text-white">{detectedBook}</span>
            </div>
          </div>
        )}

        {/* Status bar */}
        <div className="p-3 bg-[#182232] rounded-xl border border-[#222d3e] flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2 text-sky-300">
            {isProcessing ? (
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            <span>{statusMessage}</span>
          </div>
          {detectedBook && !isProcessing && (
            <span className="bg-[#0f1520] text-[#8b97ac] px-2 py-0.5 rounded text-[10px] font-mono">
              {detectedBook}
            </span>
          )}
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-950/50 border border-rose-800 rounded-xl text-xs font-mono text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" /> <span>{errorMsg}</span>
          </div>
        )}
        {detectedSportHint && detectedSportHint !== activeModalSport && extractedLines.length > 0 && (
          <div className="p-3 bg-amber-950/40 border border-amber-800 rounded-xl text-xs font-mono text-amber-300">
            The scanner thinks this slip is {detectedSportHint}, but the target is {activeModalSport}. Your selection is kept — switch the target above if the scanner is right.
          </div>
        )}

        {/* Extracted Lines Table */}
        {extractedLines.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#8b97ac] uppercase text-[11px] font-bold">
                Review &amp; Edit Extracted Lines ({extractedLines.length})
              </span>
              <button
                onClick={handleAddLine}
                className="text-xs font-mono text-sky-400 hover:text-sky-300 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Add Player Row
              </button>
            </div>

            <div className="max-h-56 overflow-y-auto rounded-xl border border-[#222d3e] bg-[#0f1520]">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#222d3e] bg-[#182232] text-[#8b97ac] text-[11px] uppercase">
                    <th className="py-2 px-3">Player Name</th>
                    <th className="py-2 px-3 text-center">
                      Line ({activeModalSport === 'NFL' ? 'Rec' : activeModalSport === 'MLB' ? 'Hits' : activeModalSport === 'NBA' ? 'Stat' : 'SOG'})
                    </th>
                    {(activeModalSport === 'NHL' || activeModalSport === 'NBA') && <th className="py-2 px-3 text-center">Market</th>}
                    <th className="py-2 px-3 text-center">Over Odds</th>
                    <th className="py-2 px-3 text-center">Under Odds</th>
                    <th className="py-2 px-2 text-right"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222d3e]/50">
                  {extractedLines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-[#182232]/40">
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={line.player}
                          onChange={e => handleUpdateLine(idx, 'player', e.target.value)}
                          className="bg-transparent text-white font-bold w-full outline-none focus:text-sky-400"
                        />
                      </td>
                      <td className="py-2 px-3 text-center">
                        <input
                          type="number"
                          step="0.5"
                          value={line.line}
                          onChange={e => handleUpdateLine(idx, 'line', parseFloat(e.target.value) || 0)}
                          className="bg-[#182232] border border-[#222d3e] rounded px-1.5 py-0.5 text-center text-white w-14 font-mono outline-none"
                        />
                      </td>
                      {activeModalSport === 'NBA' && (
                        <td className="py-2 px-3 text-center">
                          <select
                            value={({ pts: 'points', reb: 'rebounds', ast: 'assists', tpm: 'threes', pra: 'pra', stl: 'steals', blk: 'blocks' } as Record<string, string>)[inferNbaMarket(line.prop) ?? ''] ?? 'unsupported'}
                            onChange={e => handleUpdateLine(idx, 'prop', e.target.value)}
                            className="bg-[#182232] border border-[#222d3e] rounded px-1 py-0.5 text-white font-mono outline-none"
                          >
                            <option value="points">PTS</option>
                            <option value="rebounds">REB</option>
                            <option value="assists">AST</option>
                            <option value="threes">3PM</option>
                            <option value="pra">PRA</option>
                            <option value="steals">STL</option>
                            <option value="blocks">BLK</option>
                            <option value="unsupported">Other (skipped)</option>
                          </select>
                        </td>
                      )}
                      {activeModalSport === 'NHL' && (
                        <td className="py-2 px-3 text-center">
                          <select
                            value={/point|pts/i.test(line.prop || '') ? 'points' : 'shots'}
                            onChange={e => handleUpdateLine(idx, 'prop', e.target.value)}
                            className="bg-[#182232] border border-[#222d3e] rounded px-1 py-0.5 text-white font-mono outline-none"
                          >
                            <option value="shots">SOG</option>
                            <option value="points">PTS</option>
                          </select>
                        </td>
                      )}
                      <td className="py-2 px-3 text-center">
                        <input
                          type="text"
                          value={line.overOdds}
                          onChange={e => handleUpdateLine(idx, 'overOdds', e.target.value)}
                          className="bg-[#182232] border border-[#222d3e] rounded px-1.5 py-0.5 text-center text-emerald-400 font-bold w-16 font-mono outline-none"
                        />
                      </td>
                      <td className="py-2 px-3 text-center">
                        <input
                          type="text"
                          value={line.underOdds}
                          onChange={e => handleUpdateLine(idx, 'underOdds', e.target.value)}
                          className="bg-[#182232] border border-[#222d3e] rounded px-1.5 py-0.5 text-center text-[#8b97ac] w-16 font-mono outline-none"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <button
                          onClick={() => handleRemoveLine(idx)}
                          className="text-[#556277] hover:text-rose-400 text-sm px-1.5 font-bold"
                          title="Delete row"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modal Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-[#222d3e]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8b97ac] hover:text-white"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleApply}
            disabled={extractedLines.length === 0 || isProcessing}
            className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl transition disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
          >
            <CheckCircle2 className="w-4 h-4" /> Apply Lines to {activeModalSport} Board ({extractedLines.length})
          </button>
        </div>
      </div>
    </div>
  );
};
