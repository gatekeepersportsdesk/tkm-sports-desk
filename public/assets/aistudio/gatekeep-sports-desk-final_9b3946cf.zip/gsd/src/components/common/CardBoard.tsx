import React, { useMemo, useState } from 'react';
import { CardRow, CardFilter, filterCardRows, summarizeCard, isHeadline } from '../../lib/card_core';

interface Props {
  rows: CardRow[];
  edge: Set<string>;
  /** read-only line saying what the automatic capture / grading just did */
  autoStatus: string;
  /** read-only line saying what the automatic grader just did */
  gradeStatus?: string;
  /** manual re-run of the same automatic grader (never required) */
  onGrade?: () => void;
  /** downloads the card rows as JSON */
  onExport?: () => void;
  sport: string;
  markets: { id: string; label: string }[];
  /** 'min' | 'AB' | '' (NFL has no exposure column) */
  exposureUnit: string;
  startWord: string;
  sourceWord: string;
  /** what the "season avg" comparator means for this sport */
  avgNote: string;
}

const pct = (x: number | null, d = 0) => (x === null ? '—' : `${(x * 100).toFixed(d)}%`);
const n1 = (x: number | null) => (x === null ? '—' : x.toFixed(2));
const FILTERS: [CardFilter, string][] = [['all', 'All'], ['won', 'Won'], ['missed', 'Missed'], ['pending', 'Pending'], ['edge', 'Edge plays']];

/** The automatic daily card: nothing here is logged by hand. */
export const CardBoard: React.FC<Props> = ({ rows, edge, autoStatus, gradeStatus, onGrade, onExport, sport, markets, exposureUnit, startWord, sourceWord, avgNote }) => {
  const label = (id: string) => markets.find(m => m.id === id)?.label ?? id;
  const [filter, setFilter] = useState<CardFilter>('all');
  const [market, setMarket] = useState<string>('all');
  const [withEst, setWithEst] = useState(false);
  const s = useMemo(() => summarizeCard(rows, markets.map(m => m.id), false), [rows, markets]);
  const excluded = rows.filter(r => !isHeadline(r)).length;
  const shown = useMemo(() => filterCardRows(rows, filter, market, edge, withEst).slice().sort((a, b) => (a.date === b.date ? (b.capturedAt - a.capturedAt) : a.date < b.date ? 1 : -1)), [rows, filter, market, edge, withEst]);
  const chip = (on: boolean) => `px-2.5 py-1 rounded-full text-[11px] font-mono cursor-pointer ${on ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'}`;
  const noise = s.decided ? Math.sqrt(0.25 / s.decided) * 100 : null;

  return (
    <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e] space-y-4">
      <div>
        <h2 className="text-lg font-bold uppercase tracking-wide text-white">{sport} daily card — automatic self-grading</h2>
        <p className="text-xs text-[#8b97ac]">
          Every priced player-market is logged before {startWord} with no clicking, then graded from {sourceWord} once the game is final. Players who did not play are VOID and excluded.
          Headline numbers use REAL inputs with a known availability only{excluded ? ` (${excluded} estimated / unknown-availability row${excluded === 1 ? '' : 's'} kept aside)` : ''}.
        </p>
        {autoStatus && <div className="mt-2 text-[11px] font-mono text-cyan-300">{autoStatus}</div>}
        {(gradeStatus || onGrade || onExport) && (
          <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] font-mono text-[#8b97ac]">
            {gradeStatus && <span>{gradeStatus}</span>}
            {onExport && <button onClick={onExport} className="px-2 py-0.5 rounded border border-[#222d3e] hover:text-white cursor-pointer">Export card JSON</button>}
            {onGrade && <button onClick={onGrade} className="px-2 py-0.5 rounded border border-[#222d3e] hover:text-white cursor-pointer">Grade now (runs by itself anyway)</button>}
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
          <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Model prediction win rate</span>
          <p className="text-xl font-bold font-mono text-white mt-0.5">{pct(s.winRate, 1)}</p>
          <span className="text-[10px] text-[#556277] font-mono">{s.hits} / {s.decided} decided{noise !== null ? ` · ±${noise.toFixed(1)}pt noise` : ''} · baselines: always-UNDER {pct(s.alwaysUnder, 1)} · always-OVER {pct(s.alwaysOver, 1)}</span>
        </div>
        <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
          <span className="text-[10px] font-mono text-[#8b97ac] uppercase">OVER vs UNDER accuracy</span>
          <p className="text-xl font-bold font-mono text-white mt-0.5">{pct(s.over.n ? s.over.hits / s.over.n : null)} / {pct(s.under.n ? s.under.hits / s.under.n : null)}</p>
          <span className="text-[10px] text-[#556277] font-mono">{s.over.hits}/{s.over.n} over · {s.under.hits}/{s.under.n} under</span>
        </div>
        <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
          <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Brier · mean P(over) vs over rate</span>
          <p className="text-xl font-bold font-mono text-sky-400 mt-0.5">{s.brier === null ? '—' : s.brier.toFixed(3)}</p>
          <span className="text-[10px] text-[#556277] font-mono">{pct(s.meanPOver, 1)} predicted · {pct(s.overRate, 1)} happened (0.250 = coin flip)</span>
        </div>
        <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
          <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Logged · pending · push · void</span>
          <p className="text-xl font-bold font-mono text-white mt-0.5">{s.logged}</p>
          <span className="text-[10px] text-[#556277] font-mono">{s.pending} pending · {s.pushed} push · {s.voided} void</span>
        </div>
      </div>
      <p className="text-[10px] text-[#556277]">
        The win rate is measured at the model's own line (about its mean). The outcome is lopsided at that line (for most count stats UNDER wins more than half the time, for MLB 0.5 hits OVER does), so compare the win rate with the better of the two baselines, not with 50%. The real quality tests are MAE against a plain season average (below) and interval coverage; both need a few hundred graded rows per market to mean anything.
      </p>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="border-b border-[#222d3e] text-[#8b97ac] uppercase text-[11px]">
              <th className="py-1.5 px-2">Market</th><th className="py-1.5 px-2 text-right">n</th><th className="py-1.5 px-2 text-right">MAE model</th>
              <th className="py-1.5 px-2 text-right">MAE season avg*</th><th className="py-1.5 px-2 text-right">Bias (act−μ)</th><th className="py-1.5 px-2 text-right">Coverage 50/80/90</th>
            </tr>
          </thead>
          <tbody>
            {s.byMarket.filter(m => m.n > 0).length === 0 ? (
              <tr><td colSpan={6} className="py-4 text-center text-[#556277]">Nothing graded yet. Come back after the games are final; grading runs by itself when you open this page.</td></tr>
            ) : s.byMarket.filter(m => m.n > 0).map(m => (
              <tr key={m.market} className="border-b border-[#222d3e]/50 text-white">
                <td className="py-1.5 px-2 font-bold">{label(m.market)}</td>
                <td className="py-1.5 px-2 text-right">{m.n}</td>
                <td className="py-1.5 px-2 text-right text-cyan-400">{n1(m.mae)}</td>
                <td className="py-1.5 px-2 text-right">{m.maeNaive === null ? '—' : `${n1(m.maeNaive)} (model ${n1(m.maeOnNaive)} on those ${m.nNaive})`}</td>
                <td className="py-1.5 px-2 text-right">{m.bias === null ? '—' : (m.bias >= 0 ? '+' : '') + m.bias.toFixed(2)}</td>
                <td className="py-1.5 px-2 text-right">{m.coverage.map(c => pct(c)).join(' / ')}{m.n < 100 ? <span className="text-amber-400"> (n={m.n}: too few)</span> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="text-[10px] text-[#556277] mt-1">* {avgNote}, on the rows that have one. Lower MAE is better.</div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {FILTERS.map(([k, label]) => <button key={k} onClick={() => setFilter(k)} className={chip(filter === k)}>{label}</button>)}
        <span className="text-[#556277]">|</span>
        <button onClick={() => setMarket('all')} className={chip(market === 'all')}>All markets</button>
        {markets.length > 1 && markets.map(m => <button key={m.id} onClick={() => setMarket(m.id)} className={chip(market === m.id)}>{m.label}</button>)}
        <label className="ml-auto flex items-center gap-1.5 text-[11px] font-mono text-[#8b97ac] cursor-pointer">
          <input type="checkbox" checked={withEst} onChange={e => setWithEst(e.target.checked)} className="accent-cyan-400" />
          show estimated / unknown rows ({excluded})
        </label>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="border-b border-[#222d3e] text-[#8b97ac] uppercase text-[11px]">
              <th className="py-1.5 px-2">Date</th><th className="py-1.5 px-2">Player</th><th className="py-1.5 px-2">Mkt</th>
              <th className="py-1.5 px-2 text-right">Lean · line</th><th className="py-1.5 px-2 text-right">μ</th><th className="py-1.5 px-2 text-right">Actual{exposureUnit ? ` (${exposureUnit})` : ''}</th>
              <th className="py-1.5 px-2 text-right">Error</th><th className="py-1.5 px-2 text-center">Result</th><th className="py-1.5 px-2">Why</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#222d3e]/50">
            {shown.length === 0 ? (
              <tr><td colSpan={9} className="py-6 text-center text-[#556277]">{rows.length === 0 ? `The daily card fills itself when the ${sport} slate loads before ${startWord}. Nothing to do.` : 'No rows match this filter.'}</td></tr>
            ) : shown.slice(0, 200).map(r => (
              <tr key={r.id} className="hover:bg-[#182232]/50 align-top">
                <td className="py-1.5 px-2 text-[#8b97ac]">{r.date}</td>
                <td className="py-1.5 px-2 font-bold text-white">{r.name}<span className="text-[#556277] font-normal"> {r.team}v{r.opp}</span>{(!isHeadline(r)) && <span className="ml-1 text-[9px] text-amber-300 border border-amber-700 rounded px-1">{r.inputs !== 'REAL' ? 'EST' : 'AVAIL?'}</span>}{edge.has(r.id) && <span className="ml-1 text-[9px] text-emerald-300 border border-emerald-700 rounded px-1">EDGE</span>}</td>
                <td className="py-1.5 px-2 text-[#8b97ac]">{label(r.market)}</td>
                <td className="py-1.5 px-2 text-right text-white">{r.lean} {r.line}</td>
                <td className="py-1.5 px-2 text-right text-cyan-400">{r.mu.toFixed(2)}</td>
                <td className="py-1.5 px-2 text-right text-white font-bold">{r.actual === null ? '—' : exposureUnit && r.minutes !== null ? `${r.actual} (${Math.round(r.minutes)}${exposureUnit === 'min' ? 'm' : ' ' + exposureUnit})` : `${r.actual}`}</td>
                <td className="py-1.5 px-2 text-right">{r.err === null ? '—' : (r.err >= 0 ? '+' : '') + r.err.toFixed(1)}</td>
                <td className="py-1.5 px-2 text-center">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${r.result === null ? 'bg-slate-800 text-slate-400 border-slate-700' : r.result === 'HIT' ? 'bg-emerald-950 text-emerald-300 border-emerald-600' : r.result === 'MISS' ? 'bg-rose-950 text-rose-300 border-rose-700' : 'bg-slate-800 text-slate-300 border-slate-600'}`}>{r.result ?? 'PENDING'}</span>
                </td>
                <td className="py-1.5 px-2 text-[#8b97ac] min-w-[260px]">{r.reason ?? ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {shown.length > 200 && <div className="text-[10px] text-[#556277] mt-1">Showing the 200 most recent of {shown.length}. Statistics above use every row.</div>}
      </div>
    </div>
  );
};
