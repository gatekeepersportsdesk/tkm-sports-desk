import React from 'react';
import { BettableConfig, DEFAULT_BETTABLE, FLOOR_META, RankBy } from '../../lib/bettable';

interface Props { cfg: BettableConfig; onChange: (c: BettableConfig) => void }
const field = 'w-full bg-[#182232] border border-[#222d3e] rounded-lg p-2 text-white outline-none focus:border-cyan-400';

/** Shared across every sport (one config). Changes only what ranks as actionable; model numbers and the daily card are untouched. */
export const BettableSettings: React.FC<Props> = ({ cfg, onChange }) => (
  <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e] space-y-3">
    <div>
      <h3 className="text-sm font-bold uppercase tracking-wide text-white">Bettable filter (all sports)</h3>
      <p className="text-xs text-[#8b97ac]">A row is bettable when inputs are REAL, availability is known and not out / doubtful, expected usage clears the floor, and any posted price on the chosen side is not worse than the juice limit. Hidden rows stay in the model and the daily card; the "Full model" toggle on the desk shows them.</p>
    </div>
    <div className="grid sm:grid-cols-3 gap-3 text-xs font-mono">
      <label className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e] block">
        <span className="block text-[#8b97ac] uppercase text-[11px] mb-1">Max juice (American)</span>
        <input type="number" step="5" min="100" value={cfg.maxJuice} onChange={e => onChange({ ...cfg, maxJuice: Math.max(100, parseInt(e.target.value) || 175) })} className={field} />
        <span className="text-[10px] text-[#556277] mt-1 block">175 = nothing priced worse than −175 is bettable.</span>
      </label>
      <label className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e] block">
        <span className="block text-[#8b97ac] uppercase text-[11px] mb-1">Default sort</span>
        <select value={cfg.rankBy} onChange={e => onChange({ ...cfg, rankBy: e.target.value as RankBy })} className={field}>
          <option value="ev">EV at the posted price</option><option value="edge">Edge vs de-vigged price</option><option value="p">Model win probability</option>
        </select>
        <span className="text-[10px] text-[#556277] mt-1 block">Unpriced rows always sort below priced ones.</span>
      </label>
      <label className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e] flex items-center gap-2 cursor-pointer">
        <input type="checkbox" checked={cfg.bettableOnly} onChange={e => onChange({ ...cfg, bettableOnly: e.target.checked })} className="accent-cyan-400" />
        <span className="text-[#8b97ac] uppercase text-[11px]">Bettable only by default</span>
      </label>
    </div>
    <div className="grid sm:grid-cols-4 gap-3 text-xs font-mono">
      {FLOOR_META.map(f => (
        <label key={f.key} className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e] block">
          <span className="block text-[#8b97ac] text-[11px] mb-1">{f.label}</span>
          <input type="number" step={f.step} min="0" value={cfg.floors[f.key]} onChange={e => onChange({ ...cfg, floors: { ...cfg.floors, [f.key]: Math.max(0, parseFloat(e.target.value) || 0) } })} className={field} />
          {f.help && <span className="text-[10px] text-[#556277] mt-1 block">{f.help}</span>}
        </label>
      ))}
    </div>
    <button onClick={() => onChange(DEFAULT_BETTABLE)} className="px-2.5 py-1 rounded border border-[#222d3e] text-[11px] font-mono text-[#8b97ac] hover:text-white cursor-pointer">Reset to defaults</button>
  </div>
);
