import React, { useState, useEffect } from 'react';
import { NbaMarket, NBA_MARKETS, NbaOddsEntry, NbaPlayerProjection, NbaSettings, nbaOddsKey, NBA_MARKET_UNIT } from '../../types/nba';
import { NbaMatchup, NbaOddsMap, evalNbaRow } from '../../lib/nba_board';
import { NbaPlayerRow } from './NbaPlayerRow';
import { Calendar } from 'lucide-react';
import { BettableConfig } from '../../lib/bettable';
import { rankDeskRows } from '../../lib/desk_rank';

interface Props {
  date: string;
  setDate: (d: string) => void;
  games: NbaMatchup[];
  projections: NbaPlayerProjection[];
  market: NbaMarket;
  setMarket: (m: NbaMarket) => void;
  oddsMap: NbaOddsMap;
  settings: NbaSettings;
  setShowStabsOnly: (v: boolean) => void;
  onOddsChange: (market: NbaMarket, playerId: number, line: number, side: 'over' | 'under', val: number | null) => void;
  onLogRows: () => void;
  onOpenScreenshotUpload: () => void;
  statusLines: string[];
  bet: BettableConfig;
  oddsPanel?: React.ReactNode;
}

export const NbaDesk: React.FC<Props> = ({
  date, setDate, games, projections, market, setMarket, oddsMap, settings,
  setShowStabsOnly, onOddsChange, onLogRows, onOpenScreenshotUpload, statusLines, bet, oddsPanel
}) => {
  const [selectedGameId, setSelectedGameId] = useState<string | 'ALL'>('ALL');
  const [lines, setLines] = useState<Record<string, number>>({});
  const [fullModel, setFullModel] = useState(!bet.bettableOnly);
  const [pricedOnly, setPricedOnly] = useState(false);
  useEffect(() => { setFullModel(!bet.bettableOnly); }, [bet.bettableOnly]);

  const entryFor = (m: NbaMarket, id: number, line: number): NbaOddsEntry | undefined => oddsMap[nbaOddsKey(m, id, line)];
  const ranked = React.useMemo(() => rankDeskRows(projections, {
    sport: 'nba', market, cfg: bet,
    linesOf: p => p.markets[market].lines, defaultLine: p => p.markets[market].defaultLine, picked: p => lines[`${market}:${p.playerId}`],
    entryAt: (p, l) => entryFor(market, p.playerId, l),
    evalAt: (p, l) => { const r = evalNbaRow(p, market, l, entryFor(market, p.playerId, l), settings); const d = r.decision; return { hasMarket: d.hasMarket, evOver: d.evOver, evUnder: d.evUnder, edgeOver: d.edgeOver, edgeUnder: d.edgeUnder, pOver: r.pOver, pUnder: r.pUnder }; },
    mu: p => p.markets[market].mu, pm: p => p.markets[market].pm, inputs: p => p.inputsSource, availability: p => p.availability
  }), [projections, market, bet, lines, oddsMap, settings]);
  const lineFor = (p: NbaPlayerProjection) => ranked.find(r => r.p === p)?.line ?? p.markets[market].defaultLine;
  const tagOf = (p: NbaPlayerProjection) => evalNbaRow(p, market, lineFor(p), entryFor(market, p.playerId, lineFor(p)), settings).decision.tag;
  const plays = projections.filter(p => tagOf(p) !== 'PASS').length;

  const visibleRows = ranked.filter(r => {
    if (selectedGameId !== 'ALL' && r.p.gameId !== selectedGameId) return false;
    if (settings.showStabsOnly && tagOf(r.p) === 'PASS') return false;
    if (!fullModel && r.issue) return false;
    if (pricedOnly && !r.priced) return false;
    return true;
  });
  const visible = visibleRows.map(r => r.p);
  const hidden = ranked.filter(r => (selectedGameId === 'ALL' || r.p.gameId === selectedGameId) && r.issue).length;
  const gameIndex = React.useMemo(() => {
    const m = new Map<string, NbaPlayerProjection[]>();
    projections.forEach(p => { const k = p.gameId ?? ''; (m.get(k) || m.set(k, []).get(k)!).push(p); });
    return m;
  }, [projections]);
  const priced = Object.values(oddsMap).filter(e => e.over != null || e.under != null).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121824] p-3.5 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-[#8b97ac] font-mono">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="bg-[#0b0f14] border border-[#222d3e] px-2.5 py-1 rounded-lg text-white font-mono text-xs outline-none focus:border-cyan-400" />
          </div>

          <div className="flex items-center gap-1 bg-[#0f1520] p-1 rounded-xl border border-[#222d3e]">
            {NBA_MARKETS.map(m => (
              <button key={m} onClick={() => setMarket(m)}
                className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${market === m ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-[#8b97ac] hover:text-white'}`}>
                {NBA_MARKET_UNIT[m]}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button onClick={() => setSelectedGameId('ALL')}
              className={`px-3 py-1 rounded-full text-xs font-mono cursor-pointer ${selectedGameId === 'ALL' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'}`}>
              All ({projections.length})
            </button>
            {games.map(g => (
              <button key={g.gameId} onClick={() => setSelectedGameId(g.gameId)}
                className={`px-3 py-1 rounded-full text-xs font-mono whitespace-nowrap cursor-pointer ${selectedGameId === g.gameId ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'}`}>
                {g.away} @ {g.home}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <label className="flex items-center gap-1.5 text-xs font-mono text-[#8b97ac] cursor-pointer" title="Bettable = REAL inputs, known availability, real usage, sane juice. Off shows every modelled row.">
            <input type="checkbox" checked={fullModel} onChange={e => setFullModel(e.target.checked)} className="accent-cyan-400" />
            Full model{fullModel ? '' : ` (${hidden} hidden)`}
          </label>
          <label className="flex items-center gap-1.5 text-xs font-mono text-[#8b97ac] cursor-pointer">
            <input type="checkbox" checked={pricedOnly} onChange={e => setPricedOnly(e.target.checked)} className="accent-cyan-400" />
            Priced only
          </label>
          <label className="flex items-center gap-1.5 text-xs font-mono text-[#8b97ac] cursor-pointer">
            <input type="checkbox" checked={settings.showStabsOnly} onChange={e => setShowStabsOnly(e.target.checked)} className="accent-cyan-400" />
            Qualifying only ({plays})
          </label>
          <button onClick={onLogRows} disabled={!priced}
            className="px-3.5 py-1.5 bg-emerald-900/60 hover:bg-emerald-800/70 disabled:opacity-40 text-emerald-200 border border-emerald-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer"
            title="Snapshot every priced row (model P + market price) so it can be graded from the real box score">
            Log priced rows ({priced})
          </button>
          <button onClick={onOpenScreenshotUpload}
            className="px-3.5 py-1.5 bg-[#182232] hover:bg-[#222d3e] text-cyan-300 border border-cyan-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer">
            📷 Upload Lines Screenshot
          </button>
        </div>
      </div>

      {oddsPanel}
      {statusLines.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {statusLines.map(s => (
            <span key={s} className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-cyan-950/60 border border-cyan-700/60 text-cyan-300">{s}</span>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {visible.length === 0 ? (
          <div className="p-8 text-center text-[#556277] bg-[#121824] rounded-2xl border border-[#222d3e] font-mono text-xs">
            {games.length === 0
              ? 'No NBA games loaded for this date (schedule feed unreachable or no games). Nothing is invented offline.'
              : fullModel ? 'No players match the current filter.' : `No bettable players match (${hidden} low-usage / unavailable / estimated rows are hidden: tick Full model to see them).`}
          </div>
        ) : visibleRows.map(({ p, best, issue }) => (
          <div key={`${p.playerId}_${p.gameId}`}>
            {(best || (fullModel && issue)) && (
              <div className="flex flex-wrap gap-1.5 px-2 pb-0.5 text-[10px] font-mono">
                {best && <span className="px-1.5 py-0.5 rounded border border-emerald-700 text-emerald-300 bg-emerald-950/40">BEST LINE {best.side.toUpperCase()} {best.line}{best.ev !== null ? ` · EV ${(best.ev * 100).toFixed(1)}%` : best.edge !== null ? ` · edge ${best.edge.toFixed(1)}pp` : ''}</span>}
                {fullModel && issue && <span className="px-1.5 py-0.5 rounded border border-amber-700 text-amber-300 bg-amber-950/30">not bettable: {issue}</span>}
              </div>
            )}
          <NbaPlayerRow
            projection={p}
            gamePlayers={gameIndex.get(p.gameId ?? '') ?? [p]}
            market={market}
            entryFor={entryFor}
            settings={settings}
            selectedLine={lineFor(p)}
            onOddsChange={onOddsChange}
            onSelectLine={(m, id, l) => setLines(prev => ({ ...prev, [`${m}:${id}`]: l }))}
          />
          </div>
        ))}
      </div>
    </div>
  );
};
