import React from 'react';
import { NbaPrediction, NBA_MARKETS, NBA_MARKET_UNIT } from '../../types/nba';
import { CardBoard } from '../common/CardBoard';

interface Props { rows: NbaPrediction[]; edge: Set<string>; autoStatus: string }
const MARKETS = NBA_MARKETS.map(m => ({ id: m as string, label: NBA_MARKET_UNIT[m] }));

/** The automatic NBA daily card (shared board; nothing is logged by hand). */
export const NbaCardBoard: React.FC<Props> = ({ rows, edge, autoStatus }) => (
  <CardBoard rows={rows} edge={edge} autoStatus={autoStatus} sport="NBA" markets={MARKETS} exposureUnit="min" startWord="tip-off"
    sourceWord="the real box score" avgNote="this season's per-game average before the game" />
);
