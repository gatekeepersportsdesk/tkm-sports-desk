# Gatekeep odds JSON (what the in-app "Odds import" panel reads)

An array of objects (or `{ "lines": [...] }`). One object per posted line; keep several lines per player-market and one object per book.

| field | required | notes |
|---|---|---|
| book | no (default `other`) | `bet99`, `bet365`, anything else is kept as written |
| sport | recommended | `nba` \| `nhl` \| `nfl` \| `mlb`; rows for another sport are ignored by the panel |
| player | yes | full name as the book shows it; ambiguous names are skipped, never guessed |
| market | yes | nba: pts reb ast tpm pra stl blk · nhl: sog pts · nfl: rec · mlb: hit (line 0.5 only). Common book wording ("Points", "3-Pointers Made", "Shots on Goal", "Receptions") is normalised |
| line | yes | number ≥ 0 |
| over / under | at least one | American (`-115`, `+130`) or decimal (`1.87`); blank = no price (never a default) |
| asOf | no | ISO timestamp, informational |

The import writes prices only: it never changes the model and never grades anything.
