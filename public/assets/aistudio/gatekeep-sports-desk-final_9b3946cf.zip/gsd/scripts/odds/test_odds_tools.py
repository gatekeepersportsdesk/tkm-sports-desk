import json, tempfile, unittest
from pathlib import Path
import write_gatekeep_json as w
import parse_table as pt

HERE = Path(__file__).parent


class T(unittest.TestCase):
    def test_parse_odds(self):
        self.assertEqual(w.parse_odds("−115"), -115); self.assertEqual(w.parse_odds("+130"), 130)
        self.assertEqual(w.parse_odds("1.91"), -110); self.assertEqual(w.parse_odds("2.5"), 150)
        for bad in ("", None, "abc", "0", "1.0", "-"): self.assertIsNone(w.parse_odds(bad))

    def test_normalize_and_reject(self):
        rows, rej = w.normalize_rows([
            {"book": "Bet 365", "sport": "nba", "player": "A B", "market": "Points", "line": "22.5", "over": "-105", "under": "-125"},
            {"book": "bet365", "sport": "nba", "player": "A B", "market": "Points", "line": "22.5", "over": "-105", "under": "-125"},  # duplicate
            {"sport": "nba", "player": "A B", "market": "Dunks", "line": 1.5, "over": -110},
            {"sport": "nba", "player": "A B", "market": "pts", "line": "x", "over": -110},
            {"sport": "nba", "player": "A B", "market": "pts", "line": 20.5},
            {"sport": "mlb", "player": "C D", "market": "Hits", "line": 1.5, "over": -110, "under": -110},
            {"sport": "mlb", "player": "C D", "market": "Hits", "line": 0.5, "over": -250},
            {"sport": "xyz", "player": "E F", "market": "pts", "line": 1.5, "over": -110},
            {"sport": "nba", "market": "pts", "line": 1.5, "over": -110},
        ], as_of="2026-10-29T00:00:00Z")
        self.assertEqual([(r["sport"], r["book"], r["market"], r["line"], r["over"], r["under"]) for r in rows],
                         [("nba", "bet365", "pts", 22.5, -105, -125), ("mlb", "other", "hit", 0.5, -250, None)])
        self.assertEqual(len(rej), 6)  # the duplicate is dropped silently, not rejected

    def test_write_idempotent_and_sorted(self):
        rows, _ = w.normalize_rows(json.loads((HERE / "examples/sample_nba.json").read_text()))
        with tempfile.TemporaryDirectory() as d:
            p1 = w.write_files(rows, d, "2026-10-29"); a = p1[0].read_text()
            p2 = w.write_files(rows, d, "2026-10-29"); self.assertEqual(a, p2[0].read_text())
            self.assertEqual([p.name for p in p1], ["odds_nba_2026-10-29.json"])
            out = json.loads(a)
            self.assertEqual(len(out), 4); self.assertEqual({r["book"] for r in out}, {"bet365", "bet99"})
            self.assertEqual([r["market"] for r in out].count("tpm"), 1)

    def test_html_table(self):
        raw = pt.parse_html((HERE / "examples/sample_table.html").read_text(encoding="utf-8"), "bet365", "nba", "points")
        rows, rej = w.normalize_rows(raw)
        self.assertEqual([(r["player"], r["line"], r["over"], r["under"]) for r in rows],
                         [("Jamal Murray", 22.5, -105, -125), ("Jamal Murray", 24.5, 150, -185), ("Nikola Jokić", 26.5, -115, None)])
        self.assertEqual(len(rej), 1)

    def test_csv_text_table(self):
        raw = pt.parse_text((HERE / "examples/sample_table.csv").read_text(), "bet99", "nba", "pts")
        self.assertEqual(len(w.normalize_rows(raw)[0]), 2)

    def test_samples_match_schema(self):
        for f in ("sample_nba.json", "sample_nhl.json"):
            rows, rej = w.normalize_rows(json.loads((HERE / "examples" / f).read_text()))
            self.assertEqual(rej, []); self.assertTrue(rows)


if __name__ == "__main__":
    unittest.main()
