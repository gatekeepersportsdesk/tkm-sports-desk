"""Normalise raw prop rows into the JSON the Gatekeep "Odds import" panel reads. No network calls in this file.

Raw rows are dicts with (case-insensitive) keys: book, sport, player, market, line, over, under, asOf.
Output rows: {"book","sport","player","market","line","over","under","asOf"} with American odds as integers.

CLI:  python write_gatekeep_json.py --in raw.csv --sport nba --out out_dir
      (input may be .csv or .json; --sport is used for rows that carry no sport column)
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import sys
from pathlib import Path

SPORTS = ("nba", "nhl", "nfl", "mlb")
BOOKS = {"bet99": "bet99", "bet 99": "bet99", "bet365": "bet365", "bet 365": "bet365"}

# must stay in step with src/lib/odds_ingest.ts (the app re-normalises anyway; this keeps the files readable)
MARKETS = {
    "nba": {"pts": "pts", "points": "pts", "reb": "reb", "rebs": "reb", "rebounds": "reb", "ast": "ast", "assists": "ast",
            "tpm": "tpm", "3pm": "tpm", "3pt": "tpm", "threes": "tpm", "3-pointers": "tpm", "3-pointers made": "tpm",
            "3 pointers made": "tpm", "three pointers made": "tpm", "threes made": "tpm", "pra": "pra", "pts+reb+ast": "pra",
            "points + rebounds + assists": "pra", "pts + reb + ast": "pra", "stl": "stl", "steals": "stl", "blk": "blk", "blocks": "blk"},
    "nhl": {"sog": "sog", "shots": "sog", "shots on goal": "sog", "player shots on goal": "sog", "pts": "pts", "points": "pts", "player points": "pts"},
    "nfl": {"rec": "rec", "receptions": "rec", "player receptions": "rec", "receptions made": "rec"},
    "mlb": {"hit": "hit", "hits": "hit", "player hits": "hit", "to record a hit": "hit", "h": "hit"},
}


def norm_market(sport: str, raw) -> str | None:
    k = re.sub(r"\s+", " ", str(raw or "").strip().lower())
    t = MARKETS[sport]
    return t.get(k) or t.get(re.sub(r"^(player|total)\s+", "", k))


def norm_book(raw) -> str:
    k = str(raw or "").strip().lower()
    return BOOKS.get(k, k or "other")


def parse_odds(raw) -> int | None:
    """American ('-115', '+130', unicode minus) or decimal ('1.87') -> American int. Anything unreadable -> None (never a default)."""
    if raw is None:
        return None
    s = str(raw).strip().replace("−", "-").replace("–", "-").replace("—", "-").lstrip("+")
    if not s:
        return None
    try:
        x = float(s)
    except ValueError:
        return None
    if x == 0:
        return None
    if abs(x) >= 100:
        return int(round(x))
    if x >= 1.01:
        return int(round((x - 1) * 100)) if x >= 2 else -int(round(100 / (x - 1)))
    return None


def _pick(row: dict, *keys):
    for k in keys:
        v = row.get(k)
        if v is not None and str(v).strip() != "":
            return v
    return None


def normalize_rows(rows, default_sport: str | None = None, as_of: str | None = None):
    """Return (clean_rows, rejected) where rejected is a list of (row_number, reason)."""
    out, rejected, seen = [], [], set()
    stamp = as_of or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    for i, raw in enumerate(rows, 1):
        row = {re.sub(r"[\s_-]", "", str(k).lower()): v for k, v in (raw or {}).items()}
        sport = str(_pick(row, "sport", "league") or default_sport or "").strip().lower()
        if sport not in SPORTS:
            rejected.append((i, f"sport '{sport}' is not one of {SPORTS}")); continue
        player = str(_pick(row, "player", "name", "playername") or "").strip()
        if not player:
            rejected.append((i, "no player")); continue
        market = norm_market(sport, _pick(row, "market", "prop", "stat"))
        if not market:
            rejected.append((i, f"{player}: market '{_pick(row, 'market', 'prop', 'stat')}' is not a {sport} market")); continue
        try:
            line = float(_pick(row, "line", "point", "handicap", "total"))
        except (TypeError, ValueError):
            rejected.append((i, f"{player}: line is not a number")); continue
        if line < 0:
            rejected.append((i, f"{player}: negative line")); continue
        if sport == "mlb" and line != 0.5:
            rejected.append((i, f"{player}: the desk prices MLB hits at 0.5 only")); continue
        over, under = parse_odds(_pick(row, "over", "overodds", "o")), parse_odds(_pick(row, "under", "underodds", "u"))
        if over is None and under is None:
            rejected.append((i, f"{player}: no readable price on either side")); continue
        book = norm_book(_pick(row, "book", "sportsbook", "source"))
        key = (sport, book, player.lower(), market, line)
        if key in seen:  # idempotent: the same posted line twice in one file is kept once (the first one)
            continue
        seen.add(key)
        out.append({"book": book, "sport": sport, "player": player, "market": market, "line": line, "over": over, "under": under,
                    "asOf": str(_pick(row, "asof", "timestamp", "time") or stamp)})
    return out, rejected


def write_files(rows, out_dir: str | Path, date: str | None = None, combined: bool = False) -> list[Path]:
    """One file per sport (odds_{sport}_{date}.json) or a single odds_all_{date}.json. Deterministic ordering."""
    d = date or dt.date.today().isoformat()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    order = lambda r: (r["sport"], r["player"].lower(), r["market"], r["line"], r["book"])
    groups = {"all": sorted(rows, key=order)} if combined else {s: sorted([r for r in rows if r["sport"] == s], key=order) for s in SPORTS}
    paths = []
    for name, rs in groups.items():
        if not rs:
            continue
        p = out_dir / f"odds_{name}_{d}.json"
        p.write_text(json.dumps(rs, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        paths.append(p)
    return paths


def read_raw(path: str | Path):
    p = Path(path)
    text = p.read_text(encoding="utf-8-sig")
    if p.suffix.lower() == ".json":
        j = json.loads(text)
        return j if isinstance(j, list) else next((j[k] for k in ("lines", "props", "rows", "data") if isinstance(j.get(k), list)), [])
    return list(csv.DictReader(text.splitlines()))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--in", dest="inp", required=True, help="raw .csv or .json")
    ap.add_argument("--sport", choices=SPORTS, help="sport for rows without a sport column")
    ap.add_argument("--out", default="out", help="output folder")
    ap.add_argument("--date", help="YYYY-MM-DD for the file name (default today)")
    ap.add_argument("--combined", action="store_true", help="one odds_all file instead of one per sport")
    a = ap.parse_args(argv)
    rows, rejected = normalize_rows(read_raw(a.inp), a.sport)
    paths = write_files(rows, a.out, a.date, a.combined)
    for p in paths:
        print(f"wrote {p}")
    print(f"{len(rows)} line(s) written, {len(rejected)} rejected")
    for n, why in rejected[:50]:
        print(f"  rejected row {n}: {why}", file=sys.stderr)
    return 0 if rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
