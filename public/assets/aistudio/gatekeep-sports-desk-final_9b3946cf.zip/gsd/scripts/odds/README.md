# Local odds producer (optional, outside the app)

The Gatekeep web app **never scrapes** and never fetches odds from a book. It reads a JSON / CSV file you load in
**Odds import**. This folder holds a small local tool that produces that file. Nothing here is imported by the app.

## Setup
```
cd scripts/odds
pip install -r requirements.txt     # only needed for fetch_template.py; the writer and the table parser use the standard library
```

## 1. Write Gatekeep JSON from raw rows (no network)
```
python write_gatekeep_json.py --in examples/sample_nba.json --out out --date 2026-10-29
python write_gatekeep_json.py --in examples/sample_table.csv --sport nba --out out      # a CSV needs --sport (and a book/market column or use parse_table.py)
```
Writes `out/odds_nba_YYYY-MM-DD.json` (one file per sport, or `--combined`). Rows with no player, market, line or readable price are
dropped and listed on screen; the same posted line twice in one file is kept once.

## 2. Manual path (works today, no automation): save a page or copy a table
```
python parse_table.py --html saved_page.html --book bet365 --sport nba --market points --out raw.json
python write_gatekeep_json.py --in raw.json --out out
```
`--text copied_table.txt` takes a copied table (tab or comma separated, header row with Player / Line / Over / Under).
Try it on `examples/sample_table.html`.

## 3. Load it in Gatekeep
Open the sport's desk → **Odds import** → **Load odds file…** → pick `odds_nba_YYYY-MM-DD.json` → **Apply to board**.
Pick "best of all books" or one book. Typing a price on the board still overrides. If the script fails that day, the in-app
screenshot upload is the fallback.

## 4. Cadence
Pre-match only: once when lines open and once near lock. Not continuous, not live.

## 5. `fetch_template.py` (optional, yours to maintain)
A skeleton that opens the pages listed in your local `config.local.json` in a visible browser, waits for you to confirm the table is
showing, reads it and writes the JSON. It ships with **no site-specific selectors, no login, no credentials, no stealth or
anti-bot features, and a hard cap of 12 pages per run**. I could not validate any book's page layout from the build environment, so the
manual path in section 2 is the tested one.

## Terms and breakage
Automated access can violate a book's terms of use; if you run the template you accept that risk. Prefer an official feed or a manual
export. Page layouts change without notice and will break the parser; that is expected maintenance, not a bug in the app.
