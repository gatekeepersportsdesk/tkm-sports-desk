"""Manual path: turn a saved page (HTML) or a copied table (CSV / tab-separated text) into raw prop rows. No network, standard library only.

A prop table is recognised by its header cells: a player column plus a line column and over / under price columns
(names like "Player", "Line", "Over", "Under", "O", "U" are accepted). One page = one book + one sport + one market,
given on the command line or in the config, because a table rarely says so itself.

  python parse_table.py --html saved_page.html --book bet365 --sport nba --market points --out raw.json
  python parse_table.py --text copied_table.txt --book bet99 --sport nhl --market sog --out raw.json
then:  python write_gatekeep_json.py --in raw.json --out out
Several lines for one player simply appear as several table rows.
"""
from __future__ import annotations

import argparse
import json
import re
from html.parser import HTMLParser


class _Tables(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self._depth += 1
            self.tables.append([])
        elif tag == "tr" and self.tables:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._cell is not None and self._row is not None:
            self._row.append(re.sub(r"\s+", " ", "".join(self._cell)).strip())
            self._cell = None
        elif tag == "tr" and self._row is not None and self.tables:
            if any(self._row):
                self.tables[-1].append(self._row)
            self._row = None
        elif tag == "table":
            self._depth -= 1

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


HEAD = {
    "player": {"player", "name", "playername"},
    "line": {"line", "point", "points", "total", "handicap", "o/u"},
    "over": {"over", "o", "overodds"},
    "under": {"under", "u", "underodds"},
}


def _columns(header: list[str]) -> dict[str, int] | None:
    idx = {}
    for i, h in enumerate(header):
        k = re.sub(r"[^a-z/]", "", h.lower())
        for field, names in HEAD.items():
            if k in names and field not in idx:
                idx[field] = i
    return idx if {"player", "line"} <= set(idx) and ("over" in idx or "under" in idx) else None


def rows_from_tables(tables: list[list[list[str]]], book: str, sport: str, market: str) -> list[dict]:
    out = []
    for t in tables:
        cols = _columns(t[0]) if t else None
        if not cols:
            continue
        for r in t[1:]:
            get = lambda f: r[cols[f]] if f in cols and cols[f] < len(r) else ""
            out.append({"book": book, "sport": sport, "player": get("player"), "market": market, "line": get("line"), "over": get("over"), "under": get("under")})
    return out


def parse_html(html: str, book: str, sport: str, market: str) -> list[dict]:
    p = _Tables()
    p.feed(html)
    return rows_from_tables(p.tables, book, sport, market)


def parse_text(text: str, book: str, sport: str, market: str) -> list[dict]:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    delim = "\t" if any("\t" in ln for ln in lines[:3]) else ","
    table = [[c.strip().strip('"') for c in ln.split(delim)] for ln in lines]
    return rows_from_tables([table], book, sport, market)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--html"); g.add_argument("--text")
    ap.add_argument("--book", required=True); ap.add_argument("--sport", required=True); ap.add_argument("--market", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    src = a.html or a.text
    body = open(src, encoding="utf-8-sig").read()
    rows = (parse_html if a.html else parse_text)(body, a.book, a.sport, a.market)
    json.dump(rows, open(a.out, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print(f"{len(rows)} raw row(s) -> {a.out}")
    return 0 if rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
