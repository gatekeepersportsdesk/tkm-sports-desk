/**
 * The automatic daily card: capture every player-market the model prices BEFORE tip-off, grade it from the real box
 * score afterwards, and summarise how good the projections actually were. No price, no clicking.
 *
 * Honesty rules built in:
 *  - only pre-game rows are captured (a game that is in progress or final is skipped), and a captured row is never rewritten;
 *  - a player who did not play is VOID, never a zero and never a miss;
 *  - headline numbers use REAL inputs with a known availability only; estimated / unknown rows are kept but reported separately;
 *  - the "win rate" is measured at the model's own line (about its mean). Counts are right-skewed, so 'under' wins more than half
 *    the time there for ANY model; the always-UNDER baseline is shown beside it. MAE vs the season-average comparator and
 *    interval coverage are the real quality tests.
 */
import { NbaMarket, NBA_MARKETS, NbaPlayerProjection, NbaPlayerSnapshot, NbaPrediction, NbaBoxLine, NbaLedgerRow, NBA_MARKET_UNIT } from '../types/nba';
import { NbaGame } from './nba_data';
import { gradeActual, nbinomPmf } from '../model/nhl_engine';
import { discretePit, pitCoverage, hashUnit } from '../model/calibration';

const NOT_PLAYING = new Set(['OUT', 'IR', 'INACTIVE', 'SCRATCHED']);

export function predictionId(date: string, market: NbaMarket, playerId: number): string { return `${date}:${market}:${playerId}`; }

/**
 * Rows for every priced player-market that is not already logged. Idempotent: calling it again later in the day only adds
 * players that were not on the board before (a later injury-report change never rewrites an earlier row).
 */
export function captureDailyCard(
  projections: NbaPlayerProjection[], games: NbaGame[], players: NbaPlayerSnapshot[], existing: Set<string>, date: string, now = Date.now()
): NbaPrediction[] {
  const open = new Set(games.filter(g => g.state === 'pre' && !g.completed && !g.postponed).map(g => g.gameId));
  const byId = new Map(players.map(p => [p.playerId, p]));
  const out: NbaPrediction[] = [];
  for (const p of projections) {
    if (!p.gameId || !open.has(p.gameId) || NOT_PLAYING.has(p.availability)) continue;
    const snap = byId.get(p.playerId);
    for (const m of NBA_MARKETS) {
      const id = predictionId(date, m, p.playerId);
      if (existing.has(id)) continue;
      const mp = p.markets[m];
      const probs = mp.probs[mp.defaultLine];
      if (!probs) continue;
      const pOver = probs.p_over / Math.max(1e-9, 1 - probs.p_push);
      out.push({
        id, date, capturedAt: now, gameId: p.gameId, market: m, playerId: p.playerId, name: p.name, team: p.team, opp: p.opp,
        mu: mp.mu, r: mp.r, line: mp.defaultLine, lean: pOver >= 0.5 ? 'OVER' : 'UNDER', pOver,
        pm: mp.pm, rate: mp.rate, oppF: mp.oppFactor, absF: mp.absFactor, lvl: mp.level,
        avg: snap && snap.gp > 0 ? snap.cum[m] / snap.gp : null,
        inputs: p.inputsSource, avail: p.availability, result: null, actual: null, minutes: null, err: null
      });
    }
  }
  return out;
}

/** New rows are added; an existing row is never overwritten (graded or not). */
export function mergePredictions(existing: NbaPrediction[], incoming: NbaPrediction[]): NbaPrediction[] {
  const seen = new Set(existing.map(r => r.id));
  const add = incoming.filter(r => !seen.has(r.id));
  return add.length ? [...existing, ...add] : existing;
}

const f1 = (x: number) => (Math.round(x * 10) / 10).toString();

/** A short, factual explanation built only from numbers we have (no invented causes). */
export function reasonFor(r: Pick<NbaPrediction, 'mu' | 'r' | 'line' | 'lean' | 'pm'>, actual: number, minutes: number, result: 'HIT' | 'MISS' | 'PUSH'): string {
  const head = `Model ${f1(r.mu)} vs ${r.line}. Actual ${actual} in ${Math.round(minutes)}m`;
  if (result === 'PUSH') return `PUSH (${r.lean}): ${head} — landed exactly on the line.`;
  if (result === 'HIT') return `WON (${r.lean}): ${head} — ${r.lean === 'OVER' ? 'cleared' : 'stayed under'}.`;
  // a miss: say which direction the surprise went and whether minutes or per-minute production carried it
  const higher = actual > r.line; // the outcome landed above the line (the lean was UNDER)
  const dm = minutes - r.pm;
  const bigMin = Math.abs(dm) >= Math.max(4, 0.12 * r.pm) && (dm > 0) === higher;
  const projRate = r.pm > 0 ? r.mu / r.pm : 0;
  const ratio = projRate > 0 && minutes > 0 ? actual / minutes / projRate : 1;
  const bigRate = (higher ? ratio >= 1.15 : ratio <= 0.85);
  const parts: string[] = [];
  if (bigMin) parts.push(`minutes ${higher ? 'higher' : 'lower'} than projected (${Math.round(minutes)} vs ${Math.round(r.pm)})`);
  if (bigRate) parts.push(`per-minute production ${higher ? 'higher' : 'lower'} than projected`);
  const sd = Math.sqrt(r.mu + (r.mu * r.mu) / r.r);
  const tail = parts.length ? parts.join('; ') : `within normal variance (model sd about ${f1(sd)})`;
  return `LOST (${r.lean}): ${head} — ${tail}.`;
}

/** Grade pending rows from real box lines. DNP / zero minutes = VOID; a game that never appears long after its date = VOID. */
export function gradePredictions(
  rows: NbaPrediction[], lines: NbaBoxLine[], today: string, staleDays = 7, now = Date.now()
): { rows: NbaPrediction[]; graded: number; pending: number; voided: number } {
  const byGame = new Map<string, Map<number, NbaBoxLine>>();
  for (const l of lines) { const m = byGame.get(l.gameId) ?? new Map<number, NbaBoxLine>(); m.set(l.playerId, l); byGame.set(l.gameId, m); }
  let graded = 0, pending = 0, voided = 0;
  const age = (d: string) => Math.floor((Date.parse(today) - Date.parse(d)) / 86400000);
  const out = rows.map(r => {
    if (r.result !== null) return r;
    const g = byGame.get(r.gameId);
    if (!g) {
      if (age(r.date) > staleDays) { voided++; return { ...r, result: 'VOID' as const, reason: 'VOID: the game never appeared in the box scores (postponed / cancelled?).', gradedAt: now }; }
      pending++; return r;
    }
    const l = g.get(r.playerId);
    if (!l || l.dnp || !(l.minutes > 0)) { voided++; return { ...r, result: 'VOID' as const, minutes: 0, reason: 'VOID: did not play (DNP / 0 minutes). Excluded from every statistic.', gradedAt: now }; }
    graded++;
    const actual = l.actual[r.market];
    const side = gradeActual(actual, r.line);
    const result = side === 'PUSH' ? 'PUSH' : (side === 'OVER') === (r.lean === 'OVER') ? 'HIT' : 'MISS';
    return { ...r, actual, minutes: l.minutes, err: actual - r.mu, result: result as 'HIT' | 'MISS' | 'PUSH', reason: reasonFor(r, actual, l.minutes, result), gradedAt: now };
  });
  return { rows: out, graded, pending, voided };
}

/** Headline statistics use REAL inputs with a known availability only. */
export const isHeadline = (r: Pick<NbaPrediction, 'inputs' | 'avail'>) => r.inputs === 'REAL' && r.avail !== 'UNKNOWN';

export interface MarketStats { market: NbaMarket; n: number; mae: number | null; bias: number | null; maeNaive: number | null; nNaive: number; maeOnNaive: number | null; coverage: (number | null)[] }
export interface CardSummary {
  logged: number; pending: number; voided: number; pushed: number; decided: number; hits: number; winRate: number | null;
  over: { n: number; hits: number }; under: { n: number; hits: number };
  brier: number | null; meanPOver: number | null; overRate: number | null;
  /** win rate of blindly leaning UNDER every row at these lines (count stats are right-skewed, so a line at the mean is beaten by 'under' more than half the time) */
  alwaysUnder: number | null;
  byMarket: MarketStats[];
}

export function summarizePredictions(all: NbaPrediction[], includeEstimated = false): CardSummary {
  const rows = all.filter(r => includeEstimated || isHeadline(r));
  const decided = rows.filter(r => r.result === 'HIT' || r.result === 'MISS');
  const hits = decided.filter(r => r.result === 'HIT').length;
  const side = (s: 'OVER' | 'UNDER') => { const d = decided.filter(r => r.lean === s); return { n: d.length, hits: d.filter(r => r.result === 'HIT').length }; };
  const played = rows.filter(r => (r.result === 'HIT' || r.result === 'MISS' || r.result === 'PUSH') && r.actual !== null);
  const bin = played.filter(r => r.result !== 'PUSH');
  const brier = bin.length ? bin.reduce((s, r) => s + (r.pOver - (r.actual! > r.line ? 1 : 0)) ** 2, 0) / bin.length : null;
  const byMarket = NBA_MARKETS.map(m => {
    const d = played.filter(r => r.market === m);
    const ae = d.map(r => Math.abs(r.actual! - r.mu));
    const withAvg = d.filter(r => r.avg !== null);
    const pits = d.map(r => discretePit(k => nbinomPmf(k, r.mu, r.r), r.actual!, hashUnit(r.id)));
    const cov = d.length ? pitCoverage(pits).map(c => c.observed) : [null, null, null];
    return {
      market: m, n: d.length,
      mae: d.length ? ae.reduce((a, b) => a + b, 0) / d.length : null,
      bias: d.length ? d.reduce((s, r) => s + r.err!, 0) / d.length : null,
      maeNaive: withAvg.length ? withAvg.reduce((s, r) => s + Math.abs(r.actual! - r.avg!), 0) / withAvg.length : null,
      nNaive: withAvg.length,
      maeOnNaive: withAvg.length ? withAvg.reduce((s, r) => s + Math.abs(r.actual! - r.mu), 0) / withAvg.length : null,
      coverage: cov as (number | null)[]
    };
  });
  return {
    logged: rows.length, pending: rows.filter(r => r.result === null).length, voided: rows.filter(r => r.result === 'VOID').length, pushed: rows.filter(r => r.result === 'PUSH').length,
    decided: decided.length, hits, winRate: decided.length ? hits / decided.length : null, over: side('OVER'), under: side('UNDER'),
    brier, meanPOver: bin.length ? bin.reduce((s, r) => s + r.pOver, 0) / bin.length : null,
    overRate: bin.length ? bin.filter(r => r.actual! > r.line).length / bin.length : null,
    alwaysUnder: bin.length ? bin.filter(r => r.actual! < r.line).length / bin.length : null, byMarket
  };
}

/** player-markets that also have a priced STAB / FADE logged the same day (the "edge plays" filter) */
export function edgeKeys(ledger: NbaLedgerRow[]): Set<string> {
  const s = new Set<string>();
  for (const r of ledger) if (r.tag !== 'PASS') s.add(predictionId(r.date, r.market, r.playerId));
  return s;
}

export type CardFilter = 'all' | 'won' | 'missed' | 'pending' | 'edge';
export function filterPredictions(rows: NbaPrediction[], f: CardFilter, market: NbaMarket | 'all', edge: Set<string>, includeEstimated: boolean): NbaPrediction[] {
  return rows.filter(r => {
    if (!includeEstimated && !isHeadline(r)) return false;
    if (market !== 'all' && r.market !== market) return false;
    if (f === 'won') return r.result === 'HIT';
    if (f === 'missed') return r.result === 'MISS';
    if (f === 'pending') return r.result === null;
    if (f === 'edge') return edge.has(r.id);
    return true;
  });
}

export { NBA_MARKET_UNIT };
