# Update 2 — tab reset, OCR integrity, sampling layer, NHL tuning

## Bugs found and fixed
* **"Kicked back to NFL"** — two causes. (1) `activeSport` lived only in React state, so any reload / hot reload / remount reset it to NFL; it is now persisted (`gatekeep_nav_v1`) and validated on load. (2) The screenshot scanner let Gemini's guess at the sport (`detectedSport`) override the target you picked, and Apply then switched the whole app to that sport (often NFL). The guess is now only a hint banner; your selection is never overridden.
* **Fabricated lines in the scanner (missed in the first pass).** On any OCR failure — and whenever you clicked a sport pill with lines loaded — the modal injected hard-coded sample lines with fake odds (JSN, Matthews, Judge…), and "Try Sample Slip" fed a fake slip through OCR. All removed. A failed scan now says so and adds nothing; manual rows start blank (no pre-filled -115/-115); Apply requires a player and at least one price.
* A render error in one desk can no longer blank the app: an error boundary wraps the content area (the sport switcher stays alive) and resets when you change tab.
* OCR prompt now returns a per-line `prop` (shots / points), tells the model not to guess unreadable values; NHL rows get a SOG/PTS market selector in the review table.

## Sampling layer (`src/model/sampler.ts`)
* Seeded Gaussian copula over the existing, validated negative-binomial marginals. Marginals stay exactly as priced (tested: sampled mean/variance/P(over) match the closed form); only the dependence between legs is added. Deterministic (same inputs → same answer).
* Why a copula rather than a from-scratch game simulator: the NFL marginals were validated by backtest and interval coverage; a game simulator would have to re-earn that calibration. Joint questions are where simulation matters, so that is where it is used. Closed form remains the path for single-leg prices.
* **Measured on real data** (`scripts/estimate_nfl_corr.ts`, nflverse 2025 wk3-18 + 2026 wk3-6, walk-forward residuals): WR/TE teammates ρ = +0.027 (±0.016), WR-WR +0.040, WR-TE +0.028, opposing receivers −0.001 (±0.015). So teammate receptions are NOT meaningfully negatively correlated once game script is in the mean, and an NFL stack is close to independent. The sampler's NFL priors use these numbers.
* **NHL same-skater shots↔points ρ = 0.35 is a PRIOR (not measured)** — the NHL feed could not be reached to measure it. Editable in Settings.
* UI: NHL player drawer has a shots + points combo panel (over/under any SOG line + any points line, joint vs independent, fair price, ±MC error). NFL has the library (`jointProbability`, `teamCorrelation`) but no screen yet.

## NHL Settings now expose every prior / frozen value
SOG r (frozen from sog_v1), points r, shrink Ks, position priors, opponent-factor K, stale-table weight, shots↔points ρ, Monte Carlo draws — each labelled "frozen" / "prior — not fitted" / "prior — not measured" / "setting", persisted, with Reset. Ledger rows keep the r they were priced with.

## Verified here
`tsc` clean, **79 tests** passing (sampler, OCR cleaning, tuning added), server + app bundle with esbuild.
Not verified: UI rendering, and the browser behaviour of the error boundary / persistence (logic only).

---

# Gatekeep Sports Desk — audit & fix pass (NFL v1.5 · MLB v5.9 · NHL sog_v2)

Benchmark in mind: RotoBot-style honesty — distributions not point guesses, calibration you can check,
injury/availability awareness, and no number on screen that did not come from data.

## What was wrong everywhere (and is now fixed in all three sports)
| Problem | Fix |
|---|---|
| "Edge" measured against the de-vigged line was treated as a bet signal, but you pay the vig | Every sport now requires **EV > 0 at the price offered** (shared `src/lib/odds.ts`) |
| Blank / garbage odds silently became +100 (fake 50% market, fake two-way) | Parsers return `null`; unpriced rows are model-only and can never qualify |
| Estimated / guessed inputs could still show BET / PLAY / STAB | One universal gate (availability → input quality → edge). ESTIMATED can never qualify |
| Hand-typed injury / roster lists | Removed. Availability comes from live feeds; no feed = UNKNOWN = cannot qualify |
| Random "settle demo" results flattered the scoreboards | Removed. Grading is from official box scores / nflverse. Legacy rows are tagged DEMO and excluded from every metric |
| Odds saved in localStorage with no date (yesterday's price on today's line) | Odds maps are date-stamped and discarded on another day |
| No way to tell if the model is calibrated | Shared calibration lib: Brier vs market, reliability bins, randomized-PIT 50/80/90% interval coverage |

## NFL receptions (v1.4 → v1.5) — validated on real nflverse data
* Real ingestion (`stats_player_week`, `snap_counts`, `injuries`, `games`): routes proxy = team dropbacks × snap %, TPRR shrunk to prior season, walk-forward (week W sees only weeks < W).
* Backtest reproduced the 2025 WR over-prediction; fixed with an in-season **decay-weighted** position ratio (actual/mu 0.935 → 0.991). Carrying the prior-season ratio made 2026 worse, so it is off.
* Early-season dispersion inflation α·(1 + 2.5/games). WR α .10 / TE α .125 re-validated.
* Game cap (3 BETs/game), one-sided price can never be BET, no fabricated -115/-115 baseline rows, receiver/team resolution bug fixed, schedule from nflverse (no hard-coded week, no ESPN spread guessing), real grades from nflverse.

## MLB hits (v5.8 → v5.9)
* Line probabilities from the PA model's hit-count distribution (Poisson-binomial), not a Poisson shortcut, so 1.5 / 2.5 lines are priced correctly (still not PLAY until you opt in).
* Real batter/pitcher inputs from statsapi (season, game log, platoon splits, K%, recent IP). Missing pieces → EST → PASS.
* PLAY requires confirmed lineup, slot 1–3, price window, **EV > 0**, REAL inputs.
* Ledger grades from official box scores (DNP = void, postponed = void); no random grading.
* Parlay picker: EV at the offered price; same-game haircut applied only when no quoted price; deterministic simulation.
* Reference-cache key now includes the tune (changing a setting no longer returns stale numbers).

## NHL (sog_v1 → sog_v2) — and the points market you asked for
* **Points market added** (NB, r = 12 is a prior to calibrate; lines 0.5 / 1.5 / 2.5). Shots / Points toggle on the desk.
* Skater rates are **shrunk** toward last season and a position prior (a 4-game 6.0 shots/game start is no longer priced as a 6.0 shooter).
* Real game logs (last 10 games) replace the fake `[round(mu) ×5]` form chips.
* Opponent factor from live shots-against / goals-against, shrunk by games played; the old hand-typed table is a labelled half-weight fallback.
* **FADE** now needs a real under price and +EV; over/under entered separately and de-vigged together.
* Removed: the 2024 hand-typed roster (players on teams they no longer play for), seeded odds, the fake fallback slate, ESPN game ids (can't be graded), `mu from the line` for screenshot players (now ESTIMATED from the position prior, cannot qualify), mutation of the seed array.
* Ledger: log priced rows → grade from the official box score; scoreboard shows per-market calibration, interval coverage, W-L and units for STAB/FADE only.

## Verified here
* `tsc` clean, **65 / 65 tests** (NFL 17, MLB 19, NHL 29) incl. fixtures for every parser and grader; `server.ts` and the whole app bundle with esbuild.
* NFL pipeline run end-to-end on real nflverse 2024-2026 files.

## NOT verified (be straight about it)
* The sandbox cannot reach the NHL, MLB or ESPN hosts. Those fetchers/parsers are tested against fixtures that follow the documented JSON shapes, **not live responses**. First run on your machine: open each tab and read the status chips (they say exactly which feed failed).
* The UI was typechecked and bundled, **not rendered** (React isn't installable offline here).
* NHL has no historical backtest here: shrinkage K (20 / 40), position priors, the points `r = 12`, and the opponent clamp are sensible priors, not fitted values. Let the ledger's reliability bins and interval coverage tell you what to move; don't trust them before ~200+ graded rows per market.
* ESPN's injury JSON shape was written defensively but is the least certain parser.

## Setup
`npm install && npm run dev` (needs Node 20+; `GEMINI_API_KEY` for screenshot OCR). Tests: `npx tsx --test src/model/*.test.ts`.
