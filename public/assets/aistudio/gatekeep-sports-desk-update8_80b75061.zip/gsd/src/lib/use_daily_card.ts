import { useCallback, useEffect, useRef, useState } from 'react';
import { CardRow, mergeCardRows, persistRows } from './card_core';

/**
 * Shared plumbing for every sport's automatic daily card: rows persisted in browser storage (120-day prune, quota fallback),
 * a ref that always holds the latest rows, and an add() that can only append (an existing row is never rewritten).
 */
export function useDailyCard<T extends CardRow>(storageKey: string, today: () => string) {
  const [rows, setRows] = useState<T[]>(() => {
    try { const v = JSON.parse(localStorage.getItem(storageKey) || '[]'); return Array.isArray(v) ? v : []; } catch { return []; }
  });
  const [status, setStatus] = useState('');
  const ref = useRef<T[]>(rows);
  useEffect(() => {
    ref.current = rows;
    const r = persistRows(storageKey, rows, today());
    if (!r.ok) setStatus('Browser storage is full: the daily card could not be saved. Export JSON from the scoreboard.');
    else if (r.trimmed) setStatus(`Browser storage is tight: kept the most recent ${r.kept} daily-card rows.`);
  }, [rows]);
  const add = useCallback((incoming: T[]) => setRows(prev => mergeCardRows(prev, incoming)), []);
  return { rows, ref, setRows, add, status, setStatus };
}

/**
 * Runs `run` automatically: after the slate loads (`ready` changes), when the scoreboard / History tab opens (`open` turns
 * true) and when the browser tab regains focus. Automatic runs are throttled to once per 5 minutes; `go(true)` is the
 * manual button and ignores the throttle. Never runs two at once.
 */
export function useAutoGrade(run: () => Promise<void>, ready: unknown, open: boolean) {
  const runRef = useRef(run);
  runRef.current = run;
  const busy = useRef(false);
  const last = useRef(0);
  const go = useCallback(async (manual: boolean) => {
    if (busy.current) return;
    if (!manual && Date.now() - last.current < 5 * 60 * 1000) return;
    busy.current = true; last.current = Date.now();
    try { await runRef.current(); } catch (e) { console.warn('auto-grade failed', e); } finally { busy.current = false; }
  }, []);
  useEffect(() => { void go(false); }, [ready]);
  useEffect(() => { if (open) void go(false); }, [open]);
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === 'visible') void go(false); };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, [go]);
  return go;
}
