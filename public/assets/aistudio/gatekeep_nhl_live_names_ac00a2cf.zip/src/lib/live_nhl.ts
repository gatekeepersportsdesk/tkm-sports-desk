import { NhlPlayerSnapshot, NhlGameMatchup } from '../types/nhl';

/** ESPN / UI abbrev → NHL API tricode */
const NHL_ABBREV: Record<string, string> = {
  SJ: 'SJS', SJS: 'SJS', LA: 'LAK', LAK: 'LAK', TB: 'TBL', TBL: 'TBL',
  NJ: 'NJD', NJD: 'NJD', WAS: 'WSH', WSH: 'WSH', MON: 'MTL', MTL: 'MTL',
  VEG: 'VGK', VGK: 'VGK', LV: 'VGK', UTAH: 'UTA', UTA: 'UTA',
  ANH: 'ANA', ANA: 'ANA', CLS: 'CBJ', CBJ: 'CBJ', CAL: 'CGY', CGY: 'CGY',
  NAS: 'NSH', NSH: 'NSH', WIN: 'WPG', WPG: 'WPG',
};

export function normalizeNhlTeam(code: string): string {
  const u = (code || '').toUpperCase();
  return NHL_ABBREV[u] || u;
}

export async function fetchNhlSchedule(dateStr: string): Promise<NhlGameMatchup[]> {
  try {
    const res = await fetch(`/api/nhl/schedule?date=${dateStr}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return (data.games || []).map((g: any) => ({
      gameId: g.gameId,
      startTimeUtc: g.startTimeUtc,
      awayTeam: normalizeNhlTeam(g.awayTeam),
      homeTeam: normalizeNhlTeam(g.homeTeam),
      venue: g.venue || '',
    }));
  } catch (e) {
    console.warn('NHL schedule fetch failed', e);
    return [];
  }
}

export async function fetchNhlSkatersForTeam(team: string): Promise<NhlPlayerSnapshot[]> {
  const t = normalizeNhlTeam(team);
  try {
    const res = await fetch(`/api/nhl/skaters/${t}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return (data.skaters || []).map((s: any) => ({
      playerId: s.playerId,
      name: s.name,
      team: s.team || t,
      pos: s.pos === 'D' ? 'D' : 'F',
      mu0: s.mu0,
      toiAvg: s.toiAvg,
      recentShots: s.recentShots || [2, 2, 2, 2, 2],
    })) as NhlPlayerSnapshot[];
  } catch (e) {
    console.warn('NHL skaters fetch failed for', t, e);
    return [];
  }
}

/** Load real names for every team on the slate. Never invent "Top Center". */
export async function loadNhlSkatersForGames(
  games: NhlGameMatchup[]
): Promise<Record<string, NhlPlayerSnapshot[]>> {
  const teams = Array.from(new Set(games.flatMap((g) => [g.awayTeam, g.homeTeam])));
  const out: Record<string, NhlPlayerSnapshot[]> = {};
  await Promise.all(
    teams.map(async (team) => {
      out[team] = await fetchNhlSkatersForTeam(team);
    })
  );
  return out;
}
