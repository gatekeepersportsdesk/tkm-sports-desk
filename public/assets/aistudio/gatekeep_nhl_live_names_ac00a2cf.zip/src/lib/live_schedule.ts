import { NflGameContext } from '../types/nfl';
import { MlbGameMatchup } from '../types/mlb';
import { NhlGameMatchup } from '../types/nhl';
import { NFL_GAMES } from '../data/nfl_seed';
import { MLB_SEEDED_SLATE, getProjectedLineupForTeam } from '../data/mlb_seed';
import { getFallbackNhlSlate } from '../data/nhl_seed';
import { MLB_PARK_FACTORS } from '../model/mlb_engine';

export async function fetchLiveNflGames(): Promise<Record<string, NflGameContext>> {
  try {
    // Try local server proxy first, then direct ESPN endpoint
    const res = await fetch('/api/games/nfl').catch(() =>
      fetch('https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard')
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const events = data.events || [];

    if (events.length > 0) {
      const liveGames: Record<string, NflGameContext> = {};

      events.forEach((ev: any) => {
        const comp = ev.competitions?.[0];
        if (!comp) return;

        const homeComp = comp.competitors?.find((c: any) => c.homeAway === 'home');
        const awayComp = comp.competitors?.find((c: any) => c.homeAway === 'away');

        const homeTeam = homeComp?.team?.abbreviation || 'HOME';
        const awayTeam = awayComp?.team?.abbreviation || 'AWAY';

        const dateObj = new Date(ev.date);
        const dayOfWeek = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
        let dayTag: 'Thursday' | 'Sunday' | 'Monday' = 'Sunday';
        if (dayOfWeek === 'Thursday') dayTag = 'Thursday';
        else if (dayOfWeek === 'Monday') dayTag = 'Monday';

        const kickoffTime = dateObj.toLocaleDateString('en-US', {
          weekday: 'short',
          hour: 'numeric',
          minute: '2-digit'
        });

        // Parse odds if available from ESPN
        const oddsObj = comp.odds?.[0];
        let spreadHome = 2.5;
        let overUnder = 43.5;

        if (oddsObj?.overUnder) {
          overUnder = parseFloat(oddsObj.overUnder) || 43.5;
        }
        if (oddsObj?.spread) {
          spreadHome = parseFloat(oddsObj.spread) || 2.5;
        }

        const impliedHome = (overUnder / 2.0) - (spreadHome / 2.0);
        const impliedAway = (overUnder / 2.0) + (spreadHome / 2.0);

        const id = `2026-w6-${awayTeam}@${homeTeam}`;
        liveGames[id] = {
          id,
          season: 2026,
          week: data.week?.number || 6,
          day: dayTag,
          kickoff: kickoffTime,
          away: awayTeam,
          home: homeTeam,
          spread_home: spreadHome,
          implied_total_home: impliedHome,
          spread_away: -spreadHome,
          implied_total_away: impliedAway
        };
      });

      if (Object.keys(liveGames).length > 0) {
        return liveGames;
      }
    }
  } catch (err) {
    console.warn('Could not auto-fetch ESPN NFL games, falling back to baseline schedule:', err);
  }

  return NFL_GAMES;
}

export async function fetchLiveMlbGames(): Promise<MlbGameMatchup[]> {
  try {
    const todayStr = new Date().toISOString().slice(0, 10);
    // Try official MLB stats API with hydrated lineups
    const res = await fetch(`https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=${todayStr}&hydrate=lineups,probablePitcher,team,linescore`)
      .catch(() => fetch('/api/games/mlb'));

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const gamesRaw = data.dates?.[0]?.games || [];

    if (gamesRaw.length > 0) {
      return gamesRaw.map((g: any) => {
        const awayTeam = g.teams?.away?.team?.abbreviation || 'AWAY';
        const homeTeam = g.teams?.home?.team?.abbreviation || 'HOME';
        const park = MLB_PARK_FACTORS[homeTeam] || 1.0;

        const awaySp = {
          name: g.teams?.away?.probablePitcher?.fullName || 'Probable Starter',
          hand: 'RHP',
          kPct: 22.0,
          kBf: 450,
          recentIp: 5.2
        };
        const homeSp = {
          name: g.teams?.home?.probablePitcher?.fullName || 'Probable Starter',
          hand: 'RHP',
          kPct: 22.0,
          kBf: 450,
          recentIp: 5.2
        };

        const parseLineup = (players: any[], teamCode: string, isHome: boolean, oppSp: any) => {
          if (!players || !players.length) return [];
          return players.slice(0, 9).map((p: any, idx: number) => ({
            id: p.id,
            name: p.fullName,
            team: teamCode,
            slot: idx + 1,
            isHome,
            hand: 'R',
            seasonBa: 0.255,
            xba: 0.255,
            recentBa: 0.255,
            recentAb: 35,
            bbPct: 0.08,
            confirmed: true,
            park,
            gamePk: g.gamePk,
            oppSp: oppSp.name,
            oppHand: oppSp.hand
          }));
        };

        const awayLineup = (g.lineups?.awayPlayers && g.lineups.awayPlayers.length > 0)
          ? parseLineup(g.lineups.awayPlayers, awayTeam, false, homeSp)
          : getProjectedLineupForTeam(awayTeam, false, homeSp, g.gamePk, park);
        const homeLineup = (g.lineups?.homePlayers && g.lineups.homePlayers.length > 0)
          ? parseLineup(g.lineups.homePlayers, homeTeam, true, awaySp)
          : getProjectedLineupForTeam(homeTeam, true, awaySp, g.gamePk, park);

        return {
          gamePk: g.gamePk,
          away: awayTeam,
          home: homeTeam,
          status: g.status?.detailedState || 'Scheduled',
          live: g.status?.abstractGameState === 'Live',
          inning: g.linescore?.currentInning || 0,
          park,
          confirmed: Boolean(awayLineup.length && homeLineup.length),
          awaySp,
          homeSp,
          batters: [...awayLineup, ...homeLineup]
        };
      });
    }
  } catch (err) {
    console.warn('Could not auto-fetch MLB games, using active slate:', err);
  }

  return MLB_SEEDED_SLATE;
}

export async function fetchLiveNhlGames(dateStr: string): Promise<NhlGameMatchup[]> {
  try {
    const res = await fetch(`/api/games/nhl?date=${dateStr}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const events = data.events || [];

    if (events.length > 0) {
      return events.map((ev: any) => {
        const comp = ev.competitions?.[0];
        const homeComp = comp?.competitors?.find((c: any) => c.homeAway === 'home');
        const awayComp = comp?.competitors?.find((c: any) => c.homeAway === 'away');
        return {
          gameId: parseInt(ev.id) || Math.floor(Math.random() * 1000000),
          startTimeUtc: ev.date || new Date().toISOString(),
          awayTeam: awayComp?.team?.abbreviation || 'AWAY',
          homeTeam: homeComp?.team?.abbreviation || 'HOME',
          venue: comp?.venue?.fullName || 'NHL Arena'
        };
      });
    }
  } catch (err) {
    console.warn('Could not auto-fetch NHL games, using active slate:', err);
  }

  return getFallbackNhlSlate(dateStr);
}
