export interface NflPlayerStats {
  name: string;
  pos: 'WR' | 'TE';
  team: string;
  route_pct: number;
  season_tprr: number;
  prior_tprr: number;
  routes: number;
  targets: number;
  receptions: number;
  games: number;
  season_avg: number;
  ratio: number;
}

export interface NflGameContext {
  id: string;
  season: number;
  week: number;
  day: 'Thursday' | 'Sunday' | 'Monday';
  kickoff: string;
  away: string;
  home: string;
  spread_home: number;
  implied_total_home: number;
  spread_away: number;
  implied_total_away: number;
}

export interface NflPropSnapshot {
  id: string;
  season: number;
  week: number;
  book: string;
  kind: 'pre' | 'open' | 'close';
  timestamp: string;
  player: string;
  pos: 'WR' | 'TE';
  team: string;
  gameKey: string;
  line: number;
  overOdds: string;
  underOdds: string;
  mu: number;
  muStructural: number;
  muAdapted: number;
  dropbacks: number;
  shrunkTprr: number;
  shrunkCatchRate: number;
  seasonAvg: number;
  alpha: number;
  p_over: number;
  p_under: number;
  fair_over: number;
  fair_under: number;
  lean: 'OVER' | 'UNDER';
  edge: number;
  cardStatus: 'BET' | 'PASS' | 'OFF';
  cardReason: string;
  oddsOffered: number;
}

export interface NflBetRecord {
  snapshot_id: string;
  side: 'over' | 'under';
  stake: number;
  odds_taken: number;
  placed_at: string;
}

export interface NflActualRecord {
  played: boolean;
  actual: number;
}
