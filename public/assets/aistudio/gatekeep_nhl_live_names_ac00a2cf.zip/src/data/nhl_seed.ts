import { NhlPlayerSnapshot, NhlGameMatchup } from '../types/nhl';

export const NHL_SEED_PLAYERS: NhlPlayerSnapshot[] = [
  // Edmonton Oilers
  { playerId: 8478402, name: "Connor McDavid", team: "EDM", pos: "F", mu0: 3.42, toiAvg: 21.8, recentShots: [4, 5, 2, 4, 6, 3, 5] },
  { playerId: 8477934, name: "Leon Draisaitl", team: "EDM", pos: "F", mu0: 3.08, toiAvg: 20.9, recentShots: [3, 4, 3, 2, 5, 4] },
  { playerId: 8475784, name: "Zach Hyman", team: "EDM", pos: "F", mu0: 3.65, toiAvg: 19.5, recentShots: [5, 4, 6, 3, 4, 7] },
  { playerId: 8476454, name: "Ryan Nugent-Hopkins", team: "EDM", pos: "F", mu0: 2.12, toiAvg: 19.1, recentShots: [2, 1, 3, 2, 4] },
  { playerId: 8480803, name: "Evan Bouchard", team: "EDM", pos: "D", mu0: 3.15, toiAvg: 23.2, recentShots: [4, 3, 5, 2, 4, 6] },

  // Toronto Maple Leafs
  { playerId: 8479318, name: "Auston Matthews", team: "TOR", pos: "F", mu0: 4.45, toiAvg: 21.0, recentShots: [5, 6, 4, 7, 3, 5] },
  { playerId: 8478483, name: "Mitchell Marner", team: "TOR", pos: "F", mu0: 2.25, toiAvg: 21.2, recentShots: [2, 3, 1, 4, 2] },
  { playerId: 8477939, name: "William Nylander", team: "TOR", pos: "F", mu0: 3.75, toiAvg: 19.8, recentShots: [4, 5, 3, 6, 4, 5] },
  { playerId: 8475166, name: "John Tavares", team: "TOR", pos: "F", mu0: 2.85, toiAvg: 17.5, recentShots: [3, 2, 4, 3, 5] },
  { playerId: 8476853, name: "Morgan Rielly", team: "TOR", pos: "D", mu0: 2.05, toiAvg: 23.6, recentShots: [2, 1, 3, 2, 4] },

  // Colorado Avalanche
  { playerId: 8477492, name: "Nathan MacKinnon", team: "COL", pos: "F", mu0: 4.75, toiAvg: 22.8, recentShots: [6, 5, 7, 4, 6, 8] },
  { playerId: 8478420, name: "Mikko Rantanen", team: "COL", pos: "F", mu0: 3.35, toiAvg: 22.1, recentShots: [3, 4, 5, 2, 4] },
  { playerId: 8480069, name: "Cale Makar", team: "COL", pos: "D", mu0: 2.85, toiAvg: 24.5, recentShots: [3, 4, 2, 5, 3] },
  { playerId: 8477444, name: "Artturi Lehkonen", team: "COL", pos: "F", mu0: 2.10, toiAvg: 18.2, recentShots: [2, 3, 1, 3, 2] },

  // Boston Bruins
  { playerId: 8477956, name: "David Pastrnak", team: "BOS", pos: "F", mu0: 4.55, toiAvg: 20.2, recentShots: [6, 4, 5, 7, 4, 6] },
  { playerId: 8475745, name: "Charlie Coyle", team: "BOS", pos: "F", mu0: 1.85, toiAvg: 17.6, recentShots: [1, 2, 3, 1, 2] },
  { playerId: 8473419, name: "Brad Marchand", team: "BOS", pos: "F", mu0: 2.70, toiAvg: 18.9, recentShots: [3, 2, 4, 3, 5] },
  { playerId: 8479325, name: "Charlie McAvoy", team: "BOS", pos: "D", mu0: 1.80, toiAvg: 23.4, recentShots: [2, 3, 1, 2, 2] },

  // Florida Panthers
  { playerId: 8477493, name: "Aleksander Barkov", team: "FLA", pos: "F", mu0: 2.65, toiAvg: 20.4, recentShots: [2, 3, 4, 2, 3] },
  { playerId: 8479314, name: "Matthew Tkachuk", team: "FLA", pos: "F", mu0: 3.80, toiAvg: 18.9, recentShots: [4, 5, 3, 6, 4] },
  { playerId: 8477933, name: "Sam Reinhart", team: "FLA", pos: "F", mu0: 3.10, toiAvg: 20.1, recentShots: [3, 4, 2, 5, 4] },
  { playerId: 8477932, name: "Aaron Ekblad", team: "FLA", pos: "D", mu0: 2.05, toiAvg: 21.5, recentShots: [2, 3, 1, 2, 4] },

  // Vancouver Canucks
  { playerId: 8480012, name: "Elias Pettersson", team: "VAN", pos: "F", mu0: 2.55, toiAvg: 19.7, recentShots: [3, 2, 4, 1, 3] },
  { playerId: 8476442, name: "J.T. Miller", team: "VAN", pos: "F", mu0: 2.45, toiAvg: 20.0, recentShots: [2, 3, 1, 4, 3] },
  { playerId: 8478444, name: "Brock Boeser", team: "VAN", pos: "F", mu0: 2.75, toiAvg: 18.5, recentShots: [3, 4, 2, 5, 3] },
  { playerId: 8480800, name: "Quinn Hughes", team: "VAN", pos: "D", mu0: 2.65, toiAvg: 25.1, recentShots: [3, 2, 4, 3, 5] },

  // New York Rangers
  { playerId: 8478550, name: "Artemi Panarin", team: "NYR", pos: "F", mu0: 3.70, toiAvg: 20.3, recentShots: [4, 3, 5, 6, 4] },
  { playerId: 8476459, name: "Mika Zibanejad", team: "NYR", pos: "F", mu0: 2.95, toiAvg: 19.8, recentShots: [3, 2, 4, 5, 3] },
  { playerId: 8477447, name: "Vincent Trocheck", team: "NYR", pos: "F", mu0: 2.75, toiAvg: 21.1, recentShots: [3, 4, 2, 3, 4] },
  { playerId: 8479323, name: "Adam Fox", team: "NYR", pos: "D", mu0: 1.85, toiAvg: 23.9, recentShots: [1, 2, 3, 2, 1] },

  // Carolina Hurricanes
  { playerId: 8478427, name: "Sebastian Aho", team: "CAR", pos: "F", mu0: 3.10, toiAvg: 19.8, recentShots: [4, 3, 5, 2, 4] },
  { playerId: 8480830, name: "Andrei Svechnikov", team: "CAR", pos: "F", mu0: 3.25, toiAvg: 17.2, recentShots: [3, 5, 2, 4, 5] },
  { playerId: 8482093, name: "Seth Jarvis", team: "CAR", pos: "F", mu0: 2.35, toiAvg: 18.8, recentShots: [2, 3, 4, 1, 3] },
  { playerId: 8476885, name: "Brent Burns", team: "CAR", pos: "D", mu0: 2.45, toiAvg: 21.6, recentShots: [3, 2, 4, 3, 2] }
];

export const NHL_INITIAL_ODDS_MAP: Record<string, number> = {
  "8478402_2.5": -155, // McDavid Over 2.5
  "8477934_2.5": -130, // Draisaitl Over 2.5
  "8475784_3.5": 115,  // Hyman Over 3.5
  "8479318_3.5": -140, // Matthews Over 3.5
  "8477939_3.5": 105,  // Nylander Over 3.5
  "8477492_4.5": -115, // MacKinnon Over 4.5
  "8477956_4.5": -120, // Pastrnak Over 4.5
  "8479314_3.5": -110, // Tkachuk Over 3.5
  "8480800_2.5": 100   // Hughes Over 2.5
};

export function getFallbackNhlSlate(dateIso: string): NhlGameMatchup[] {
  return [
    { gameId: 2024020101, startTimeUtc: `${dateIso}T23:00:00Z`, awayTeam: "TOR", homeTeam: "EDM", venue: "Rogers Place" },
    { gameId: 2024020102, startTimeUtc: `${dateIso}T00:00:00Z`, awayTeam: "BOS", homeTeam: "FLA", venue: "Amerant Bank Arena" },
    { gameId: 2024020103, startTimeUtc: `${dateIso}T01:30:00Z`, awayTeam: "COL", homeTeam: "VAN", venue: "Rogers Arena" },
    { gameId: 2024020104, startTimeUtc: `${dateIso}T02:00:00Z`, awayTeam: "NYR", homeTeam: "CAR", venue: "Lenovo Center" }
  ];
}

export function getSkatersForNhlTeam(team: string): NhlPlayerSnapshot[] {
  // Seed is a fallback only. Live path must call /api/nhl/skaters/:team.
  // NEVER invent role placeholders like "SJ Top Center" — those are not players.
  const found = NHL_SEED_PLAYERS.filter(p => p.team === team);
  return found;
}
