import { MlbGameMatchup, MlbBatterInput } from '../types/mlb';
import { MLB_PARK_FACTORS } from '../model/mlb_engine';

export const MLB_PROJECTED_LINEUPS: Record<string, { name: string; id: number; hand: string; ba: number }[]> = {
  CLE: [
    { name: "Steven Kwan", id: 680757, hand: "L", ba: 0.292 },
    { name: "Jose Ramirez", id: 608070, hand: "S", ba: 0.279 },
    { name: "Josh Naylor", id: 647304, hand: "L", ba: 0.243 },
    { name: "David Fry", id: 681807, hand: "R", ba: 0.263 },
    { name: "Lane Thomas", id: 657041, hand: "R", ba: 0.237 },
    { name: "Jhonkensy Noel", id: 678877, hand: "R", ba: 0.218 },
    { name: "Andres Gimenez", id: 665926, hand: "L", ba: 0.252 },
    { name: "Austin Hedges", id: 595978, hand: "R", ba: 0.152 },
    { name: "Brayan Rocchio", id: 677587, hand: "S", ba: 0.206 }
  ],
  TB: [
    { name: "Yandy Diaz", id: 650490, hand: "R", ba: 0.281 },
    { name: "Brandon Lowe", id: 664040, hand: "L", ba: 0.244 },
    { name: "Josh Lowe", id: 666139, hand: "L", ba: 0.241 },
    { name: "Christopher Morel", id: 666624, hand: "R", ba: 0.196 },
    { name: "Junior Caminero", id: 691406, hand: "R", ba: 0.248 },
    { name: "Jose Siri", id: 642350, hand: "R", ba: 0.187 },
    { name: "Jose Caballero", id: 676609, hand: "R", ba: 0.227 },
    { name: "Ben Rortvedt", id: 666163, hand: "L", ba: 0.228 },
    { name: "Taylor Walls", id: 670764, hand: "S", ba: 0.183 }
  ],
  NYY: [
    { name: "Gleyber Torres", id: 643396, hand: "R", ba: 0.257 },
    { name: "Juan Soto", id: 665742, hand: "L", ba: 0.288 },
    { name: "Aaron Judge", id: 592450, hand: "R", ba: 0.322 },
    { name: "Giancarlo Stanton", id: 650402, hand: "R", ba: 0.233 },
    { name: "Jazz Chisholm Jr.", id: 665862, hand: "L", ba: 0.256 },
    { name: "Anthony Rizzo", id: 519203, hand: "L", ba: 0.228 },
    { name: "Anthony Volpe", id: 683011, hand: "R", ba: 0.243 },
    { name: "Austin Wells", id: 669224, hand: "L", ba: 0.229 },
    { name: "Alex Verdugo", id: 657077, hand: "L", ba: 0.233 }
  ],
  LAD: [
    { name: "Shohei Ohtani", id: 660271, hand: "L", ba: 0.310 },
    { name: "Mookie Betts", id: 605141, hand: "R", ba: 0.289 },
    { name: "Freddie Freeman", id: 518692, hand: "L", ba: 0.282 },
    { name: "Teoscar Hernandez", id: 605170, hand: "R", ba: 0.272 },
    { name: "Max Muncy", id: 571970, hand: "L", ba: 0.232 },
    { name: "Will Smith", id: 669257, hand: "R", ba: 0.248 },
    { name: "Tommy Edman", id: 669242, hand: "S", ba: 0.237 },
    { name: "Gavin Lux", id: 666158, hand: "L", ba: 0.251 },
    { name: "Enrique Hernandez", id: 571771, hand: "R", ba: 0.229 }
  ],
  BOS: [
    { name: "Jarren Duran", id: 677951, hand: "L", ba: 0.285 },
    { name: "Rafael Devers", id: 646240, hand: "L", ba: 0.272 },
    { name: "Tyler O'Neill", id: 650391, hand: "R", ba: 0.241 },
    { name: "Masataka Yoshida", id: 807799, hand: "L", ba: 0.280 },
    { name: "Wilyer Abreu", id: 680776, hand: "L", ba: 0.253 },
    { name: "Triston Casas", id: 671213, hand: "L", ba: 0.241 },
    { name: "Ceddanne Rafaela", id: 678882, hand: "R", ba: 0.246 },
    { name: "Connor Wong", id: 657136, hand: "R", ba: 0.280 },
    { name: "Trevor Story", id: 596115, hand: "R", ba: 0.228 }
  ],
  COL: [
    { name: "Ezequiel Tovar", id: 678662, hand: "R", ba: 0.269 },
    { name: "Brenton Doyle", id: 663697, hand: "R", ba: 0.260 },
    { name: "Ryan McMahon", id: 668843, hand: "L", ba: 0.242 },
    { name: "Michael Toglia", id: 672515, hand: "S", ba: 0.218 },
    { name: "Brendan Rodgers", id: 663898, hand: "R", ba: 0.267 },
    { name: "Charlie Blackmon", id: 453568, hand: "L", ba: 0.256 },
    { name: "Nolan Jones", id: 666134, hand: "L", ba: 0.225 },
    { name: "Jacob Stallings", id: 607732, hand: "R", ba: 0.263 },
    { name: "Sam Hilliard", id: 656541, hand: "L", ba: 0.238 }
  ]
};

export function getProjectedLineupForTeam(
  team: string,
  isHome: boolean,
  oppSp: { name: string; hand: string },
  gamePk: number,
  park: number
): MlbBatterInput[] {
  const roster = MLB_PROJECTED_LINEUPS[team] || [
    { name: `${team} Leadoff`, id: 910001, hand: "L", ba: 0.275 },
    { name: `${team} Two-Hole`, id: 910002, hand: "R", ba: 0.285 },
    { name: `${team} Three-Hole`, id: 910003, hand: "L", ba: 0.280 },
    { name: `${team} Cleanup`, id: 910004, hand: "R", ba: 0.265 },
    { name: `${team} Five-Hitter`, id: 910005, hand: "R", ba: 0.255 },
    { name: `${team} Six-Hitter`, id: 910006, hand: "L", ba: 0.245 },
    { name: `${team} Seven-Hitter`, id: 910007, hand: "R", ba: 0.235 },
    { name: `${team} Eight-Hitter`, id: 910008, hand: "R", ba: 0.225 },
    { name: `${team} Nine-Hitter`, id: 910009, hand: "S", ba: 0.215 }
  ];

  return roster.map((p, idx) => ({
    id: p.id,
    name: p.name,
    team,
    slot: idx + 1,
    isHome,
    hand: p.hand,
    seasonBa: p.ba,
    xba: p.ba,
    recentBa: p.ba + 0.012,
    recentAb: 38,
    bbPct: 0.09,
    confirmed: true,
    park,
    gamePk,
    oppSp: oppSp.name,
    oppHand: oppSp.hand
  }));
}

export const MLB_SEEDED_SLATE: MlbGameMatchup[] = [
  {
    gamePk: 745301,
    away: "BOS",
    home: "NYY",
    status: "Confirmed",
    live: false,
    inning: 0,
    park: MLB_PARK_FACTORS.NYY,
    confirmed: true,
    awaySp: { name: "Brayan Bello", hand: "RHP", kPct: 22.4, kBf: 450, recentIp: 5.1 },
    homeSp: { name: "Gerrit Cole", hand: "RHP", kPct: 27.8, kBf: 510, recentIp: 6.0 },
    batters: [
      ...getProjectedLineupForTeam("BOS", false, { name: "Gerrit Cole", hand: "RHP" }, 745301, MLB_PARK_FACTORS.NYY),
      ...getProjectedLineupForTeam("NYY", true, { name: "Brayan Bello", hand: "RHP" }, 745301, MLB_PARK_FACTORS.NYY)
    ]
  },
  {
    gamePk: 745302,
    away: "LAD",
    home: "COL",
    status: "Confirmed",
    live: false,
    inning: 0,
    park: MLB_PARK_FACTORS.COL,
    confirmed: true,
    awaySp: { name: "Tyler Glasnow", hand: "RHP", kPct: 32.2, kBf: 490, recentIp: 5.2 },
    homeSp: { name: "Austin Gomber", hand: "LHP", kPct: 16.5, kBf: 410, recentIp: 4.8 },
    batters: [
      ...getProjectedLineupForTeam("LAD", false, { name: "Austin Gomber", hand: "LHP" }, 745302, MLB_PARK_FACTORS.COL),
      ...getProjectedLineupForTeam("COL", true, { name: "Tyler Glasnow", hand: "RHP" }, 745302, MLB_PARK_FACTORS.COL)
    ]
  }
];

export const MLB_INITIAL_ODDS_MAP: Record<number, { over: string; under: string; line?: number }> = {
  677951: { over: "-160", under: "+130", line: 0.5 }, // Jarren Duran
  646240: { over: "-180", under: "+145", line: 0.5 }, // Rafael Devers
  680776: { over: "-135", under: "+105", line: 0.5 }, // Wilyer Abreu
  643396: { over: "-170", under: "+135", line: 0.5 }, // Gleyber Torres
  665742: { over: "-195", under: "+155", line: 0.5 }, // Juan Soto
  592450: { over: "-190", under: "+150", line: 0.5 }, // Aaron Judge
  660271: { over: "-210", under: "+165", line: 0.5 }, // Shohei Ohtani
  605141: { over: "-185", under: "+145", line: 0.5 }, // Mookie Betts
  518692: { over: "-175", under: "+140", line: 0.5 }, // Freddie Freeman
  680757: { over: "-165", under: "+130", line: 0.5 }, // Steven Kwan
  608070: { over: "-190", under: "+150", line: 0.5 }, // Jose Ramirez
  650490: { over: "-175", under: "+140", line: 0.5 }, // Yandy Diaz
  664040: { over: "-155", under: "+125", line: 0.5 }  // Brandon Lowe
};
