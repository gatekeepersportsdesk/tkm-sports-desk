import React, { useState } from 'react';
import { MlbGameMatchup, MlbBatterInput, MlbHitProjection, MlbGateResult } from '../../types/mlb';
import { scoreMlbHit, gateMlbRow, MLB_DEFAULT_TUNE } from '../../model/mlb_engine';
import { MlbBatterCard } from './MlbBatterCard';
import { MlbPlayerSheet } from './MlbPlayerSheet';

interface MlbDeskProps {
  games: MlbGameMatchup[];
  oddsMap: Record<number, { over: string; under: string; line?: number }>;
  parlayLegs: number[];
  tune: typeof MLB_DEFAULT_TUNE;
  onUpdateOdds: (id: number, side: 'over' | 'under', val: string) => void;
  onUpdateLine?: (id: number, line: number) => void;
  onToggleParlay: (batter: MlbBatterInput, gate: MlbGateResult, price: { over: string; under: string; line?: number }) => void;
  onLogAllPriced: (pricedRows: any[]) => void;
  onOpenScreenshotUpload: () => void;
}

export const MlbDesk: React.FC<MlbDeskProps> = ({
  games,
  oddsMap,
  parlayLegs,
  tune,
  onUpdateOdds,
  onUpdateLine,
  onToggleParlay,
  onLogAllPriced,
  onOpenScreenshotUpload
}) => {
  const [filter, setFilter] = useState<'ALL' | 'PLAY' | 'PASS'>('ALL');
  const [selectedSheetRow, setSelectedSheetRow] = useState<any | null>(null);

  // Compute all row projections with full line flexibility
  const allRows: {
    batter: MlbBatterInput;
    hit: MlbHitProjection;
    gate: MlbGateResult;
    game: MlbGameMatchup;
    price: { over: string; under: string; line?: number };
  }[] = [];

  games.forEach(game => {
    game.batters.forEach(b => {
      const oppSp = b.isHome ? game.awaySp : game.homeSp;
      const hit = scoreMlbHit(b, oppSp, game.park, undefined, 4.4, tune);
      const price = oddsMap[b.id] || { over: "", under: "", line: 0.5 };
      const gate = gateMlbRow({
        confirmed: game.confirmed,
        slot: b.slot,
        live: game.live,
        inning: game.inning,
        line: price.line !== undefined ? price.line : 0.5,
        over: price.over,
        under: price.under,
        hit,
        tune
      });

      allRows.push({ batter: b, hit, gate, game, price });
    });
  });

  const playCount = allRows.filter(r => r.gate.call === 'PLAY').length;
  const passCount = allRows.filter(r => r.gate.call === 'PASS').length;

  const handleLogClick = () => {
    const priced = allRows.filter(r => Boolean(r.price.over));
    if (priced.length === 0) {
      alert("No rows have odds entered yet.");
      return;
    }
    onLogAllPriced(priced);
  };

  return (
    <div className="space-y-4">
      {/* Control ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121824] p-3.5 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center gap-1.5 bg-[#0f1520] p-1 rounded-xl border border-[#222d3e]">
          <button
            onClick={() => setFilter('ALL')}
            className={`px-3.5 py-1.5 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
              filter === 'ALL' ? 'bg-amber-400 text-amber-950 font-bold' : 'text-[#8b97ac] hover:text-white'
            }`}
          >
            All Hitters ({allRows.length})
          </button>
          <button
            onClick={() => setFilter('PLAY')}
            className={`px-3.5 py-1.5 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
              filter === 'PLAY' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-[#8b97ac] hover:text-emerald-400'
            }`}
          >
            PLAYs Only ({playCount})
          </button>
          <button
            onClick={() => setFilter('PASS')}
            className={`px-3.5 py-1.5 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
              filter === 'PASS' ? 'bg-slate-700 text-white font-bold' : 'text-[#8b97ac] hover:text-white'
            }`}
          >
            PASS Only ({passCount})
          </button>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-2.5 py-1 rounded-lg flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Live Lineups Auto-Synced
          </span>
          <button
            onClick={onOpenScreenshotUpload}
            className="px-3.5 py-1.5 bg-[#182232] hover:bg-[#222d3e] text-amber-300 border border-amber-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer"
          >
            📷 Upload Lines Screenshot
          </button>
          <button
            onClick={handleLogClick}
            className="px-3.5 py-1.5 bg-[#182232] hover:bg-[#222d3e] text-white border border-[#222d3e] text-xs font-mono font-semibold rounded-xl transition cursor-pointer"
          >
            📋 Log Priced Rows
          </button>
        </div>
      </div>

      {/* Matchup game sections */}
      <div className="space-y-4">
        {games.map(game => {
          const gameRows = allRows.filter(r => r.game.gamePk === game.gamePk);
          const visibleRows = gameRows.filter(r => {
            if (filter === 'PLAY') return r.gate.call === 'PLAY';
            if (filter === 'PASS') return r.gate.call === 'PASS';
            return true;
          });

          return (
            <section key={game.gamePk} className="bg-[#121824] rounded-2xl border border-[#222d3e] overflow-hidden">
              <div className="px-4 py-3 bg-[#182232] border-b border-[#222d3e] flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold font-display uppercase tracking-wider text-white">
                    {game.away} @ {game.home}
                  </h3>
                  <p className="text-xs text-[#8b97ac] font-mono">
                    {game.status} &middot; Starters: {game.awaySp.name} vs {game.homeSp.name} &middot; Park factor: {game.park.toFixed(3)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs bg-[#0f1520] text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-900 font-semibold">
                    {gameRows.filter(r => r.gate.call === 'PLAY').length} PLAYs
                  </span>
                  <span className="font-mono text-xs bg-[#0f1520] text-[#8b97ac] px-2.5 py-1 rounded-full border border-[#222d3e]">
                    {gameRows.length} Batters on Board
                  </span>
                </div>
              </div>

              {visibleRows.length === 0 ? (
                <div className="p-8 text-center text-[#8b97ac] font-mono text-xs">
                  No batters match the current filter ({filter}) for this matchup.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 p-4">
                  {visibleRows.map(row => (
                    <MlbBatterCard
                      key={row.batter.id}
                      row={row}
                      inParlay={parlayLegs.includes(row.batter.id)}
                      onToggleParlay={() => onToggleParlay(row.batter, row.gate, row.price)}
                      onOpenSheet={() => setSelectedSheetRow(row)}
                      onOddsChange={(side, val) => onUpdateOdds(row.batter.id, side, val)}
                      onLineChange={lineVal => {
                        if (onUpdateLine) onUpdateLine(row.batter.id, lineVal);
                      }}
                    />
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>

      {/* Deep Dive Modal */}
      {selectedSheetRow && (
        <MlbPlayerSheet
          row={selectedSheetRow}
          onClose={() => setSelectedSheetRow(null)}
        />
      )}
    </div>
  );
};
