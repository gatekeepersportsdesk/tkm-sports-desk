import React, { useState } from 'react';
import { simMlbCard, parseAmericanOdds } from '../../model/mlb_engine';
import { Calculator } from 'lucide-react';

interface MlbParlayPickerProps {
  legs: {
    id: number;
    name: string;
    team: string;
    calP: number;
    overPrice: string;
    gamePk: number;
  }[];
  onRemoveLeg: (id: number) => void;
  onClear: () => void;
}

export const MlbParlayPicker: React.FC<MlbParlayPickerProps> = ({
  legs,
  onRemoveLeg,
  onClear
}) => {
  const [simResult, setSimResult] = useState<{
    sim: number;
    indep: number;
    lift: number;
    same: boolean;
  } | null>(null);

  const [simulating, setSimulating] = useState(false);

  const handleRunSim = () => {
    if (legs.length < 2) return;
    setSimulating(true);
    setTimeout(() => {
      const formattedLegs = legs.map(l => ({
        name: l.name,
        team: l.team,
        p: l.calP,
        game: l.gamePk
      }));
      const res = simMlbCard(formattedLegs, 6000);
      setSimResult(res);
      setSimulating(false);
    }, 50);
  };

  // Calculate combined decimal odds & American fair price
  const combinedDec = legs.reduce((acc, l) => {
    const parsed = parseAmericanOdds(l.overPrice);
    return acc * (parsed ? parsed.dec : 1.6);
  }, 1) * (simResult?.same ? 0.95 : 1.0);

  const fairAmerican = combinedDec >= 2.0
    ? `+${Math.round((combinedDec - 1) * 100)}`
    : `-${Math.round(100 / (combinedDec - 1))}`;

  return (
    <div className="space-y-4">
      <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center justify-between border-b border-[#222d3e] pb-3 mb-4">
          <div>
            <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white">
              Monte Carlo Parlay Simulator (Gaussian Copula)
            </h2>
            <p className="text-xs text-[#8b97ac]">
              Latent team covariance (0.07) &amp; cross-game factors (0.03) &middot; 6,000 trial draws
            </p>
          </div>
          <button
            onClick={onClear}
            className="text-xs text-[#8b97ac] hover:text-white underline font-mono"
          >
            Clear Selection
          </button>
        </div>

        {legs.length === 0 ? (
          <div className="p-8 text-center text-[#556277] text-xs font-mono">
            No legs selected. Click "+ Add to Parlay" on any green or qualified hitter card on the board.
          </div>
        ) : (
          <div className="space-y-3">
            <div className="space-y-2">
              {legs.map(leg => (
                <div key={leg.id} className="flex items-center justify-between p-2.5 rounded-xl bg-[#182232] border border-[#222d3e] text-xs font-mono">
                  <div>
                    <span className="font-bold text-white mr-2">{leg.name}</span>
                    <span className="text-[#8b97ac]">({leg.team} &middot; Over 0.5 Hits &middot; {(leg.calP * 100).toFixed(1)}% &middot; {leg.overPrice || '-160'})</span>
                  </div>
                  <button
                    onClick={() => onRemoveLeg(leg.id)}
                    className="text-rose-400 hover:text-rose-300 font-bold px-2 py-0.5"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleRunSim}
                disabled={legs.length < 2 || simulating}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl transition disabled:opacity-50 flex items-center gap-1.5"
              >
                <Calculator className="w-4 h-4" />
                {simulating ? 'Running 6,000 Trials...' : 'Run 6,000 Trial Simulation'}
              </button>
              <span className="text-xs font-mono text-[#8b97ac]">
                {legs.length} leg{legs.length !== 1 ? 's' : ''} queued (max 4)
              </span>
            </div>

            {simResult && (
              <div className="mt-4 p-4 rounded-xl bg-[#0f1520] border border-[#222d3e] space-y-2 text-xs font-mono">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <span className="text-[#8b97ac] text-[11px] block">Simulated Win %</span>
                    <p className="text-lg font-bold text-amber-400">{(simResult.sim * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <span className="text-[#8b97ac] text-[11px] block">Independent Win %</span>
                    <p className="text-lg font-bold text-white">{(simResult.indep * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <span className="text-[#8b97ac] text-[11px] block">Correlation Lift</span>
                    <p className={`text-lg font-bold ${simResult.lift >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {simResult.lift >= 0 ? '+' : ''}{(simResult.lift * 100).toFixed(1)} pts
                    </p>
                  </div>
                  <div>
                    <span className="text-[#8b97ac] text-[11px] block">Fair American Odds</span>
                    <p className="text-lg font-bold text-white">{fairAmerican}</p>
                  </div>
                </div>
                <p className="text-[11px] text-[#8b97ac] pt-1">
                  {simResult.same
                    ? 'Same-game parlay: Positive intra-team game correlation applied with book 5% SGP haircut.'
                    : 'Cross-game ticket: Independent variance applied across separate matchups.'}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
