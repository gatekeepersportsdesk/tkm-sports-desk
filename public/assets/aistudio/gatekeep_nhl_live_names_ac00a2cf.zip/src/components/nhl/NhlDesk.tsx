import React, { useState } from 'react';
import { NhlSkaterProjection, NhlGameMatchup } from '../../types/nhl';
import { NhlPlayerRow } from './NhlPlayerRow';
import { Calendar } from 'lucide-react';
import { evaluateNhlAction, pOverLine } from '../../model/nhl_engine';

interface NhlDeskProps {
  date: string;
  setDate: (d: string) => void;
  games: NhlGameMatchup[];
  projections: (NhlSkaterProjection & { gameId: number })[];
  oddsMap: Record<string, number>;
  edgeThreshold: number;
  maxJuice: number;
  showStabsOnly: boolean;
  setShowStabsOnly: (v: boolean) => void;
  onOddsChange: (playerId: number, line: number, val: number | null) => void;
  onOpenScreenshotUpload: () => void;
}

export const NhlDesk: React.FC<NhlDeskProps> = ({
  date,
  setDate,
  games,
  projections,
  oddsMap,
  edgeThreshold,
  maxJuice,
  showStabsOnly,
  setShowStabsOnly,
  onOddsChange,
  onOpenScreenshotUpload
}) => {
  const [selectedGameId, setSelectedGameId] = useState<number | 'ALL'>('ALL');
  const [filterMode, setFilterMode] = useState<'ALL' | 'PLAY' | 'PASS'>('ALL');
  const [playerLines, setPlayerLines] = useState<Record<number, number>>({});

  const handleSelectLine = (playerId: number, line: number) => {
    setPlayerLines(prev => ({ ...prev, [playerId]: line }));
  };

  // Evaluate each skater's grade for the filter
  const isSkaterPlay = (p: NhlSkaterProjection) => {
    const targetLine = playerLines[p.playerId] ?? p.defaultLine ?? 2.5;
    const odds = oddsMap[`${p.playerId}_${targetLine}`];
    if (odds === undefined || odds === null) return false;
    const targetProb = p.probOver[targetLine] ?? pOverLine(p.mu, targetLine);
    const decision = evaluateNhlAction(targetProb, odds, edgeThreshold, maxJuice);
    return decision.tag === 'STAB';
  };

  const totalPlays = projections.filter(isSkaterPlay).length;
  const totalPasses = projections.length - totalPlays;

  const visibleProjections = projections.filter(p => {
    if (selectedGameId !== 'ALL' && p.gameId !== selectedGameId) return false;
    if (filterMode === 'PLAY') return isSkaterPlay(p);
    if (filterMode === 'PASS') return !isSkaterPlay(p);
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Date Bar & Slate Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121824] p-3.5 rounded-2xl border border-[#222d3e]">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-[#8b97ac] font-medium font-mono">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="bg-[#0b0f14] border border-[#222d3e] px-2.5 py-1 rounded-lg text-white font-mono text-xs outline-none focus:border-cyan-400"
              title="Slate date (auto-initialized to today)"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button
              onClick={() => setSelectedGameId('ALL')}
              className={`px-3 py-1 rounded-full text-xs font-mono transition cursor-pointer ${
                selectedGameId === 'ALL'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'
              }`}
            >
              All Matchups ({projections.length} Skaters)
            </button>
            {games.map(g => (
              <button
                key={g.gameId}
                onClick={() => setSelectedGameId(g.gameId)}
                className={`px-3 py-1 rounded-full text-xs font-mono transition whitespace-nowrap cursor-pointer ${
                  selectedGameId === g.gameId
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-[#0f1520] text-[#8b97ac] border border-[#222d3e] hover:text-white'
                }`}
              >
                {g.awayTeam} @ {g.homeTeam}
              </button>
            ))}
          </div>
        </div>

        {/* Filter buttons: ALL, PLAY, PASS */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-[#0f1520] p-1 rounded-xl border border-[#222d3e]">
            <button
              onClick={() => setFilterMode('ALL')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
                filterMode === 'ALL'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              All Skaters ({projections.length})
            </button>
            <button
              onClick={() => setFilterMode('PLAY')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
                filterMode === 'PLAY'
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'text-[#8b97ac] hover:text-emerald-400'
              }`}
            >
              PLAYs Only ({totalPlays})
            </button>
            <button
              onClick={() => setFilterMode('PASS')}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg transition cursor-pointer ${
                filterMode === 'PASS'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'text-[#8b97ac] hover:text-white'
              }`}
            >
              PASS Only ({totalPasses})
            </button>
          </div>

          <button
            onClick={onOpenScreenshotUpload}
            className="px-3.5 py-1.5 bg-[#182232] hover:bg-[#222d3e] text-cyan-300 border border-cyan-500/40 text-xs font-mono font-semibold rounded-xl transition cursor-pointer"
          >
            📷 Upload Lines Screenshot
          </button>
        </div>
      </div>

      {/* Skaters List - Showing everyone on the board */}
      <div className="space-y-2">
        {visibleProjections.length === 0 ? (
          <div className="p-8 text-center text-[#556277] bg-[#121824] rounded-2xl border border-[#222d3e] font-mono text-xs">
            No skaters matching current filter ({filterMode}) on this slate.
          </div>
        ) : (
          visibleProjections.map(proj => (
            <NhlPlayerRow
              key={`${proj.playerId}_${proj.gameId}`}
              projection={proj}
              oddsMap={oddsMap}
              edgeThreshold={edgeThreshold}
              maxJuice={maxJuice}
              selectedLine={playerLines[proj.playerId]}
              onOddsChange={onOddsChange}
              onSelectLine={handleSelectLine}
            />
          ))
        )}
      </div>
    </div>
  );
};
