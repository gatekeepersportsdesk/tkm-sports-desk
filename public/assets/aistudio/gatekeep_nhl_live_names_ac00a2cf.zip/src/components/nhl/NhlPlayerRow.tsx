import React, { useState } from 'react';
import { NhlSkaterProjection } from '../../types/nhl';
import { evaluateNhlAction, parseAmericanOdds, pOverLine } from '../../model/nhl_engine';
import { NhlPlayerDrawer } from './NhlPlayerDrawer';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface NhlPlayerRowProps {
  projection: NhlSkaterProjection;
  oddsMap: Record<string, number>;
  edgeThreshold: number;
  maxJuice: number;
  selectedLine?: number;
  onOddsChange: (playerId: number, line: number, val: number | null) => void;
  onSelectLine?: (playerId: number, line: number) => void;
}

export const NhlPlayerRow: React.FC<NhlPlayerRowProps> = ({
  projection,
  oddsMap,
  edgeThreshold,
  maxJuice,
  selectedLine: externalLine,
  onOddsChange,
  onSelectLine
}) => {
  const [expanded, setExpanded] = useState(false);
  const [activeLine, setActiveLine] = useState<number>(externalLine ?? projection.defaultLine ?? 2.5);

  React.useEffect(() => {
    if (externalLine !== undefined) {
      setActiveLine(externalLine);
    }
  }, [externalLine]);

  const targetLine = activeLine;
  const currentOdds = oddsMap[`${projection.playerId}_${targetLine}`] ?? null;

  // Real-time Poisson survival probability for target line
  const targetModelProb = projection.probOver[targetLine] ?? pOverLine(projection.mu, targetLine);

  const rawDecision = evaluateNhlAction(targetModelProb, currentOdds, edgeThreshold, maxJuice);
  const isPlay = rawDecision.tag === 'STAB';

  const badgeStyle = isPlay
    ? 'bg-emerald-950 text-emerald-300 border border-emerald-500 font-bold shadow-sm shadow-emerald-900/50'
    : 'bg-slate-800 text-slate-400 border border-slate-700 font-medium';

  const handleLineSelect = (newLine: number) => {
    setActiveLine(newLine);
    if (onSelectLine) onSelectLine(projection.playerId, newLine);
  };

  return (
    <div className={`border rounded-xl transition overflow-hidden mb-2 ${
      isPlay
        ? 'border-emerald-500/70 bg-[#0c161d] shadow-sm shadow-emerald-950/40'
        : 'border-[#222d3e] bg-[#0f1520] hover:border-slate-600'
    }`}>
      <div
        onClick={() => setExpanded(!expanded)}
        className="p-3 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none"
      >
        {/* Left: Player + Team + Matchup */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white text-sm sm:text-base">
              {projection.name}
            </span>
            <span className="font-mono text-[10px] bg-[#182232] text-cyan-400 px-1.5 py-0.5 rounded border border-[#222d3e]">
              {projection.pos}
            </span>
          </div>
          <span className="text-xs font-mono text-[#8b97ac]">
            {projection.team} vs {projection.opp}
          </span>
        </div>

        {/* Center: Model mu + Editable Line Selector + Probability */}
        <div className="flex items-center gap-3 text-xs font-mono" onClick={e => e.stopPropagation()}>
          <div>
            <span className="text-[#8b97ac] text-[10px] block">Model &mu;</span>
            <span className="text-cyan-400 font-bold">{projection.mu.toFixed(2)} SOG</span>
          </div>

          <label className="text-[10px] text-[#8b97ac] flex flex-col">
            Line
            <select
              value={targetLine}
              onChange={e => handleLineSelect(parseFloat(e.target.value))}
              className="bg-[#0b0f14] border border-[#222d3e] rounded px-1.5 py-1 text-xs font-mono font-bold text-white outline-none focus:border-cyan-400 mt-0.5 cursor-pointer"
              title="Sportsbook Shot Line (no default locked)"
            >
              <option value={1.5}>1.5</option>
              <option value={2.5}>2.5</option>
              <option value={3.5}>3.5</option>
              <option value={4.5}>4.5</option>
              <option value={5.5}>5.5</option>
            </select>
          </label>

          <div>
            <span className="text-[#8b97ac] text-[10px] block">P(Over {targetLine})</span>
            <span className="text-white font-bold">{(targetModelProb * 100).toFixed(1)}%</span>
          </div>
        </div>

        {/* Right: Odds Input, Edge, and PLAY/PASS badge */}
        <div className="flex items-center gap-3 justify-between sm:justify-end" onClick={e => e.stopPropagation()}>
          <div className="flex items-center gap-1.5 font-mono text-xs">
            <label className="text-[10px] text-[#8b97ac]">
              Odds:
            </label>
            <input
              type="text"
              placeholder="-140"
              value={currentOdds !== null ? (currentOdds > 0 ? `+${currentOdds}` : `${currentOdds}`) : ''}
              onChange={e => onOddsChange(projection.playerId, targetLine, parseAmericanOdds(e.target.value))}
              className="w-16 bg-[#0b0f14] border border-[#222d3e] rounded px-2 py-1 text-xs font-mono text-center text-white outline-none focus:border-cyan-400"
              title="Enter your sportsbook's odds"
            />
          </div>

          <div className="text-right font-mono text-xs min-w-[65px]">
            <span className="text-[10px] text-[#8b97ac] block">Edge</span>
            <span className={`font-bold ${rawDecision.edge >= edgeThreshold ? 'text-emerald-400' : rawDecision.edge <= -edgeThreshold ? 'text-orange-400' : 'text-[#8b97ac]'}`}>
              {currentOdds !== null ? `${rawDecision.edge >= 0 ? '+' : ''}${rawDecision.edge.toFixed(1)} pp` : 'no price'}
            </span>
          </div>

          <span className={`text-[11px] font-mono px-2.5 py-0.5 rounded ${badgeStyle}`}>
            {isPlay ? 'PLAY' : 'PASS'}
          </span>

          <button
            onClick={() => setExpanded(!expanded)}
            className="text-[#8b97ac] hover:text-white cursor-pointer ml-1"
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {expanded && (
        <NhlPlayerDrawer
          projection={projection}
          targetLine={targetLine}
          odds={currentOdds}
          edge={rawDecision.edge}
          tag={rawDecision.tag}
          reason={rawDecision.reason}
        />
      )}
    </div>
  );
};
