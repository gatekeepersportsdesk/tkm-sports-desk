import React from 'react';
import { NhlGradedResultRecord } from '../../types/nhl';
import { Download, Upload, Zap, RotateCcw } from 'lucide-react';

interface NhlScoreboardProps {
  results: NhlGradedResultRecord[];
  onSettleDemo: () => void;
  onClearResults: () => void;
  onExportJson: () => void;
  onImportJson: (json: string) => void;
}

export const NhlScoreboard: React.FC<NhlScoreboardProps> = ({
  results,
  onSettleDemo,
  onClearResults,
  onExportJson,
  onImportJson
}) => {
  const total = results.length;
  const hits = results.filter(r => r.hit).length;
  const hitRate = total > 0 ? (hits / total) * 100 : 0;
  const meanModelP = total > 0 ? (results.reduce((s, r) => s + r.probOver, 0) / total) * 100 : 0;
  const meanMu = total > 0 ? results.reduce((s, r) => s + r.modelMu, 0) / total : 0;
  const meanActualSog = total > 0 ? results.reduce((s, r) => s + r.actualSog, 0) / total : 0;

  // Chart data: cumulative hit rate vs model P over time
  let cumHits = 0;
  let cumModelP = 0;
  const timeSeries = results.map((r, i) => {
    cumHits += r.hit ? 1 : 0;
    cumModelP += r.probOver;
    return {
      idx: i + 1,
      cumHitRate: (cumHits / (i + 1)) * 100,
      cumModelP: (cumModelP / (i + 1)) * 100
    };
  });

  const W = 360, H = 100, pad = 10;
  const chartPathHit = timeSeries.map((pt, i) => {
    const x = pad + (i / Math.max(1, timeSeries.length - 1)) * (W - 2 * pad);
    const y = H - pad - (pt.cumHitRate / 100) * (H - 2 * pad);
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');

  const chartPathModel = timeSeries.map((pt, i) => {
    const x = pad + (i / Math.max(1, timeSeries.length - 1)) * (W - 2 * pad);
    const y = H - pad - (pt.cumModelP / 100) * (H - 2 * pad);
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');

  return (
    <div className="space-y-4">
      {/* Top Banner & Synthetic Settle Demo */}
      <div className="bg-[#121824] p-5 rounded-2xl border border-[#222d3e]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#222d3e] pb-4 mb-4">
          <div>
            <h2 className="text-lg font-bold font-display uppercase tracking-wide text-white">
              NHL SOG Model Scoreboard &amp; Calibration
            </h2>
            <p className="text-xs text-[#8b97ac]">
              Tracks model hit/miss every day across all lines. Calibration tracks actual hit rate against predicted probability.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onSettleDemo}
              className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold font-display uppercase tracking-wider text-xs rounded-xl flex items-center gap-1.5 transition shadow-sm"
            >
              <Zap className="w-4 h-4" /> Run Settle Demo (MoneyPuck Simulator)
            </button>
            <button
              onClick={onExportJson}
              className="px-3.5 py-2 bg-[#182232] hover:bg-[#222d3e] text-white border border-[#222d3e] text-xs font-mono rounded-xl flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" /> Export JSON
            </button>
          </div>
        </div>

        {/* Summary KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
            <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Graded Plays</span>
            <p className="text-xl font-bold font-mono text-white mt-0.5">{total}</p>
            <span className="text-[10px] text-[#556277] font-mono">{hits} hits</span>
          </div>
          <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
            <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Actual Hit Rate</span>
            <p className={`text-xl font-bold font-mono mt-0.5 ${hitRate >= 50 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {total > 0 ? `${hitRate.toFixed(1)}%` : '—'}
            </p>
            <span className="text-[10px] text-[#556277] font-mono">Realized Over outcome</span>
          </div>
          <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
            <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Model Expected Win %</span>
            <p className="text-xl font-bold font-mono text-cyan-400 mt-0.5">
              {total > 0 ? `${meanModelP.toFixed(1)}%` : '—'}
            </p>
            <span className="text-[10px] text-[#556277] font-mono">Mean survival probability</span>
          </div>
          <div className="bg-[#0f1520] p-3 rounded-xl border border-[#222d3e]">
            <span className="text-[10px] font-mono text-[#8b97ac] uppercase">Mean &mu; vs Mean SOG</span>
            <p className="text-xl font-bold font-mono text-white mt-0.5">
              {total > 0 ? `${meanMu.toFixed(2)} / ${meanActualSog.toFixed(2)}` : '—'}
            </p>
            <span className="text-[10px] text-[#556277] font-mono">Expected vs realized SOG</span>
          </div>
        </div>

        {/* Cumulative Hit Rate vs Model P Chart */}
        <div className="bg-[#0f1520] p-4 rounded-xl border border-[#222d3e] mb-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-display uppercase tracking-wider text-xs font-bold text-white">
              Cumulative Hit Rate (Cyan) vs Model Expected Probability (Slate Dash)
            </h4>
            <div className="flex items-center gap-3 text-[11px] font-mono">
              <span className="flex items-center gap-1 text-cyan-400">
                <span className="w-2.5 h-0.5 bg-cyan-400 inline-block" /> Actual Hit Rate
              </span>
              <span className="flex items-center gap-1 text-[#8b97ac]">
                <span className="w-2.5 h-0.5 bg-[#8b97ac] border-b border-dashed inline-block" /> Model P
              </span>
            </div>
          </div>
          <div className="h-28 flex items-center justify-center">
            {timeSeries.length === 0 ? (
              <span className="text-xs text-[#556277] font-mono">
                No graded plays. Tap "Run Settle Demo" above to simulate game outcomes!
              </span>
            ) : (
              <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
                <line x1={pad} y1={H / 2} x2={W - pad} y2={H / 2} stroke="#222d3e" strokeDasharray="3,3" />
                <path d={chartPathModel} fill="none" stroke="#64748b" strokeWidth="1.8" strokeDasharray="4,4" />
                <path d={chartPathHit} fill="none" stroke="#22d3ee" strokeWidth="2.2" />
              </svg>
            )}
          </div>
        </div>

        {/* Graded Results Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#222d3e] text-[#8b97ac] uppercase tracking-wider text-[11px]">
                <th className="py-2 px-3">Date</th>
                <th className="py-2 px-3">Player</th>
                <th className="py-2 px-3">Team</th>
                <th className="py-2 px-3 text-right">Line</th>
                <th className="py-2 px-3 text-right">Model &mu;</th>
                <th className="py-2 px-3 text-right">Model P</th>
                <th className="py-2 px-3 text-right">Odds</th>
                <th className="py-2 px-3 text-right">Actual SOG</th>
                <th className="py-2 px-3 text-center">Grade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#222d3e]/50">
              {results.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#556277]">
                    No historical grades logged yet.
                  </td>
                </tr>
              ) : (
                results.slice(-50).reverse().map((r, idx) => (
                  <tr key={idx} className="hover:bg-[#182232]/50">
                    <td className="py-2 px-3 text-[#8b97ac]">{r.date}</td>
                    <td className="py-2 px-3 font-bold text-white">{r.playerName}</td>
                    <td className="py-2 px-3 text-[#8b97ac]">{r.team} vs {r.opp}</td>
                    <td className="py-2 px-3 text-right font-bold text-white">{r.line}</td>
                    <td className="py-2 px-3 text-right text-cyan-400">{r.modelMu.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right">{((r.probOver) * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-[#8b97ac]">{r.oddsTaken ? (r.oddsTaken > 0 ? `+${r.oddsTaken}` : `${r.oddsTaken}`) : '—'}</td>
                    <td className="py-2 px-3 text-right font-bold text-white">{r.actualSog}</td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${r.hit ? 'bg-emerald-950 text-emerald-300 border border-emerald-600' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                        {r.hit ? 'HIT' : 'MISS'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between pt-4 mt-4 border-t border-[#222d3e]">
          <button
            onClick={() => {
              const str = prompt("Paste scoreboard JSON backup:");
              if (str) onImportJson(str);
            }}
            className="text-xs font-mono text-[#8b97ac] hover:text-white flex items-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" /> Import JSON Backup
          </button>
          <button
            onClick={onClearResults}
            className="text-xs font-mono text-rose-400 hover:text-rose-300 flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Clear History
          </button>
        </div>
      </div>
    </div>
  );
};
