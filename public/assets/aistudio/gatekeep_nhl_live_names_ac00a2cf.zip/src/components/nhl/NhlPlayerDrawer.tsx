import React from 'react';
import { NhlSkaterProjection } from '../../types/nhl';

interface NhlPlayerDrawerProps {
  projection: NhlSkaterProjection;
  targetLine: number;
  odds: number | null;
  edge: number;
  tag: 'STAB' | 'FADE' | 'PASS';
  reason: string;
}

export const NhlPlayerDrawer: React.FC<NhlPlayerDrawerProps> = ({
  projection,
  targetLine,
  odds,
  edge,
  tag,
  reason
}) => {
  return (
    <div className="p-4 bg-[#182232] border-t border-[#222d3e] text-xs font-mono space-y-3">
      <div className="flex items-center justify-between border-b border-[#222d3e] pb-2">
        <span className="font-display uppercase tracking-wider text-sm font-bold text-white">
          SOG Projection &amp; Cashable Price Analysis
        </span>
        <span className="text-cyan-400">
          Model: sog_v1 &middot; r = 15.13
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs">
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">Base Shots Rate (&mu;&#x2080;)</span>
          <span className="text-white font-medium">{projection.mu0.toFixed(2)} SOG</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">Opponent Factor ({projection.opp})</span>
          <span className="text-white font-medium">{projection.oppFactor.toFixed(3)}x league avg</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">Final Expected Shots (&mu;)</span>
          <span className="text-cyan-400 font-bold">{projection.mu.toFixed(2)} SOG</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">Default Half-Line (&lfloor;&mu;&rfloor; + 0.5)</span>
          <span className="text-white font-medium">{projection.defaultLine.toFixed(1)} SOG</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">P(Over 1.5 SOG)</span>
          <span className="text-white font-medium">{(projection.probOver[1.5] * 100).toFixed(1)}%</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">P(Over 2.5 SOG)</span>
          <span className="text-white font-medium">{(projection.probOver[2.5] * 100).toFixed(1)}%</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">P(Over 3.5 SOG)</span>
          <span className="text-white font-medium">{(projection.probOver[3.5] * 100).toFixed(1)}%</span>
        </div>
        <div className="flex justify-between py-1 border-b border-[#222d3e]/50">
          <span className="text-[#8b97ac]">Average Ice Time (TOI)</span>
          <span className="text-white font-medium">{projection.toiAvg.toFixed(1)} mins</span>
        </div>
      </div>

      {/* Recent Form Chips */}
      <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
        <div className="text-[11px] text-[#8b97ac] uppercase mb-1.5 font-bold">
          Recent Realized Shots on Goal:
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {projection.recentShots.length > 0 ? (
            projection.recentShots.map((s, idx) => (
              <span
                key={idx}
                className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold ${
                  s >= projection.defaultLine
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {s}
              </span>
            ))
          ) : (
            <span className="text-[#556277] text-xs">Recent game logs TBD</span>
          )}
        </div>
      </div>

      {/* Why cashable / disqualified note */}
      <div className="p-3 bg-[#0f1520] rounded-xl border border-[#222d3e]">
        <div className="text-white font-bold mb-1">
          Action Rationale: <span className={`px-1.5 py-0.5 rounded text-[10px] ${tag === 'STAB' ? 'bg-emerald-950 text-emerald-300 border border-emerald-600' : 'bg-slate-800 text-slate-300'}`}>{tag}</span>
        </div>
        <div className="text-xs text-[#8b97ac]">
          {reason}
        </div>
      </div>
    </div>
  );
};
