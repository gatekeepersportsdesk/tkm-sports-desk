/**
 * Gatekeep Sports Desk — NFL Receptions Props Model (v1.4)
 * Pure mathematical functions for Negative Binomial discrete pricing,
 * Bayesian shrinkage, OLS dropbacks, and card rule qualification.
 */

export const NFL_CONFIG = {
  model_version: "v1.4 walk-forward + 0.6/0.4 season-avg blend",
  dropback_base: 36.697,
  dropback_spread_coef: 0.3075,
  dropback_total_coef: 0.3562,
  blend_weight: 0.60,
  k_routes: 100.0,
  k_catch: 30.0,
  league_catch_rate: 0.680,
  league_tprr: 0.195,
  alpha: {
    WR: 0.100,
    TE: 0.125
  },
  alpha_fallback: 0.180
};

/**
 * Lanczos approximation for log-gamma: ln(Gamma(z))
 */
export function logGamma(z: number): number {
  const g = 7;
  const C = [
    0.99999999999980993,
    676.5203681218851,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.138571095856205,
    9.9843695780195716e-6,
    1.5056327351493116e-7
  ];
  if (z < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * z)) - logGamma(1 - z);
  }
  z -= 1;
  let x = C[0];
  for (let i = 1; i < g + 2; i++) {
    x += C[i] / (z + i);
  }
  const t = z + g + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

/**
 * Negative Binomial PMF: P(Y = k)
 * Dispersion alpha: Var = mu + alpha * mu^2
 */
export function nbinomPmf(k: number, mu: number, alpha: number): number {
  if (mu <= 0 || k < 0) return 0.0;
  if (alpha <= 0.0001) {
    return Math.exp(-mu + k * Math.log(mu) - logGamma(k + 1));
  }
  const r = 1.0 / alpha;
  const p = r / (r + mu);
  const logPmf = logGamma(k + r) - (logGamma(k + 1) + logGamma(r))
               + r * Math.log(p) + k * Math.log(1.0 - p);
  return Math.exp(logPmf);
}

/**
 * Discrete line probabilities for integer or half-lines
 */
export function calculateDiscreteLineProbs(mu: number, line: number, alpha: number) {
  const isInteger = (line === Math.floor(line));
  const target = Math.floor(line);
  let pStrictlyLess = 0.0;
  for (let k = 0; k < target; k++) {
    pStrictlyLess += nbinomPmf(k, mu, alpha);
  }
  const pExact = nbinomPmf(target, mu, alpha);

  let pUnder: number;
  let pPush: number;
  let pOver: number;

  if (isInteger) {
    pUnder = pStrictlyLess;
    pPush = pExact;
    pOver = Math.max(0.0, 1.0 - (pUnder + pPush));
  } else {
    pUnder = pStrictlyLess + pExact;
    pPush = 0.0;
    pOver = Math.max(0.0, 1.0 - pUnder);
  }
  return { p_over: pOver, p_under: pUnder, p_push: pPush };
}

export function conditionalProbs(pOver: number, pUnder: number) {
  const sum = pOver + pUnder;
  if (sum <= 0) return { over: 0.5, under: 0.5 };
  return {
    over: pOver / sum,
    under: pUnder / sum
  };
}

export function parseOdds(str: string | number | null | undefined) {
  if (str === null || str === undefined) return { imp: 0.5, dec: 2.0, us: 100 };
  const raw = String(str).trim().replace(/[−–—]/g, "-").replace(/^\+/, "");
  const o = parseFloat(raw);
  if (isNaN(o) || o === 0) return { imp: 0.5, dec: 2.0, us: 100 };

  if (Math.abs(o) >= 1.01 && Math.abs(o) <= 40.0) {
    const dec = Math.abs(o);
    const imp = 1.0 / dec;
    const us = dec >= 2.0 ? Math.round((dec - 1.0) * 100) : -Math.round(100 / (dec - 1.0));
    return { imp, dec, us };
  }
  let dec: number;
  let imp: number;
  if (o < 0) {
    dec = 1.0 + (100.0 / -o);
    imp = (-o) / ((-o) + 100.0);
  } else {
    dec = 1.0 + (o / 100.0);
    imp = 100.0 / (o + 100.0);
  }
  return { imp, dec, us: Math.round(o) };
}

export function devigTwoWay(overOddsStr: string | number, underOddsStr: string | number) {
  const impO = parseOdds(overOddsStr).imp;
  const impU = parseOdds(underOddsStr).imp;
  const fairOver = impO / (impO + impU);
  return {
    fair_over: fairOver,
    fair_under: 1.0 - fairOver
  };
}

export function computeStructuralMu(
  stats: {
    routes: number;
    season_tprr: number;
    prior_tprr: number;
    receptions: number;
    targets: number;
    route_pct: number;
    walk_forward_ratio: number;
    season_avg_receptions: number;
  },
  game: {
    spread: number;
    implied_total: number;
  }
) {
  const dropbacks = NFL_CONFIG.dropback_base
                  + NFL_CONFIG.dropback_spread_coef * game.spread
                  + NFL_CONFIG.dropback_total_coef * (game.implied_total - 22.0);

  const shrunkTprr = (stats.routes * stats.season_tprr + NFL_CONFIG.k_routes * stats.prior_tprr)
                   / (stats.routes + NFL_CONFIG.k_routes);

  const shrunkCatchRate = (stats.receptions + NFL_CONFIG.k_catch * NFL_CONFIG.league_catch_rate)
                        / (stats.targets + NFL_CONFIG.k_catch);

  const muStructural = Math.max(0.2, dropbacks * stats.route_pct * shrunkTprr * shrunkCatchRate);
  const muAdapted = muStructural * stats.walk_forward_ratio;

  // v1.4 blend with season average receptions per game
  const finalMu = Math.max(0.2, (NFL_CONFIG.blend_weight * muAdapted) + ((1.0 - NFL_CONFIG.blend_weight) * stats.season_avg_receptions));

  return {
    dropbacks,
    shrunkTprr,
    shrunkCatchRate,
    muStructural,
    muAdapted,
    finalMu
  };
}

export function evaluateCardRules(
  edge: number,
  recommendedOddsUs: number | string,
  modelMu: number,
  seasonAvg: number
): { status: 'BET' | 'PASS' | 'OFF'; reason: string } {
  const oddsNum = typeof recommendedOddsUs === 'string' ? parseOdds(recommendedOddsUs).us : recommendedOddsUs;

  // 1. Edge constraint: >= 3.0 percentage points
  if (edge < 0.03) {
    return { status: "PASS", reason: "Edge under +3.0 pts threshold" };
  }

  // 2. Favorite price constraint: no shorter than -150
  if (oddsNum < -150) {
    return { status: "PASS", reason: `Price ${oddsNum} exceeds maximum playable chalk (-150)` };
  }

  // 3. Agreement constraint: |model_mu - season_avg| <= 1.5
  if (Math.abs(modelMu - seasonAvg) > 1.5) {
    return { status: "OFF", reason: `Model mu (${modelMu.toFixed(2)}) deviates > 1.5 rec from season avg (${seasonAvg.toFixed(2)})` };
  }

  return { status: "BET", reason: "Meets edge, price tolerance, and historical form agreement." };
}
