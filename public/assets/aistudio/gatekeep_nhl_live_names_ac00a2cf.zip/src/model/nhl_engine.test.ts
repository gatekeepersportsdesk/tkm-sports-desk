import test from 'node:test';
import assert from 'node:assert/strict';
import {
  nbinomPmf,
  pOverLine,
  projectNhlSkater,
  americanToImplied,
  evaluateNhlAction,
  NHL_FROZEN_CONFIG
} from './nhl_engine.ts';

test('NHL: nbinomPmf with r=15.13 behaves as expected', () => {
  const mu = 3.2;
  const r = NHL_FROZEN_CONFIG.r;
  let sum = 0;
  for (let k = 0; k <= 25; k++) {
    sum += nbinomPmf(k, mu, r);
  }
  assert.ok(Math.abs(sum - 1.0) < 0.001);
});

test('NHL: pOverLine produces monotonic decreasing probabilities as lines rise', () => {
  const mu = 3.5;
  const p15 = pOverLine(1.5, mu);
  const p25 = pOverLine(2.5, mu);
  const p35 = pOverLine(3.5, mu);
  const p45 = pOverLine(4.5, mu);

  assert.ok(p15 > p25, `Expected ${p15} > ${p25}`);
  assert.ok(p25 > p35, `Expected ${p25} > ${p35}`);
  assert.ok(p35 > p45, `Expected ${p35} > ${p45}`);
  assert.ok(p15 > 0.80);
});

test('NHL: opponent factor scales mu appropriately', () => {
  const player = {
    playerId: 8478402,
    name: "Connor McDavid",
    team: "EDM",
    pos: "F" as const,
    mu0: 3.42
  };
  const projVsSjs = projectNhlSkater(player, "SJS"); // SJS factor is 1.18 (soft defense)
  const projVsCar = projectNhlSkater(player, "CAR"); // CAR factor is 0.88 (stingy defense)

  assert.ok(projVsSjs.mu > projVsCar.mu, `SJS mu ${projVsSjs.mu} vs CAR mu ${projVsCar.mu}`);
  assert.ok(projVsSjs.probOver[2.5] > projVsCar.probOver[2.5]);
});

test('NHL: evaluateNhlAction categorizes STAB, FADE, and PASS', () => {
  // Model prob = 0.60 (60%). Market odds = +100 (50%). Edge = +10pp -> STAB
  const stab = evaluateNhlAction(0.60, 100, 5.0, -200);
  assert.equal(stab.tag, 'STAB');

  // Model prob = 0.60. Market odds = -250 (71.4%). Edge is negative -> FADE
  const fade = evaluateNhlAction(0.40, 100, 5.0, -200);
  assert.equal(fade.tag, 'FADE');

  // Disqualified chalk: edge >= 5pp but odds = -220 past max chalk -200 -> PASS
  const chalkPass = evaluateNhlAction(0.75, -220, 5.0, -200);
  assert.equal(chalkPass.tag, 'PASS');

  // Inside neutral band: 52% model vs 50% market (edge = +2pp) -> PASS
  const neutral = evaluateNhlAction(0.52, 100, 5.0, -200);
  assert.equal(neutral.tag, 'PASS');
});

test('NHL: americanToImplied handles positive and negative odds correctly', () => {
  assert.ok(Math.abs(americanToImplied(100) - 0.50) < 1e-4);
  assert.ok(Math.abs(americanToImplied(-110) - (110 / 210)) < 1e-4);
  assert.ok(Math.abs(americanToImplied(150) - (100 / 250)) < 1e-4);
});
