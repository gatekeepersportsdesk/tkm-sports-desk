# Gatekeep Sports Desk — Multi-Sport Props Terminal

A quantitative, small-bankroll player propositions desk designed for serious sports analytics:
1. **NFL Receptions Props (Engine v1.4)** — WR/TE only, OLS dropbacks, Bayesian shrinkage, Negative Binomial discrete pricing, strict -150 chalk ceiling.
2. **MLB 0.5-Hit Desk (Engine v5.8)** — 11-step Bayesian engine, starter K% suppression, park factors, reference anchor centering, and Monte Carlo Gaussian copula parlay simulator.
3. **NHL Shots on Goal Desk (Engine sog_v1)** — Frozen Negative Binomial ($r = 15.13$) survival model, 1.5/2.5/3.5 SOG lines, cashable STABs, and MoneyPuck settle demo.

---

## 1. NFL Receptions Props (Engine v1.4)

### The Projection Pipeline for Expected Receptions $\mu$
1. **Dropbacks (Game Script OLS):**  
   $$\text{Dropbacks} = 36.697 + 0.3075 \times \text{spread} + 0.3562 \times (\text{implied\_total} - 22.0)$$
2. **Route Participation:** Trailing offense snap share (proxy for routes).
3. **TPRR (Targets Per Route Run):** Bayesian shrinkage toward prior ($K = 100$ routes):
   $$\text{TPRR}_{\text{shrunk}} = \frac{\text{Routes} \times \text{TPRR}_{\text{season}} + 100 \times \text{TPRR}_{\text{prior}}}{\text{Routes} + 100}$$
4. **Catch Rate:** Bayesian shrinkage toward league prior ($0.68$, $K = 30$ targets):
   $$\text{CatchRate}_{\text{shrunk}} = \frac{\text{Receptions} + 30 \times 0.68}{\text{Targets} + 30}$$
5. **Structural $\mu$:**  
   $$\mu_{\text{structural}} = \text{Dropbacks} \times \text{RoutePct} \times \text{TPRR}_{\text{shrunk}} \times \text{CatchRate}_{\text{shrunk}}$$
6. **Walk-Forward Position Ratio:** Position-specific actual/predicted, shrunk toward 1.0, clipped to $[0.85, 1.15]$.
7. **v1.4 Blend:**  
   $$\mu = 0.60 \times \mu_{\text{adapted}} + 0.40 \times \text{SeasonAvg}$$
8. **Negative Binomial Pricing:** Position dispersion $\alpha_{\text{WR}} = 0.100$, $\alpha_{\text{TE}} = 0.125$ ($r = 1/\alpha$). Discrete PMF computed via Lanczos log-gamma approximation.
9. **Two-Way De-vigging:** Converts American odds to fair market win probabilities.
   $$\text{Edge} = P_{\text{model}}(\text{side}) - P_{\text{market\_fair}}(\text{side})$$

### The 4 BET Qualification Card Rules
A proposition is tagged **`BET`** only if **all 4 conditions** hold:
1. **Edge $\ge 3.0$ percentage points.**
2. **Recommended side price $\ge -150$** ($-151$ and steeper chalk favorites are automatically demoted to `PASS`).
3. **Historical Form Agreement:** $|\mu - \text{SeasonAvg}| \le 1.5$ receptions. If deviation exceeds $1.5$, row displays **`OFF`**.
4. **Game Card Cap:** Maximum 3 `BET` suggestions per game (ranked strictly by descending edge).
* Suggested stake: **1.0 unit**.

---

## 2. MLB 0.5-Hit Desk (Engine v5.8)

* **Locked TUNE Parameters:**
  - `baseTop3HitRate: 0.673`, `compressionSlope: 0.85`, `calLo: 0.5`, `calHi: 0.8`
  - `lgBa: 0.255`, `seasonPriorPa: 500`, `xbaPriorPa: 120`, `kPriorBf: 150`, `kLeague: 22`, `kCoef: 2.0`
  - `recentWeight: 0.1`, `recentPriorAb: 120`, `platoonPrior: 0.003`, `splitPriorAb: 300`
  - `parkDamp: 0.5`, `marketWeight: 0.5`, `edgeMinPts: 1.5`, `oneSidedHold: 1.07`
* **Card Rules:**
  - **`PLAY`:** Lineup confirmed by MLB, batting in slots 1–3, juice inside $[-140, -220]$ window, edge $\ge +1.5$ percentage points.
  - **`PASS`:** Fails any of the above (with slot-only explanation when order is the sole violation).
* **Monte Carlo Parlay Simulator:**
  - Latent Gaussian copula with team covariance ($0.07$) and game factor ($0.03$), evaluated over 6,000 trial draws with book 5% SGP haircut.

---

## 3. NHL Shots on Goal Desk (Engine sog_v1)

* **Projection Model:**
  $$\mu = \mu_0 \times s \times (\text{opp\_factor}^{w\_opp})$$
  Default line: $\lfloor\mu\rfloor + 0.5$
* **Negative Binomial Survival:**
  Fixed dispersion $r = 15.13$:
  $$P(Y > \text{line}) = 1 - \text{CDF}(\lfloor\text{line}\rfloor)$$
* **Card Classification:**
  - **`STAB`:** Edge $\ge +5.0$ percentage points and American odds no shorter than $-200$.
  - **`FADE`:** Edge $\le -5.0$ percentage points (under advantage).
  - **`PASS`:** Neutral margin or excessive chalk.

---

## 4. Sample Import Block (NFL Week 6)

To test the NFL import parser and card engine, copy and paste this block into **Import Lines**:

```text
Jaxon Smith-Njigba, 6.5, -110, -120
AJ Barner, 2.5, -115, -115
Cooper Kupp, 2.5, -105, -125
Courtland Sutton, 3.5, +130, -175
Evan Engram, 2.5, -130, -105
Jaylen Waddle, 4.5, +100, -130
Marvin Mims Jr., 1.5, +110, -150
Rashid Shaheed, 1.5, -175, +130
Tory Horton, 0.5, -140, +105
Troy Franklin, 1.5, -135, +100
```
