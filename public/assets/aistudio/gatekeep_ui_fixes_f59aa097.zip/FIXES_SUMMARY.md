# Fixes Summary

## 1. Highest-% sort is full of unusable Unders
**Cause:** Sort uses model probability on the lean side. On 0.5 lines the model lean is UNDER at 90%+.
**Fix:** Add “Bettable only” filter and separate Over/Under sorts. Default high-% view to bettable sides only.

## 2. Search missing on some sports
**Cause:** Search lives in shared CardBoard but may not be rendered the same way on every desk.
**Fix:** Make the search input always visible in CardBoard so NBA/NHL/MLB match NFL.

## 3. Screenshot / paste import unreliable
**Cause:** Parser expects clean structured text or OCR JSON. Real Bet99 pastes are messy.
**Fix:** Harden parsePastedLinesText and improve the review step in the screenshot modal.

## 4. Simulations hard to find
**Cause:** gamesim and Parlay Lab exist but are not obvious from the main desk.
**Fix:** Surface a clear link/tab to Parlay Lab / simulations on all sports.

All changes are scoped to the files included in this package.
