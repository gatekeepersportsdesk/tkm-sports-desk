# Gatekeep Sports Desk — UI Fixes Prompt for Google AI Studio

Update the Gatekeep Sports Desk app with the following concrete fixes. The relevant source files are included in this package.

## Problems to fix
1. Sorting by “Model P desc (Highest %)” fills the top of the list with high-percentage UNDERs on low lines (0.5 3PM, BLK, etc.). These often hit but sportsbooks rarely post the Under side, so they are unusable.
2. No easy way to sort or filter Overs vs Unders separately.
3. No “bettable only” filter (only show rows where the lean side has a real posted price).
4. Player search exists in the shared CardBoard but is not consistently available / visible on NBA, NHL, and MLB the same way it is on NFL.
5. Screenshot / copy-paste line import is unreliable. Only clean JSON import and manual per-player entry work reliably. Pasted text from Bet99/Bet365 often fails to parse.
6. Game simulation / joint features (gamesim, Parlay Lab) are still in the codebase but hard to find. Make them easy to reach.

## Required changes

### 1. CardBoard.tsx — Sorting & Filters
- Add sort options:
  - “Highest % (Bettable only)”
  - “Highest % Overs”
  - “Highest % Unders”
  - Keep existing options.
- Add a “Bettable only” toggle/filter that hides any row where the lean side does not have a posted price.
- When sorting by percentage, default to or strongly prefer the bettable-only version so 90%+ unusable Unders no longer dominate.
- Make the player/team/opponent search box always visible on every sport desk (NBA, NHL, NFL, MLB).

### 2. card_core.ts / types
- Ensure CardRow has clear fields for whether over/under prices exist so the UI can filter on them.
- Add helper: `isBettable(row)` → true only if the lean side has a real price.

### 3. Line import (ocr_clean.ts + ScreenshotUploadModal / OddsImportPanel)
- Improve `parsePastedLinesText` to handle common Bet99 / Bet365 copy-paste formats more reliably (player name, line, American odds, O/U).
- Make the screenshot scanner more tolerant of imperfect OCR and show a clear review step before applying lines.
- Keep JSON import working as the reliable fallback.

### 4. Simulations / Parlay Lab
- Ensure Parlay Lab and gamesim joint tools are clearly accessible from the main navigation on all sports (not buried).
- Add a short note or link in the desk header so users can reach the simulation features.

## Output I need
- Updated versions of the affected files (especially CardBoard.tsx, card_core.ts, ocr_clean.ts).
- Brief comments in the code explaining the new filters and sorts.
- Confirmation that search works on all sports and that simulations remain reachable.

Focus on practical, drop-in changes. Do not redesign the whole app.
